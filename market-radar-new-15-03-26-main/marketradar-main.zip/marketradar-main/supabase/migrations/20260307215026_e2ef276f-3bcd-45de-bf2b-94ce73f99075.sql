CREATE TABLE public.prediction_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prediction_date date NOT NULL UNIQUE,
  btc_current_price numeric NOT NULL DEFAULT 0,
  btc_predicted_price numeric NOT NULL DEFAULT 0,
  btc_predicted_move numeric NOT NULL DEFAULT 0,
  btc_actual_price numeric,
  sp500_current_price numeric NOT NULL DEFAULT 0,
  sp500_predicted_price numeric NOT NULL DEFAULT 0,
  sp500_predicted_move numeric NOT NULL DEFAULT 0,
  sp500_actual_price numeric,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.prediction_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Service role full access" ON public.prediction_history
  AS RESTRICTIVE FOR ALL
  USING (true)
  WITH CHECK (true);