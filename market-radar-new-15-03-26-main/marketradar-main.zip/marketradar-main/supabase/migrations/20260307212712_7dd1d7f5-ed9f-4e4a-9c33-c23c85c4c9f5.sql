
CREATE TABLE public.market_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  market_title text NOT NULL,
  source text NOT NULL,
  probability integer NOT NULL,
  volume_raw numeric NOT NULL DEFAULT 0,
  category text NOT NULL DEFAULT 'Markets',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_market_snapshots_title_time ON public.market_snapshots (market_title, created_at DESC);
CREATE INDEX idx_market_snapshots_created_at ON public.market_snapshots (created_at);

ALTER TABLE public.market_snapshots ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Service role full access" ON public.market_snapshots
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);
