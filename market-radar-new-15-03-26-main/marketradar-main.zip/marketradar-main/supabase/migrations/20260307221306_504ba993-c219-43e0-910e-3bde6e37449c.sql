ALTER TABLE public.prediction_history 
ADD COLUMN IF NOT EXISTS gold_current_price numeric NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS gold_predicted_price numeric NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS gold_predicted_move numeric NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS gold_actual_price numeric DEFAULT NULL;