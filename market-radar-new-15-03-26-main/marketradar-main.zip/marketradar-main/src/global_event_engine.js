// GlobalEventEngine
// Aggregates prediction market signals (Polymarket, Kalshi, etc.) into structured macro signals.
// Usage: import { computeGlobalEventPayload, runCLI } from './global_event_engine.js'
// Or run: node src\global_event_engine.js

const DEFAULT_ALPHA = 0.25; // smoothing

// Event impact weights (configurable)
const EVENT_WEIGHTS = {
  oilSupplyShock: 1.5,
  inflationSpike: 1.3,
  geopoliticalConflict: 1.4,
  recessionRisk: 1.2,
  policyTightening: 1.1
};

// Helper: safe number
function toNum(x) { const n = Number(x); return isNaN(n) ? null : n; }

// Normalize probability to [0,1]
function normalizeProb(p) {
  if (p == null) return null;
  const n = Number(p);
  if (isNaN(n)) return null;
  if (n < 0) return 0;
  if (n > 1) return n <= 100 ? (n > 1 ? n / 100 : n) : 1; // if >1 treat 0..100
  return n;
}

// Simple fetch helper
async function fetchJson(url, opts = {}) {
  try {
    const res = await fetch(url, { headers: { 'Accept': 'application/json', 'User-Agent': 'market-oracle/1.0' }, ...opts });
    if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
    return await res.json();
  } catch (e) {
    return null;
  }
}

// Polymarket fetcher (search by topic)
async function fetchPolymarketMarkets(topic = 'oil') {
  const endpoints = [
    `https://api.polymarket.com/v1/markets?search=${encodeURIComponent(topic)}&limit=200`,
    `https://polymarket.com/api/markets?search=${encodeURIComponent(topic)}&limit=200`
  ];
  for (const url of endpoints) {
    const d = await fetchJson(url);
    if (!d) continue;
    let arr = null;
    if (Array.isArray(d)) arr = d;
    if (Array.isArray(d.markets)) arr = d.markets;
    if (Array.isArray(d.results)) arr = d.results;
    if (!arr) continue;
    return arr.map(m => ({ source: 'polymarket', id: m.id || m.slug || null, title: m.title || m.name || m.description || '', probability: m.probability ?? m.lastTradePrice ?? m.lastPrice ?? null, raw: m }));
  }
  return [];
}

// Kalshi fetcher - Using free public endpoints (no API key required)
// Returns empty array if API is unavailable (no demo data)
async function fetchKalshiMarkets(topic = 'oil') {
  // Try free public endpoints first
  try {
    const url = `https://api.kalshi.com/trade-api/v2/markets?status=active&limit=50`;
    const d = await fetchJson(url);
    if (!d || !d.markets) return []; // Return empty instead of demo data

    // Filter by topic if possible
    let markets = d.markets || [];
    if (topic) {
      const topicLower = topic.toLowerCase();
      markets = markets.filter(m =>
        (m.title && m.title.toLowerCase().includes(topicLower)) ||
        (m.question && m.question.toLowerCase().includes(topicLower))
      );
    }

    return markets.slice(0, 20).map(m => ({
      source: 'kalshi',
      id: m.id || m.conditionId || null,
      title: m.title || m.question || '',
      probability: m.lastPrice ?? m.yesBid ?? m.yesAsk ?? 0.5,
      raw: m
    }));
  } catch (e) {
    console.warn('Kalshi fetch failed, returning empty:', e.message);
    return []; // Return empty array on error - no demo data
  }
}

// Map markets to canonical event categories and extract probability, volume, and timestamps
function mapMarketToEvents(market) {
  const title = (market.title || '').toString();
  const titleLower = title.toLowerCase();
  const prob = normalizeProb(market.probability ?? market.prob ?? market.lastTradePrice ?? market.lastPrice ?? market.raw?.probability);

  // attempt to extract volume from common fields across providers
  let volume = null;
  const raw = market.raw || {};
  const volFields = ['volumeUSD','volume_usd','volumeUsd','volume','totalVolume','total_volume','volume_24h','liquidity'];
  for (const f of volFields) {
    if (raw[f] != null) { volume = Number(raw[f]); break; }
    if (market[f] != null) { volume = Number(market[f]); break; }
  }
  if (isNaN(volume)) volume = null;

  // timestamps
  const tsFields = ['closeTime','closesAt','closes_at','close_at','endTime','endDate','createdAt','created_at','created'];
  let timestamp = null;
  for (const f of tsFields) {
    if (raw[f]) { timestamp = (new Date(raw[f])).toISOString(); break; }
    if (market[f]) { timestamp = (new Date(market[f])).toISOString(); break; }
  }

  const base = { probability: prob, reason: title, source: market.source, volume: volume ?? 0, ts: timestamp, id: market.id || market.raw?.id || null };
  const events = [];

  // Energy / oil supply shock
  if (/oil|opec|opec.*cut|production cut|supply disrupt|energy supply|oil above|oil >|brent.*above|wti.*above/.test(titleLower)) {
    events.push({ key: 'oilSupplyShock', ...base });
  }

  // Inflation
  if (/inflation|cpi|consumer price|core cpi|inflation higher|inflation above|inflation spike/.test(titleLower)) {
    events.push({ key: 'inflationSpike', ...base });
  }

  // Policy tightening
  if (/fed|fed funds|rate hike|rate increase|fed will raise|interest rate (hike|increase)|central bank.*hike/.test(titleLower)) {
    events.push({ key: 'policyTightening', ...base });
  }

  // Recession
  if (/recession|economic contraction|recession probability|recession risk/.test(titleLower)) {
    events.push({ key: 'recessionRisk', ...base });
  }

  // Geopolitics
  if (/war|conflict|sanction|sanctions|trade restriction|trade war|escalation|invasion|attack|embargo/.test(titleLower)) {
    events.push({ key: 'geopoliticalConflict', ...base });
  }

  return events;
}

// Aggregate events across markets into probabilities per event using volume-weighted averaging
function aggregateEvents(mappedEvents, options = {}) {
  const { minVolumePerMarket = 100, minMarkets = 1 } = options;
  const agg = {};
  for (const ev of mappedEvents) {
    if (ev.probability == null) continue;
    // filter low-volume markets early
    const vol = Number(ev.volume) || 0;
    if (vol > 0 && vol < minVolumePerMarket) continue;
    if (!agg[ev.key]) agg[ev.key] = { items: [], reasons: [] };
    agg[ev.key].items.push(ev);
    agg[ev.key].reasons.push({ reason: ev.reason, source: ev.source, p: ev.probability, volume: vol, ts: ev.ts });
  }

  const out = {};
  for (const k of Object.keys(agg)) {
    const items = agg[k].items;
    if (!items || items.length === 0) continue;

    // compute weights (moderated by sqrt to reduce dominance)
    const weights = items.map(it => ({ w: it.volume && it.volume > 0 ? Math.sqrt(it.volume) : 1, p: it.probability }));
    const totalW = weights.reduce((s, x) => s + x.w, 0);
    const weightedMean = weights.reduce((s, x) => s + x.w * x.p, 0) / (totalW || items.length);

    // compute weighted variance for dispersion
    const weightedVar = weights.reduce((s, x) => s + x.w * Math.pow(x.p - weightedMean, 2), 0) / (totalW || items.length);
    const dispersion = Math.sqrt(weightedVar);

    const totalVolume = items.reduce((s, it) => s + (Number(it.volume) || 0), 0);
    const n = items.length;

    // reliability heuristic: combine log-volume, count, and low dispersion
    const scoreVol = Math.min(1, Math.log10(totalVolume + 1) / 4); // ~1 when totalVolume ~ 10k
    const scoreCount = Math.min(1, n / 10);
    const scoreDispersion = 1 - Math.min(1, dispersion * 2); // dispersion near 0 => near 1
    const reliability = Math.max(0, Math.min(1, 0.5 * scoreVol + 0.3 * scoreCount + 0.2 * scoreDispersion));

    out[k] = {
      probability: Math.max(0, Math.min(1, weightedMean)),
      drivers: agg[k].reasons,
      count: n,
      totalVolume,
      dispersion,
      reliability
    };
  }
  return out;
}

// Convert event probabilities to weighted signals
function eventSignalsFromAggregates(aggregates, weights = EVENT_WEIGHTS, options = {}) {
  // multiply probabilities by reliability to downweight weak events
  const signals = {};
  const getAdjusted = (k, weightKey) => {
    const o = aggregates[k];
    if (!o) return 0;
    const prob = o.probability ?? 0;
    const rel = o.reliability != null ? o.reliability : 1;
    return prob * rel * (weights[weightKey] ?? 1);
  };
  signals.oilSupplyShockProbability = getAdjusted('oilSupplyShock', 'oilSupplyShock');
  signals.inflationSpikeProbability = getAdjusted('inflationSpike', 'inflationSpike');
  signals.policyTighteningProbability = getAdjusted('policyTightening', 'policyTightening');
  signals.recessionProbability = getAdjusted('recessionRisk', 'recessionRisk');
  signals.geopoliticalRiskProbability = getAdjusted('geopoliticalConflict', 'geopoliticalConflict');
  return signals;
}

// Combine into globalEventScore and normalize to [-10, +10]
function computeGlobalEventScoreFromSignals(signals) {
  let s = 0;
  s += signals.oilSupplyShockProbability ?? 0;
  s += signals.inflationSpikeProbability ?? 0;
  s += signals.geopoliticalRiskProbability ?? 0;
  s += signals.recessionProbability ?? 0;
  s += signals.policyTighteningProbability ?? 0;
  // s is positive; transform to [-10,10] by scaling. Determine theoretical max: sum of weights (if prob=1)
  const maxTheoretical = (EVENT_WEIGHTS.oilSupplyShock + EVENT_WEIGHTS.inflationSpike + EVENT_WEIGHTS.geopoliticalConflict + EVENT_WEIGHTS.recessionRisk + EVENT_WEIGHTS.policyTightening);
  // scale to [0,10] then shift to [-10,10] centered at 0 by mapping 0->-10 and max->+10
  const scaled = (s / maxTheoretical) * 20 - 10; // linear map
  // clamp
  return Math.max(-10, Math.min(10, scaled));
}

// Exponential smoothing
function smoothEventScore(prevScore, newScore, alpha = DEFAULT_ALPHA) {
  if (prevScore == null) return newScore;
  return alpha * newScore + (1 - alpha) * prevScore;
}

// Macro cluster integration
function integrateIntoMacroCluster({ dollarIndexSignal = 0, bondYieldSignal = 0, liquiditySignal = 0, oilPressureSignal = 0, globalEventScore = 0, globalWeight = 0.12 }) {
  // globalEventScore contribution ~ 10-15%
  const macroScore = dollarIndexSignal + bondYieldSignal + liquiditySignal + oilPressureSignal + (globalEventScore * globalWeight);
  return macroScore;
}

// Cross-asset impact engine: returns adjustments to asset scores
function crossAssetImpacts(aggregates) {
  const impacts = {
    goldScore: 0,
    equityScore: 0,
    oilPressureScore: 0,
    bondYieldPressure: 0,
    cryptoScore: 0,
    safeHavenScore: 0
  };

  const geo = aggregates.geopoliticalConflict?.probability ?? 0;
  const infl = aggregates.inflationSpike?.probability ?? 0;
  const rec = aggregates.recessionRisk?.probability ?? 0;

  if (geo > 0.6) {
    impacts.goldScore += 1 * (geo - 0.6); // positive
    impacts.equityScore -= 1.5 * (geo - 0.6);
    impacts.oilPressureScore += 1.2 * (geo - 0.6);
  }
  if (infl > 0.6) {
    impacts.bondYieldPressure += 1.3 * (infl - 0.6);
    impacts.goldScore += 0.8 * (infl - 0.6);
    impacts.equityScore -= 1 * (infl - 0.6);
  }
  if (rec > 0.6) {
    impacts.equityScore -= 1.5 * (rec - 0.6);
    impacts.cryptoScore -= 1.0 * (rec - 0.6);
    impacts.safeHavenScore += 1.2 * (rec - 0.6);
  }

  return impacts;
}

// Drift detection
function detectMacroEventDrift(prevGlobalScore, currentGlobalScore, currentPrice = null, prevPrice = null, opts = {}) {
  const deltaScore = (currentGlobalScore ?? 0) - (prevGlobalScore ?? 0);
  const priceChange = (currentPrice != null && prevPrice != null && prevPrice !== 0) ? ((currentPrice - prevPrice) / Math.abs(prevPrice)) : null;

  const scoreThreshold = opts.scoreThreshold ?? 0.05; // 5 percentage point increase (in normalized global score units?)
  const priceStabilityThreshold = opts.priceStabilityThreshold ?? 0.01; // 1% price move considered stable

  const macroEventDrift = (deltaScore > scoreThreshold) && (priceChange == null || Math.abs(priceChange) <= priceStabilityThreshold);
  return { macroEventDrift, deltaScore, priceChange };
}

// Top drivers extraction
function extractTopDrivers(aggregates, topN = 5) {
  const drivers = [];
  for (const [k, v] of Object.entries(aggregates)) {
    for (const d of (v.drivers || [])) {
      drivers.push({ event: k, driver: d.reason, source: d.source, p: d.p });
    }
  }
  drivers.sort((a,b) => Math.abs(b.p - 0.5) - Math.abs(a.p - 0.5)); // drivers far from 0.5 are more decisive
  return drivers.slice(0, topN);
}

// Explainability signal drivers builder
function buildSignalDrivers({ liquidityDrivers = [], whaleDrivers = [], predictionMarketDrivers = [], technicalDrivers = [] }) {
  const lines = [];
  for (const l of liquidityDrivers) lines.push(`+ ${l}`);
  for (const w of whaleDrivers) lines.push(`+ ${w}`);
  for (const pm of predictionMarketDrivers) lines.push(`+ ${pm}`);
  for (const t of technicalDrivers) lines.push(`- ${t}`);
  return lines;
}

// Main compute pipeline: accepts markets array (from any source), previousScore optional, and returns payload
async function computeGlobalEventPayload({ markets = [], prevSmoothedScore = null, alpha = DEFAULT_ALPHA, otherOptions = {} } = {}) {
  // Map markets to events
  const mapped = [];
  for (const m of markets) {
    const evs = mapMarketToEvents(m);
    for (const e of evs) mapped.push(e);
  }

  // apply aggregation with volume filtering
  const aggOptions = { minVolumePerMarket: otherOptions.minVolumePerMarket ?? 100, minMarkets: otherOptions.minMarkets ?? 3 };
  const aggregates = aggregateEvents(mapped, aggOptions);

  // compute signals using reliability-adjusted probabilities
  const signals = eventSignalsFromAggregates(aggregates);
  const rawGlobalScore = computeGlobalEventScoreFromSignals(signals);
  const smoothed = smoothEventScore(prevSmoothedScore, rawGlobalScore, alpha);

  // compute overall reliability as weighted average of event reliabilities (weights by event importance)
  const eventKeys = ['oilSupplyShock','inflationSpike','policyTightening','recessionRisk','geopoliticalConflict'];
  let reliSum = 0, reliW = 0;
  for (const k of eventKeys) {
    const rel = aggregates[k]?.reliability ?? 0;
    const w = EVENT_WEIGHTS[k] ?? 1;
    reliSum += rel * w;
    reliW += w;
  }
  const overallReliability = reliW > 0 ? reliSum / reliW : 0;

  const payload = {
    timestamp: new Date().toISOString(),
    rawGlobalScore,
    smoothedGlobalScore: smoothed,
    overallReliability,
    eventProbabilities: {
      oilSupplyShock: aggregates.oilSupplyShock?.probability ?? null,
      inflationSpike: aggregates.inflationSpike?.probability ?? null,
      policyTightening: aggregates.policyTightening?.probability ?? null,
      recessionRisk: aggregates.recessionRisk?.probability ?? null,
      geopoliticalConflict: aggregates.geopoliticalConflict?.probability ?? null
    },
    eventReliability: {
      oilSupplyShock: aggregates.oilSupplyShock?.reliability ?? 0,
      inflationSpike: aggregates.inflationSpike?.reliability ?? 0,
      policyTightening: aggregates.policyTightening?.reliability ?? 0,
      recessionRisk: aggregates.recessionRisk?.reliability ?? 0,
      geopoliticalConflict: aggregates.geopoliticalConflict?.reliability ?? 0
    },
    eventMeta: {
      oilSupplyShock: { count: aggregates.oilSupplyShock?.count ?? 0, totalVolume: aggregates.oilSupplyShock?.totalVolume ?? 0 },
      inflationSpike: { count: aggregates.inflationSpike?.count ?? 0, totalVolume: aggregates.inflationSpike?.totalVolume ?? 0 },
      policyTightening: { count: aggregates.policyTightening?.count ?? 0, totalVolume: aggregates.policyTightening?.totalVolume ?? 0 },
      recessionRisk: { count: aggregates.recessionRisk?.count ?? 0, totalVolume: aggregates.recessionRisk?.totalVolume ?? 0 },
      geopoliticalConflict: { count: aggregates.geopoliticalConflict?.count ?? 0, totalVolume: aggregates.geopoliticalConflict?.totalVolume ?? 0 }
    },
    eventSignals: signals,
    aggregates,
    topEventDrivers: extractTopDrivers(aggregates, 6)
  };

  return payload;
}

// Convenience: high-level function that fetches markets from supported providers and computes payload
async function runAllAndCompute(topic = 'oil', prevSmoothedScore = null) {
  const [poly, kalshi] = await Promise.all([
    fetchPolymarketMarkets(topic),
    fetchKalshiMarkets(topic)
  ]);
  const markets = [...(poly || []), ...(kalshi || [])];
  return await computeGlobalEventPayload({ markets, prevSmoothedScore });
}

// CLI runner
async function runCLI() {
  const topic = process.argv[2] || 'oil';
  console.log('Fetching markets for topic:', topic);
  const payload = await runAllAndCompute(topic, null);
  console.log('Global Event Payload:');
  console.log(JSON.stringify(payload, null, 2));
}

export {
  fetchPolymarketMarkets,
  fetchKalshiMarkets,
  mapMarketToEvents,
  aggregateEvents,
  eventSignalsFromAggregates,
  computeGlobalEventScoreFromSignals,
  smoothEventScore,
  computeGlobalEventPayload,
  runAllAndCompute,
  runCLI,
  integrateIntoMacroCluster,
  crossAssetImpacts,
  detectMacroEventDrift,
  extractTopDrivers,
  buildSignalDrivers
};

if (typeof process !== 'undefined' && process.argv && process.argv[1] && process.argv[1].endsWith('global_event_engine.js')) {
  runCLI().catch(e => { console.error(e); process.exit(1); });
}
