import { motion } from "framer-motion";

export function LoadingSkeleton({ className = "" }: { className?: string }) {
  return (
    <div className={`animate-pulse ${className}`}>
      <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
      <div className="h-8 bg-muted rounded w-1/2 mb-4"></div>
      <div className="space-y-3">
        <div className="h-3 bg-muted rounded w-full"></div>
        <div className="h-3 bg-muted rounded w-5/6"></div>
        <div className="h-3 bg-muted rounded w-4/6"></div>
      </div>
    </div>
  );
}

export function ForecastCardSkeleton() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-card rounded-xl border border-border p-4 card-elevated min-h-[520px]"
    >
      <div className="flex items-center justify-between mb-1.5">
        <div className="flex items-center gap-1.5">
          <div className="h-4 w-8 bg-muted rounded"></div>
          <div className="h-4 w-24 bg-muted rounded"></div>
        </div>
        <div className="h-4 w-16 bg-muted rounded"></div>
      </div>

      <div className="mb-1.5">
        <div className="h-8 w-24 bg-muted rounded"></div>
      </div>

      <div className="flex gap-0.5 mb-1.5 flex-wrap">
        {["1H", "4H", "24H", "3D", "7D"].map((tf) => (
          <div key={tf} className="h-6 w-8 bg-muted rounded"></div>
        ))}
      </div>

      <div className="space-y-1">
        <div className="flex items-center justify-between">
          <div className="h-3 w-12 bg-muted rounded"></div>
          <div className="flex items-center gap-1">
            <div className="h-4 w-4 bg-muted rounded"></div>
            <div className="h-4 w-16 bg-muted rounded"></div>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <div className="h-3 w-16 bg-muted rounded"></div>
          <div className="h-4 w-12 bg-muted rounded"></div>
        </div>
        <div className="h-1 w-full bg-muted rounded-full"></div>
        <div className="flex items-center justify-between">
          <div className="h-3 w-16 bg-muted rounded"></div>
          <div className="h-3 w-12 bg-muted rounded"></div>
        </div>
      </div>

      <div className="mt-3">
        <div className="grid grid-cols-5 gap-1">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-4 bg-muted rounded"></div>
          ))}
        </div>
        <div className="mt-2 space-y-2">
          <div className="h-3 w-full bg-muted rounded"></div>
          <div className="h-3 w-3/4 bg-muted rounded"></div>
        </div>
      </div>
    </motion.div>
  );
}

export function DashboardSkeleton() {
  return (
    <div className="space-y-4">
      {/* Header Skeleton */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="h-4 w-4 bg-muted rounded"></div>
          <div className="h-4 w-32 bg-muted rounded"></div>
        </div>
        <div className="flex items-center gap-3">
          <div className="h-4 w-16 bg-muted rounded"></div>
          <div className="h-4 w-20 bg-muted rounded"></div>
          <div className="h-4 w-4 bg-muted rounded"></div>
        </div>
      </div>

      {/* Forecast Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[...Array(4)].map((_, i) => (
          <ForecastCardSkeleton key={i} />
        ))}
      </div>

      {/* Analytics Section */}
      <div className="border border-border rounded-xl overflow-hidden">
        <div className="w-full flex items-center justify-between bg-card px-4 py-3.5">
          <div className="flex items-center gap-3">
            <div className="h-3 w-48 bg-muted rounded"></div>
            <div className="h-3 w-24 bg-muted rounded"></div>
          </div>
          <div className="h-4 w-4 bg-muted rounded"></div>
        </div>
      </div>
    </div>
  );
}
