import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

export interface MomentumItem {
  title: string;
  previous: number;
  current: number;
  source: string;
}

const getMomentumLabel = (delta: number) => {
  const abs = Math.abs(delta);
  if (abs >= 8) return "Strong";
  if (abs >= 4) return "Moderate";
  if (abs >= 1) return "Weak";
  return "Flat";
};

const getMomentumColor = (delta: number) => {
  if (delta >= 4) return "text-bullish";
  if (delta <= -4) return "text-bearish";
  return "text-neutral";
};

const getMomentumBg = (delta: number) => {
  if (delta >= 4) return "bg-bullish/8 border-bullish/20";
  if (delta <= -4) return "bg-bearish/8 border-bearish/20";
  return "bg-secondary/50 border-border";
};

export const MomentumChart = ({ items }: { items: MomentumItem[] }) => {
  return (
    <div className="bg-card rounded-lg border border-border p-5">
      <h3 className="text-foreground font-semibold text-lg flex items-center gap-2 mb-1">
        <span>⚡</span> Probability Momentum
      </h3>
      <p className="text-muted-foreground text-xs mb-4">Direction of belief, not just current level</p>

      {items.length === 0 ? (
        <p className="text-muted-foreground text-xs text-center py-6">No momentum data yet</p>
      ) : (
        <div className="space-y-2.5">
          {items.map((item, i) => {
            const delta = item.current - item.previous;
            const Icon = delta > 1 ? TrendingUp : delta < -1 ? TrendingDown : Minus;

            return (
              <motion.div
                key={i}
                className={`rounded-md border px-4 py-3 ${getMomentumBg(delta)}`}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.06 }}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <p className="text-foreground text-sm font-medium truncate pr-3">{item.title}</p>
                  <span className="text-muted-foreground text-[10px] font-mono shrink-0">{item.source}</span>
                </div>

                {/* Probability flow */}
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 font-mono text-sm">
                    <span className="text-muted-foreground">{item.previous}%</span>
                    <span className="text-muted-foreground">→</span>
                    <span className={`font-bold ${getMomentumColor(delta)}`}>{item.current}%</span>
                  </div>

                  <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
                    <motion.div
                      className={`h-full rounded-full ${delta >= 0 ? "bg-bullish" : "bg-bearish"}`}
                      initial={{ width: `${item.previous}%` }}
                      animate={{ width: `${item.current}%` }}
                      transition={{ duration: 1, delay: 0.3 + i * 0.1 }}
                    />
                  </div>

                  <div className={`flex items-center gap-1 shrink-0 ${getMomentumColor(delta)}`}>
                    <Icon className="w-3.5 h-3.5" />
                    <span className="text-xs font-mono font-semibold">
                      {delta > 0 ? "+" : ""}{delta}%
                    </span>
                  </div>
                </div>

                <p className={`text-[10px] font-semibold uppercase tracking-wider mt-1.5 ${getMomentumColor(delta)}`}>
                  Momentum: {getMomentumLabel(delta)}
                </p>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
};
