// News Ticker Component
// Real-time news headline display at top of UI

import { useState, useEffect } from "react"
import { getNewsTicker } from "../oracle-engine"

interface TickerItem {
  headline: string
  sentiment: number
  source: string
}

export function NewsTicker() {
  const [tickerText, setTickerText] = useState<string>("")
  const [items, setItems] = useState<TickerItem[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    // Fetch ticker data every 60 seconds
    const fetchTicker = async () => {
      try {
        const text = await getNewsTicker()
        setTickerText(text)

        // Parse items from text
        const parsed = text.split(" | ").map((item) => {
          const sentiment = item.startsWith("🟢") ? 1 : item.startsWith("🔴") ? -1 : 0
          const sourceMatch = item.match(/\(([^)]+)\)$/)
          const source = sourceMatch ? sourceMatch[1] : ""
          const headline = item.replace(/^[🟢🔴⚪]\s*/, "").replace(/\s*\([^)]+\)$/, "")

          return { headline, sentiment, source }
        })

        setItems(parsed)
      } catch (error) {
        console.error("Failed to fetch ticker:", error)
      }
    }

    // Initial fetch
    fetchTicker()

    // Set up interval
    const interval = setInterval(fetchTicker, 60000)

    return () => clearInterval(interval)
  }, [])

  // Rotate through items every 10 seconds
  useEffect(() => {
    if (items.length <= 1) return

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % items.length)
    }, 10000)

    return () => clearInterval(interval)
  }, [items.length])

  if (!tickerText) {
    return (
      <div className="w-full bg-slate-800 text-white px-4 py-2">
        <div className="flex items-center gap-2">
          <span className="text-xl">📰</span>
          <span className="text-sm animate-pulse">Loading latest signals...</span>
        </div>
      </div>
    )
  }

  const currentItem = items[currentIndex]
  const sentimentColor = currentItem?.sentiment > 0 ? "text-green-400" : currentItem?.sentiment < 0 ? "text-red-400" : "text-gray-400"
  const sentimentBg = currentItem?.sentiment > 0 ? "bg-green-900/30" : currentItem?.sentiment < 0 ? "bg-red-900/30" : "bg-gray-800"

  return (
    <div className={`w-full ${sentimentBg} border-b border-slate-700`}>
      <div className="max-w-7xl mx-auto px-4 py-2">
        <div className="flex items-center gap-3">
          <span className="text-xl flex-shrink-0">📰</span>
          <span className="text-sm text-slate-300 flex-shrink-0">Latest Signal:</span>
          <div className="flex-1 overflow-hidden">
            <div
              key={currentIndex}
              className={`text-sm font-medium ${sentimentColor} animate-fade-in`}
            >
              {currentItem?.headline}
              <span className="text-slate-500 text-xs ml-2">
                ({currentItem?.source})
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            {items.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`w-1.5 h-1.5 rounded-full transition-all ${
                  idx === currentIndex ? "bg-blue-500 w-3" : "bg-slate-600 hover:bg-slate-500"
                }`}
                aria-label={`Go to headline ${idx + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default NewsTicker
