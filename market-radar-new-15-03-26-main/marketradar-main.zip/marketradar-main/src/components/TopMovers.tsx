import { motion } from "framer-motion";
import { TrendingUp, TrendingDown } from "lucide-react";

export interface Mover {
  title: string;
  change: number;
  probability: number;
  source: string;
  sentiment: number;
}

export const TopMovers = ({ movers }: { movers: Mover[] }) => {
  const sorted = [...movers].sort((a, b) => Math.abs(b.change) - Math.abs(a.change)).slice(0, 6);
  const gainers = sorted.filter((m) => m.change > 0);
  const losers = sorted.filter((m) => m.change <= 0);

  return (
    <div className="bg-card rounded-lg border border-border p-5">
      <h3 className="text-foreground font-semibold text-lg flex items-center gap-2 mb-4">
        <span>🚀</span> Top Movers
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Gainers */}
        <div>
          <p className="text-bullish text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" /> Gainers
          </p>
          <div className="space-y-2">
            {gainers.length === 0 && (
              <p className="text-muted-foreground text-xs">No gainers detected</p>
            )}
            {gainers.map((m, i) => (
              <motion.div
                key={i}
                className="bg-bullish/5 border border-bullish/15 rounded-md px-3 py-2"
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.08 }}
              >
                <p className="text-foreground text-xs font-medium leading-snug truncate">{m.title}</p>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-muted-foreground text-xs font-mono">{m.source}</span>
                  <span className="text-bullish text-xs font-mono font-bold">+{m.change}%</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Losers */}
        <div>
          <p className="text-bearish text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-1">
            <TrendingDown className="w-3 h-3" /> Losers
          </p>
          <div className="space-y-2">
            {losers.length === 0 && (
              <p className="text-muted-foreground text-xs">No losers detected</p>
            )}
            {losers.map((m, i) => (
              <motion.div
                key={i}
                className="bg-bearish/5 border border-bearish/15 rounded-md px-3 py-2"
                initial={{ opacity: 0, x: 8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.08 }}
              >
                <p className="text-foreground text-xs font-medium leading-snug truncate">{m.title}</p>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-muted-foreground text-xs font-mono">{m.source}</span>
                  <span className="text-bearish text-xs font-mono font-bold">{m.change}%</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
