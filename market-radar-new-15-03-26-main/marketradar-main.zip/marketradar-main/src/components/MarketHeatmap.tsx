import { motion } from "framer-motion";

export interface HeatmapCell {
  label: string;
  value: number;
  change: number;
  category: string;
}

const getCellBg = (change: number) => {
  if (change >= 6) return "bg-bullish/90";
  if (change >= 3) return "bg-bullish/50";
  if (change >= 1) return "bg-bullish/25";
  if (change <= -6) return "bg-bearish/90";
  if (change <= -3) return "bg-bearish/50";
  if (change <= -1) return "bg-bearish/25";
  return "bg-secondary";
};

const getTextColor = (change: number) => {
  if (Math.abs(change) >= 6) return "text-foreground";
  return "text-foreground";
};

export const MarketHeatmap = ({ cells }: { cells: HeatmapCell[] }) => {
  if (cells.length === 0) {
    return (
      <div className="bg-card rounded-lg border border-border p-5">
        <h3 className="text-foreground font-semibold text-lg flex items-center gap-2 mb-1">
          <span>🗺️</span> Market Heatmap
        </h3>
        <p className="text-muted-foreground text-xs text-center py-6">No heatmap data yet</p>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-lg border border-border p-5">
      <h3 className="text-foreground font-semibold text-lg flex items-center gap-2 mb-1">
        <span>🗺️</span> Market Heatmap
      </h3>
      <p className="text-muted-foreground text-xs mb-4">Each square = a market · Color = probability change</p>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
        {cells.map((cell, i) => (
          <motion.div
            key={cell.label}
            className={`rounded-md p-3 ${getCellBg(cell.change)} ${getTextColor(cell.change)}`}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.03, type: "spring", stiffness: 250 }}
          >
            <p className="text-[10px] uppercase tracking-wider opacity-60 truncate">{cell.category}</p>
            <p className="text-xs font-medium truncate mt-0.5">{cell.label}</p>
            <p className={`text-sm font-mono font-bold mt-1 ${cell.change >= 0 ? "text-bullish" : "text-bearish"}`}>
              {cell.change > 0 ? "+" : ""}{cell.change}%
            </p>
          </motion.div>
        ))}
      </div>

      <div className="flex items-center justify-between mt-3 text-[10px] text-muted-foreground font-mono">
        <span className="flex items-center gap-1"><span className="w-3 h-1.5 rounded-sm bg-bearish inline-block" /> Dropping</span>
        <span className="flex items-center gap-1"><span className="w-3 h-1.5 rounded-sm bg-secondary inline-block" /> Flat</span>
        <span className="flex items-center gap-1"><span className="w-3 h-1.5 rounded-sm bg-bullish inline-block" /> Rising</span>
      </div>
    </div>
  );
};
