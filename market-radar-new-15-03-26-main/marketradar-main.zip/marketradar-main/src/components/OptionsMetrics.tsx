import { motion } from "framer-motion";
import { Activity, BarChart2, TrendingDown, Layers } from "lucide-react";

interface AssetOptions {
  impliedVolatility: number;
  putCallRatio: number;
  skew: number;
  openInterest: number;
}

interface OptionsMetricsProps {
  metrics: {
    btc: AssetOptions;
    sp500: AssetOptions;
    gold: AssetOptions;
  };
}

const assets = [
  { key: "btc" as const, label: "Bitcoin", emoji: "₿" },
  { key: "sp500" as const, label: "S&P 500", emoji: "📊" },
  { key: "gold" as const, label: "Gold", emoji: "🥇" },
];

function formatOI(value: number): string {
  if (value >= 1_000_000_000) return `$${(value / 1_000_000_000).toFixed(1)}B`;
  if (value >= 1_000_000) return `$${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `$${(value / 1_000).toFixed(1)}K`;
  return `$${value.toFixed(0)}`;
}

function MetricRow({ icon: Icon, label, value, color }: {
  icon: React.ElementType;
  label: string;
  value: string;
  color?: string;
}) {
  return (
    <div className="flex items-center justify-between py-2">
      <div className="flex items-center gap-2">
        <Icon className="w-3.5 h-3.5 text-muted-foreground" />
        <span className="text-[11px] text-muted-foreground font-medium">{label}</span>
      </div>
      <span className={`text-sm font-bold tabular-nums font-mono ${color ?? "text-foreground"}`}>
        {value}
      </span>
    </div>
  );
}

export function OptionsMetrics({ metrics }: OptionsMetricsProps) {
  return (
    <section>
      <h2 className="text-[11px] font-bold text-muted-foreground uppercase tracking-widest mb-4">
        Market Derivatives
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {assets.map((asset, i) => {
          const m = metrics[asset.key];
          const ivColor = m.impliedVolatility > 30 ? "text-bearish" : m.impliedVolatility > 15 ? "text-neutral" : "text-bullish";
          const pcColor = m.putCallRatio > 1.2 ? "text-bearish" : m.putCallRatio < 0.8 ? "text-bullish" : "text-foreground";
          const skewColor = m.skew < -0.3 ? "text-bearish" : m.skew > 0.3 ? "text-bullish" : "text-foreground";

          return (
            <motion.div
              key={asset.key}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="bg-card rounded-2xl border border-border p-5 card-elevated"
            >
              <div className="flex items-center gap-2.5 mb-4">
                <span className="text-lg">{asset.emoji}</span>
                <h3 className="text-foreground font-bold text-sm">{asset.label}</h3>
              </div>

              <div className="divide-y divide-border">
                <MetricRow
                  icon={Activity}
                  label="Implied Volatility"
                  value={`${m.impliedVolatility.toFixed(1)}%`}
                  color={ivColor}
                />
                <MetricRow
                  icon={BarChart2}
                  label="Put/Call Ratio"
                  value={m.putCallRatio.toFixed(2)}
                  color={pcColor}
                />
                <MetricRow
                  icon={TrendingDown}
                  label="Skew"
                  value={m.skew >= 0 ? `+${m.skew.toFixed(2)}` : m.skew.toFixed(2)}
                  color={skewColor}
                />
                <MetricRow
                  icon={Layers}
                  label="Open Interest"
                  value={formatOI(m.openInterest)}
                />
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
