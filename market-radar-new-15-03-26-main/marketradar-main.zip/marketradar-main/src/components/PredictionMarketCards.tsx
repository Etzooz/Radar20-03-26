import { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Clock, Timer, Flame, Search, ChevronDown, ChevronRight, Zap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import Heatmap from "@/components/Heatmap";

interface EnrichedMarket {
  id: string;
  platform: string;
  question: string;
  assetGroup: string;
  assetLabel: string;
  yesPct: number | null;
  noPct: number | null;
  volumeUSD: number;
  volumeFormatted: string;
  createdDate: string | null;
  endDate: string | null;
  hoursUntilClose: number | null;
  window: string;
  windowLabel: string;
  impactScore: number;
  url: string;
  isLive: boolean;
}

interface PredictionMarketCardsProps {
  predictionMarketsByGroup?: Record<string, EnrichedMarket[]>;
  predictionMarketCounts?: Record<string, number>;
  signals?: any[];
}

const PLATFORM_COLORS: Record<string, string> = {
  polymarket: "bg-[#3b82f6]",
  kalshi: "bg-[#a855f7]",
  manifold: "bg-[#ec4899]",
  metaculus: "bg-[#f97316]",
};

const PLATFORM_SYMBOLS: Record<string, string> = {
  polymarket: "◆", kalshi: "○", manifold: "●", metaculus: "◎",
};

const WINDOW_COLORS: Record<string, string> = {
  TODAY: "bg-destructive/20 text-destructive",
  "THIS WEEK": "bg-primary/20 text-primary",
  "THIS MONTH": "bg-muted text-muted-foreground",
  "LONG TERM": "bg-secondary text-secondary-foreground",
};

const GROUP_CONFIG: { key: string; icon: string; label: string }[] = [
  { key: "BTC", icon: "₿", label: "BITCOIN" },
  { key: "CRYPTO", icon: "◈", label: "CRYPTO" },
  { key: "SNP_NASDAQ", icon: "◈", label: "S&P & NASDAQ" },
  { key: "GOLD", icon: "◎", label: "GOLD" },
];

function formatCountdown(hours: number | null): string {
  if (hours === null) return "";
  if (hours <= 0) return "Ended";
  if (hours < 1) return `${Math.round(hours * 60)}m`;
  if (hours < 24) return `${Math.round(hours)}h`;
  if (hours < 168) return `${Math.round(hours / 24)}d`;
  return `${Math.round(hours / 168)}w`;
}

function useCountdownHours(endDate: string | null | undefined) {
  const [hours, setHours] = useState<number | null>(() => {
    if (!endDate) return null;
    const ms = new Date(endDate).getTime() - Date.now();
    return ms > 0 ? ms / 3600000 : null;
  });
  useEffect(() => {
    if (!endDate) return;
    const update = () => {
      const ms = new Date(endDate).getTime() - Date.now();
      setHours(ms > 0 ? ms / 3600000 : 0);
    };
    update();
    if (hours !== null && hours < 48) {
      const id = setInterval(update, hours < 1 ? 1000 : 60000);
      return () => clearInterval(id);
    }
  }, [endDate]);
  return hours;
}

function MarketCard({ market }: { market: EnrichedMarket }) {
  const hours = useCountdownHours(market.endDate);
  const isUrgent = hours !== null && hours > 0 && hours < 24;
  const isClosingSoon = hours !== null && hours > 0 && hours < 1;
  const isLowVolume = market.volumeUSD < 1000;

  const platformBg = PLATFORM_COLORS[market.platform] ?? "bg-muted-foreground";
  const platformSymbol = PLATFORM_SYMBOLS[market.platform] ?? "●";
  const platformName = market.platform.charAt(0).toUpperCase() + market.platform.slice(1);
  const windowColor = WINDOW_COLORS[market.windowLabel] ?? "bg-muted text-muted-foreground";

  const glowClass = isClosingSoon
    ? "border-destructive/50 shadow-[0_0_15px_hsl(var(--destructive)/0.3)]"
    : isUrgent
      ? "border-warning/40 shadow-[0_0_12px_hsl(var(--warning)/0.2)]"
      : "border-border";

  const yesPct = market.yesPct ?? 50;
  const noPct = market.noPct ?? 50;

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: isLowVolume ? 0.5 : 1, y: 0 }}
      className={`bg-card rounded-xl border ${glowClass} p-4 card-elevated transition-all ${isLowVolume ? "opacity-50" : ""}`}
    >
      {/* Badges row */}
      <div className="flex items-center gap-1.5 mb-2.5 flex-wrap">
        <Badge className={`text-[9px] px-2 py-0.5 font-bold text-white border-0 ${platformBg}`}>
          {platformSymbol} {platformName}
        </Badge>
        <Badge className={`text-[9px] px-1.5 py-0.5 font-bold border-0 ${windowColor}`}>
          {market.windowLabel}
        </Badge>
        {isUrgent && (
          <Badge className="text-[9px] px-1.5 py-0 bg-destructive/20 text-destructive border-0 font-bold">
            <Zap className="w-2.5 h-2.5 mr-0.5" /> NEXT 24H
          </Badge>
        )}
      </div>

      {/* Title */}
      <h4 className="text-sm font-bold text-foreground leading-snug mb-3">{market.question}</h4>

      {/* YES / NO bar */}
      <div className="mb-3">
        <div className="flex items-center justify-between mb-1">
          <span className="text-bullish text-sm font-black font-mono">YES {yesPct}%</span>
          <span className="text-muted-foreground text-sm font-mono">NO {noPct}%</span>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden flex">
          <motion.div
            className="h-full bg-bullish/70 rounded-l-full"
            initial={{ width: 0 }}
            animate={{ width: `${yesPct}%` }}
            transition={{ duration: 0.5 }}
          />
          <div className="h-full bg-bearish/30 flex-1 rounded-r-full" />
        </div>
      </div>

      {/* Volume + Countdown row */}
      <div className="flex items-center justify-between">
        <span className="text-[10px] text-muted-foreground">
          Vol: <span className={`font-bold font-mono ${isLowVolume ? "text-muted-foreground" : "text-foreground"}`}>{market.volumeFormatted}</span>
        </span>
        {hours !== null && hours > 0 && (
          <span className={`text-sm font-black font-mono tabular-nums ${
            isClosingSoon ? "text-destructive animate-pulse" : isUrgent ? "text-warning" : "text-foreground"
          }`}>
            {formatCountdown(hours)}
          </span>
        )}
        {hours !== null && hours <= 0 && (
          <span className="text-sm font-bold text-muted-foreground flex items-center gap-1">
            <Clock className="w-3 h-3" /> Ended
          </span>
        )}
      </div>

      {/* Closing soon badge */}
      {isClosingSoon && (
        <div className="mt-2 flex items-center gap-2 rounded-lg px-3 py-1.5 bg-destructive/10">
          <Timer className="w-3.5 h-3.5 text-destructive animate-pulse" />
          <Badge className="text-[8px] px-2 py-0 bg-destructive text-destructive-foreground animate-pulse">
            CLOSING SOON
          </Badge>
        </div>
      )}
    </motion.div>
  );
}

function GroupSection({
  groupKey,
  icon,
  label,
  markets,
  defaultOpen = true,
}: {
  groupKey: string;
  icon: string;
  label: string;
  markets: EnrichedMarket[];
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  if (markets.length === 0) return null;

  // Sort by impactScore desc (volume × relevance), low volume to bottom
  const sorted = [...markets].sort((a, b) => {
    const aLow = a.volumeUSD < 1000 ? 1 : 0;
    const bLow = b.volumeUSD < 1000 ? 1 : 0;
    if (aLow !== bLow) return aLow - bLow;
    return b.impactScore - a.impactScore;
  });

  return (
    <div className="mb-4">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 w-full text-left py-2 px-1 hover:bg-secondary/30 rounded-lg transition-colors"
      >
        {open ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
        <span className="text-lg">{icon}</span>
        <span className="text-[11px] font-bold text-foreground uppercase tracking-widest">{label}</span>
        <Badge variant="outline" className="text-[9px] px-1.5 py-0 text-muted-foreground border-border ml-auto">
          {markets.length}
        </Badge>
      </button>
      {open && (
        <div className="space-y-3 mt-2 pl-1">
          <AnimatePresence>
            {sorted.map(m => (
              <MarketCard key={m.id} market={m} />
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}

export function PredictionMarketCards({ predictionMarketsByGroup, predictionMarketCounts }: PredictionMarketCardsProps) {
  const [search, setSearch] = useState("");

  const allMarkets = useMemo(() => {
    if (!predictionMarketsByGroup) return [];
    return [
      ...(predictionMarketsByGroup.BTC || []),
      ...(predictionMarketsByGroup.CRYPTO || []),
      ...(predictionMarketsByGroup.SNP_NASDAQ || []),
      ...(predictionMarketsByGroup.GOLD || []),
    ];
  }, [predictionMarketsByGroup]);

  // Filter by search
  const filterBySearch = (markets: EnrichedMarket[]) => {
    if (!search.trim()) return markets;
    const q = search.toLowerCase();
    return markets.filter(m =>
      m.question.toLowerCase().includes(q) ||
      m.platform.includes(q) ||
      m.assetLabel.toLowerCase().includes(q)
    );
  };

  // ALL MARKETS tab: PRIMARY + MACRO only
  const allMarketsFiltered = useMemo(() => {
    const filtered = allMarkets.filter(m => m.window === "PRIMARY" || m.window === "MACRO");
    return filterBySearch(filtered);
  }, [allMarkets, search]);

  // CLOSING IN 24H tab: URGENT only
  const urgentMarkets = useMemo(() => {
    const filtered = allMarkets.filter(m => m.window === "URGENT");
    return filterBySearch(filtered);
  }, [allMarkets, search]);

  const urgentCount = urgentMarkets.length;

  // Group filtered markets
  const groupMarkets = (markets: EnrichedMarket[]) => ({
    BTC: markets.filter(m => m.assetGroup === "BTC"),
    CRYPTO: markets.filter(m => m.assetGroup === "CRYPTO"),
    SNP_NASDAQ: markets.filter(m => m.assetGroup === "SNP_NASDAQ"),
    GOLD: markets.filter(m => m.assetGroup === "GOLD"),
  });

  const allGrouped = useMemo(() => groupMarkets(allMarketsFiltered), [allMarketsFiltered]);
  const urgentGrouped = useMemo(() => groupMarkets(urgentMarkets), [urgentMarkets]);

  if (!predictionMarketsByGroup) {
    return (
      <section>
        <h2 className="text-[11px] font-bold text-muted-foreground uppercase tracking-widest mb-4">
          🎯 Prediction Markets
        </h2>
        <div className="text-center py-8 text-muted-foreground text-sm">Loading markets...</div>
      </section>
    );
  }

  return (
    <section>
      <h2 className="text-[11px] font-bold text-muted-foreground uppercase tracking-widest mb-2">
        🎯 Prediction Markets
      </h2>
      {predictionMarketCounts && (
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[9px] text-muted-foreground font-mono mb-3">
          <span>{predictionMarketCounts.total} markets</span>
          <span className="text-border">|</span>
          {(predictionMarketCounts as any).byPlatform && Object.entries((predictionMarketCounts as any).byPlatform)
            .filter(([, count]) => (count as number) > 0)
            .map(([platform, count]) => (
              <span key={platform} className="flex items-center gap-1">
                <span className={`w-1.5 h-1.5 rounded-full ${PLATFORM_COLORS[platform] ?? "bg-muted-foreground"}`} />
                {platform.charAt(0).toUpperCase() + platform.slice(1)}: {count as number}
              </span>
            ))
          }
          <span className="text-border">|</span>
          <span className="text-muted-foreground/60">{predictionMarketCounts.discarded} filtered</span>
        </div>
      )}

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-3 bg-secondary/50 h-8">
          <TabsTrigger value="all" className="text-[10px] px-3 py-1 h-6 font-bold">
            ALL MARKETS ({allMarketsFiltered.length})
          </TabsTrigger>
          <TabsTrigger value="closing" className="text-[10px] px-3 py-1 h-6 relative font-bold">
            <Flame className="w-3 h-3 mr-1 text-warning" />
            CLOSING IN 24H
            {urgentCount > 0 && (
              <span className="ml-1.5 bg-warning text-warning-foreground text-[8px] font-black px-1.5 py-0 rounded-full min-w-[16px] text-center">
                {urgentCount}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        {/* Search bar */}
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search markets, assets, topics..."
            className="w-full bg-secondary/50 border border-border rounded-lg pl-9 pr-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
          />
        </div>

        <TabsContent value="all">
          {allMarketsFiltered.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground text-sm">
              No markets match your filters
            </div>
          ) : (
            GROUP_CONFIG.map(g => (
              <GroupSection
                key={g.key}
                groupKey={g.key}
                icon={g.icon}
                label={g.label}
                markets={allGrouped[g.key as keyof typeof allGrouped] || []}
              />
            ))
          )}
        </TabsContent>

        <TabsContent value="closing">
          {urgentMarkets.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground text-sm">
              No relevant markets closing in the next 24 hours
            </div>
          ) : (
            GROUP_CONFIG.map(g => (
              <GroupSection
                key={g.key}
                groupKey={g.key}
                icon={g.icon}
                label={g.label}
                markets={urgentGrouped[g.key as keyof typeof urgentGrouped] || []}
              />
            ))
          )}
        </TabsContent>
      </Tabs>
    </section>
  );
}
