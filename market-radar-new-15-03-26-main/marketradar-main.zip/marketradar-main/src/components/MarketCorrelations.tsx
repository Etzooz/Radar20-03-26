import { motion } from "framer-motion";
import type { MarketCorrelation } from "@/hooks/usePredictionMarkets";

interface Props {
  correlations: {
    btcSp500: MarketCorrelation;
    goldSp500: MarketCorrelation;
    btcGold: MarketCorrelation;
  };
}

function CorrelationCard({ label, pair, correlation, index }: {
  label: string;
  pair: string;
  correlation: MarketCorrelation;
  index: number;
}) {
  const isInverse = correlation.direction === "inverse";
  const arrow = isInverse ? "↕" : "↔";
  const dirColor = isInverse ? "text-bearish" : "text-bullish";
  const strengthBadge = correlation.strength === "Strong"
    ? "bg-bullish/12 text-bullish"
    : correlation.strength === "Moderate"
      ? "bg-neutral/12 text-neutral"
      : "bg-muted text-muted-foreground";

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08 }}
      className="bg-card border border-border rounded-xl p-4 card-elevated"
    >
      <div className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wide mb-2">{label}</div>
      <div className="flex items-center gap-2 mb-3">
        <span className="text-sm font-bold text-foreground">{pair.split(" ↔ ")[0]}</span>
        <span className={`text-lg ${dirColor}`}>{arrow}</span>
        <span className="text-sm font-bold text-foreground">{pair.split(" ↔ ")[1]}</span>
      </div>
      <div className="flex items-center gap-2">
        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${strengthBadge}`}>
          {correlation.strength}
        </span>
        <span className={`text-[11px] font-medium ${dirColor}`}>
          {correlation.direction === "positive" ? "Positive correlation" : "Inverse correlation"}
        </span>
      </div>
    </motion.div>
  );
}

export function MarketCorrelations({ correlations }: Props) {
  return (
    <div>
      <h2 className="text-[11px] font-bold text-muted-foreground uppercase tracking-widest mb-4">
        🔗 Market Relationships
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <CorrelationCard label="Crypto ↔ Equities" pair="BTC ↔ S&P 500" correlation={correlations.btcSp500} index={0} />
        <CorrelationCard label="Commodities ↔ Equities" pair="Gold ↔ S&P 500" correlation={correlations.goldSp500} index={1} />
        <CorrelationCard label="Crypto ↔ Commodities" pair="BTC ↔ Gold" correlation={correlations.btcGold} index={2} />
      </div>
    </div>
  );
}
