import { motion } from "framer-motion";
import type { GlobalMarketPulse as PulseData } from "@/hooks/usePredictionMarkets";

function getZoneConfig(score: number) {
  if (score <= 30) return { label: "Bearish", color: "text-bearish", bg: "bg-bearish", barColor: "bg-bearish" };
  if (score <= 45) return { label: "Weak", color: "text-[hsl(25,90%,55%)]", bg: "bg-[hsl(25,90%,55%)]", barColor: "bg-[hsl(25,90%,55%)]" };
  if (score <= 55) return { label: "Neutral", color: "text-neutral", bg: "bg-neutral", barColor: "bg-neutral" };
  if (score <= 70) return { label: "Bullish", color: "text-bullish", bg: "bg-bullish", barColor: "bg-bullish" };
  return { label: "Strong Bullish", color: "text-bullish", bg: "bg-bullish", barColor: "bg-bullish" };
}

export function GlobalMarketPulse({ data }: { data: PulseData }) {
  const zone = getZoneConfig(data.score);

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card rounded-2xl border border-border p-5 card-elevated"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <span className="text-lg">🌐</span>
          <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Global Market Pulse</h2>
        </div>
        <div className="flex items-center gap-2">
          {data.regime && (
            <span className="px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider bg-secondary text-foreground border border-border">
              {data.regime}
            </span>
          )}
          <div className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider ${zone.bg}/12 ${zone.color}`}>
            {zone.label}
          </div>
        </div>
      </div>

      <div className="flex items-end gap-4 mb-4">
        <div>
          <span className="text-3xl font-black tabular-nums font-mono tracking-tight text-foreground">{data.score}</span>
          <span className="text-sm text-muted-foreground font-medium ml-1">/ 100</span>
        </div>
        <span className={`text-sm font-semibold ${zone.color} mb-1`}>
          {data.environment}
        </span>
      </div>

      {/* Score bar */}
      <div className="w-full h-2 bg-accent rounded-full overflow-hidden mb-4">
        <motion.div
          className={`h-full rounded-full ${zone.barColor}`}
          initial={{ width: 0 }}
          animate={{ width: `${data.score}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />
      </div>

      {/* Color scale labels */}
      <div className="flex justify-between text-[9px] text-muted-foreground font-medium mb-4">
        <span>Bearish</span>
        <span>Weak</span>
        <span>Neutral</span>
        <span>Bullish</span>
        <span>Strong</span>
      </div>

      {/* Drivers */}
      <div>
        <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide mb-2 block">Key Drivers</span>
        <div className="flex flex-wrap gap-1.5">
          {data.drivers.map((driver, i) => (
            <span
              key={i}
              className="bg-secondary/80 text-foreground text-[11px] font-medium px-2.5 py-1 rounded-md border border-border"
            >
              {driver}
            </span>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
