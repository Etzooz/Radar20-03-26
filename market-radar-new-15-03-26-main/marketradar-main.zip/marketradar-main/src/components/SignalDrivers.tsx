import { Activity, TrendingUp, Waves, Droplets } from "lucide-react";
import { motion } from "framer-motion";

export interface AssetSignalDriver {
  sentimentRaw: number;
  sentimentLabel: string;
  momentum: number;
  volatility: number;
  liquidity: number;
  signalCount: number;
}

interface SignalDriversProps {
  drivers: {
    btc: AssetSignalDriver;
    sp500: AssetSignalDriver;
    gold: AssetSignalDriver;
  };
}

const assets = [
  { key: "btc" as const, label: "Bitcoin", emoji: "₿" },
  { key: "sp500" as const, label: "S&P 500", emoji: "📈" },
  { key: "gold" as const, label: "Gold", emoji: "🥇" },
];

export function SignalDrivers({ drivers }: SignalDriversProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <h3 className="text-[11px] font-bold text-muted-foreground uppercase tracking-widest mb-4">
        Signals Driving Prediction
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {assets.map((asset, ai) => {
          const d = drivers[asset.key];

          const sentimentInterp = d.sentimentRaw > 60 ? "Bullish" : d.sentimentRaw < 40 ? "Bearish" : "Neutral";
          const sentimentColor = sentimentInterp === "Bullish" ? "text-bullish" : sentimentInterp === "Bearish" ? "text-bearish" : "text-neutral";
          const sentimentValue = `${d.sentimentRaw >= 50 ? "+" : ""}${((d.sentimentRaw - 50) / 50).toFixed(2)}`;

          const momentumLabel = d.momentum > 2 ? "Rising" : d.momentum < -2 ? "Falling" : "Flat";
          const momentumColor = d.momentum > 2 ? "text-bullish" : d.momentum < -2 ? "text-bearish" : "text-neutral";
          const momentumValue = d.momentum > 0 ? `+${d.momentum.toFixed(1)}` : d.momentum.toFixed(1);

          const liqLabel = d.liquidity >= 60 ? "High" : d.liquidity >= 35 ? "Medium" : "Low";
          const liqColor = d.liquidity >= 60 ? "text-bullish" : d.liquidity >= 35 ? "text-neutral" : "text-bearish";

          const volLabel = d.volatility >= 15 ? "High" : d.volatility >= 5 ? "Medium" : "Low";
          const volColor = d.volatility >= 15 ? "text-bearish" : d.volatility >= 5 ? "text-neutral" : "text-bullish";

          const signals = [
            { icon: Activity, title: "Sentiment", value: sentimentValue, label: sentimentInterp, labelColor: sentimentColor },
            { icon: TrendingUp, title: "Momentum", value: momentumValue, label: momentumLabel, labelColor: momentumColor },
            { icon: Droplets, title: "Liquidity", value: `${d.liquidity}%`, label: liqLabel, labelColor: liqColor },
            { icon: Waves, title: "Volatility", value: `${d.volatility.toFixed(1)}%`, label: volLabel, labelColor: volColor },
          ];

          return (
            <motion.div
              key={asset.key}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: 0.1 * ai }}
              className="bg-card rounded-2xl border border-border p-5 card-elevated"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <span className="text-base">{asset.emoji}</span>
                  <span className="text-xs font-bold text-foreground">{asset.label}</span>
                </div>
                <span className="text-[9px] text-muted-foreground font-mono">{d.signalCount} signals</span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {signals.map((s, i) => (
                  <div
                    key={i}
                    className="bg-secondary/70 rounded-xl p-3 text-center"
                  >
                    <s.icon className="w-3.5 h-3.5 text-muted-foreground mx-auto mb-1.5" strokeWidth={2} />
                    <span className="text-[9px] text-muted-foreground font-semibold uppercase tracking-wide block mb-1">{s.title}</span>
                    <span className="text-sm font-bold text-foreground tabular-nums font-mono block">{s.value}</span>
                    <span className={`text-[10px] font-bold ${s.labelColor}`}>{s.label}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}
