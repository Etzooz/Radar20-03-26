import { Target } from "lucide-react";
import { motion } from "framer-motion";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";
import { format, parseISO } from "date-fns";
import type { AccuracyHistoryItem } from "@/hooks/usePredictionMarkets";

interface AccuracyTrackerProps {
  history: AccuracyHistoryItem[];
}

export function AccuracyTracker({ history }: AccuracyTrackerProps) {
  const chartData = history
    .filter(h => h.btcAccuracy !== null || h.sp500Accuracy !== null || h.goldAccuracy !== null)
    .map(h => ({
      date: format(parseISO(h.date), "EEE"),
      btc: h.btcAccuracy,
      sp500: h.sp500Accuracy,
      gold: h.goldAccuracy,
    }));

  if (chartData.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="bg-card rounded-2xl border border-border p-6 card-elevated"
    >
      <div className="flex items-center gap-2 mb-5">
        <Target className="w-4 h-4 text-muted-foreground" strokeWidth={2} />
        <h3 className="text-[11px] font-bold text-muted-foreground uppercase tracking-widest">
          7 Day Forecast Accuracy
        </h3>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <MiniChart data={chartData} dataKey="btc" label="Bitcoin Accuracy %" color="hsl(var(--bullish))" />
        <MiniChart data={chartData} dataKey="sp500" label="S&P 500 Accuracy %" color="hsl(var(--foreground))" />
        <MiniChart data={chartData} dataKey="gold" label="Gold Accuracy %" color="hsl(45 93% 47%)" />
      </div>
    </motion.div>
  );
}

function MiniChart({ data, dataKey, label, color }: { data: any[]; dataKey: string; label: string; color: string }) {
  return (
    <div>
      <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide block mb-3">{label}</span>
      <ResponsiveContainer width="100%" height={120}>
        <LineChart data={data}>
          <XAxis dataKey="date" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
          <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={30} />
          <Tooltip
            contentStyle={{ fontSize: 11, borderRadius: 8, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))" }}
            formatter={(v: number) => [`${v}%`, "Accuracy"]}
          />
          <Line type="monotone" dataKey={dataKey} stroke={color} strokeWidth={2} dot={{ r: 3, fill: color }} isAnimationActive={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
