import { motion } from "framer-motion";

interface MarketSignal {
  name: string;
  value: number;
}

const getColor = (v: number) => {
  if (v <= 35) return "bg-bearish";
  if (v <= 65) return "bg-neutral";
  return "bg-bullish";
};

export const MarketSignals = ({ signals }: { signals: MarketSignal[] }) => {
  return (
    <div className="bg-card rounded-lg border border-border p-5">
      <h3 className="text-foreground font-semibold text-lg flex items-center gap-2 mb-4">
        <span>🔍</span> Market Signals
      </h3>

      <div className="grid grid-cols-2 gap-3">
        {signals.map((signal, i) => (
          <motion.div
            key={i}
            className="bg-secondary/50 rounded-md p-3"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.05 }}
          >
            <p className="text-muted-foreground text-xs mb-1.5">{signal.name}</p>
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${getColor(signal.value)}`} />
              <span className="text-foreground font-mono font-bold text-lg">{signal.value}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
