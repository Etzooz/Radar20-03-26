import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Minus, BarChart3, Bitcoin } from "lucide-react";
import Heatmap from "@/components/Heatmap";

interface PriceCardProps {
  label: string;
  variant: "sp500" | "btc";
  currentPrice: number;
  predictedPrice: number;
  fearGreed: number;
}

const formatPrice = (p: number) =>
  p >= 1000 ? `$${p.toLocaleString("en-US", { maximumFractionDigits: 0 })}` : `$${p.toFixed(2)}`;

const getPctChange = (current: number, predicted: number) => {
  if (current === 0) return 0;
  return ((predicted - current) / current) * 100;
};

export const PriceCard = ({ label, variant, currentPrice, predictedPrice, fearGreed }: PriceCardProps) => {
  const pct = getPctChange(currentPrice, predictedPrice);
  const isUp = pct > 0.1;
  const isDown = pct < -0.1;
  const TrendIcon = isUp ? TrendingUp : isDown ? TrendingDown : Minus;

  const iconBg = variant === "btc"
    ? "bg-[hsl(35,90%,50%)]/15 text-[hsl(35,90%,55%)]"
    : "bg-primary/15 text-primary";

  return (
    <motion.div
      className="bg-card rounded-xl border border-border p-6 flex flex-col gap-5 min-h-[420px]"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
    >
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${iconBg}`}>
          {variant === "btc" ? <Bitcoin className="w-5 h-5" /> : <BarChart3 className="w-5 h-5" />}
        </div>
        <div className="flex-1">
          <h3 className="text-foreground font-bold text-lg leading-tight">{label}</h3>
          <p className="text-muted-foreground text-xs">
            {variant === "btc" ? "Crypto" : "Equities"} · Prediction Markets
          </p>
        </div>
        <span className={`px-2.5 py-1 rounded-md text-[11px] font-mono font-bold ${
          fearGreed <= 40 ? "bg-bearish/15 text-bearish" : fearGreed >= 60 ? "bg-bullish/15 text-bullish" : "bg-neutral/15 text-neutral"
        }`}>
          F&G {fearGreed}
        </span>
      </div>

      {/* Prices side by side */}
      <div className="grid grid-cols-2 gap-6">
        {/* Current */}
        <div>
          <p className="text-muted-foreground text-xs font-medium mb-1.5 uppercase tracking-wider">Now</p>
          <p className="text-foreground font-mono font-extrabold text-3xl tracking-tight">{formatPrice(currentPrice)}</p>
        </div>

        {/* Predicted */}
        <div>
          <p className="text-muted-foreground text-xs font-medium mb-1.5 uppercase tracking-wider">Predicted</p>
          <p className={`font-mono font-extrabold text-3xl tracking-tight ${isUp ? "text-bullish" : isDown ? "text-bearish" : "text-foreground"}`}>
            {formatPrice(predictedPrice)}
          </p>
          <div className={`flex items-center gap-1.5 mt-1 ${isUp ? "text-bullish" : isDown ? "text-bearish" : "text-muted-foreground"}`}>
            <TrendIcon className="w-4 h-4" />
            <span className="text-sm font-mono font-bold">
              {pct > 0 ? "+" : ""}{pct.toFixed(1)}%
            </span>
          </div>
        </div>
      </div>
      <div className="mt-3">
        <Heatmap intensity={1 - Math.max(0, Math.min(100, fearGreed)) / 100} />
      </div>
    </motion.div>
  );
};
