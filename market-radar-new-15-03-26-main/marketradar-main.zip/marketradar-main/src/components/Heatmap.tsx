import React from 'react';

interface HeatmapProps {
  // scores: optional map of label->value (0..1). If omitted, intensity can be used to render a generic heatmap.
  scores?: Record<string, number>;
  intensity?: number; // 0..1 fallback
  size?: number; // number of cells, default 5
}

export default function Heatmap({ scores, intensity = 0.5, size = 5 }: HeatmapProps) {
  const entries = scores ? Object.entries(scores) : Array.from({ length: size }).map((_, i) => [`c${i+1}`, Math.max(0, Math.min(1, intensity * (0.4 + i * 0.15)))]);

  function colorFor(v: number) {
    // Map 0..1 to green->yellow->red (hue 120 -> 60 -> 0)
    const hue = Math.round((1 - Math.max(0, Math.min(1, v))) * 120);
    return `hsl(${hue} 75% ${v > 0.5 ? '45%' : '55%'})`;
  }

  return (
    <div className="mt-3">
      <div className="grid grid-cols-5 gap-1">
        {entries.map(([label, val], idx) => (
          <div
            key={label + idx}
            title={`${label}: ${(val * 100).toFixed(0)}%`}
            style={{ background: colorFor(val) }}
            className="w-full h-4 rounded-sm border border-border"
          />
        ))}
      </div>
      <div className="text-[10px] text-muted-foreground mt-2">
        {scores ? Object.keys(scores).slice(0,5).map((k,i) => `${k}: ${(entries[i]?.[1]*100).toFixed(0)}%`).join(' · ') : 'Prediction market heatmap'}
      </div>
    </div>
  );
}
