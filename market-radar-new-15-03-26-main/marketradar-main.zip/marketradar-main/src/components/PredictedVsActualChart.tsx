import { Target } from "lucide-react";
import { motion } from "framer-motion";
import { useMemo } from "react";
import type { RealtimeAccuracy, AccuracyHistoryItem } from "@/hooks/usePredictionMarkets";

interface PredictedVsActualChartProps {
  realtimeAccuracy: RealtimeAccuracy;
  history: AccuracyHistoryItem[];
}

const assets = [
  { key: "btc" as const, label: "Bitcoin", emoji: "₿", accKey: "btcAccuracy" as const },
  { key: "sp500" as const, label: "S&P 500", emoji: "📈", accKey: "sp500Accuracy" as const },
  { key: "gold" as const, label: "Gold", emoji: "🥇", accKey: "goldAccuracy" as const },
];

function computeAverage(items: AccuracyHistoryItem[], accKey: "btcAccuracy" | "sp500Accuracy" | "goldAccuracy", days: number): number | null {
  const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
  const valid = items.filter(h => h.date >= cutoff && h[accKey] !== null);
  if (valid.length === 0) return null;
  const sum = valid.reduce((s, h) => s + (h[accKey] as number), 0);
  return Math.round(sum / valid.length);
}

function AccuracyValue({ value, label }: { value: number | null; label: string }) {
  const display = value !== null ? `${value}%` : "—";
  const color =
    value === null ? "text-muted-foreground" :
    value >= 70 ? "text-bullish" :
    value >= 50 ? "text-foreground" :
    "text-bearish";

  return (
    <div className="flex flex-col items-center flex-1 min-w-0">
      <span className="text-[9px] text-muted-foreground font-semibold uppercase tracking-wide mb-1">{label}</span>
      <span className={`text-2xl font-black tabular-nums font-mono tracking-tight ${color}`}>
        {display}
      </span>
    </div>
  );
}

export function PredictedVsActualChart({ realtimeAccuracy, history }: PredictedVsActualChartProps) {
  const averages = useMemo(() => {
    return assets.map(a => ({
      key: a.key,
      sevenDay: computeAverage(history, a.accKey, 7),
      fourteenDay: computeAverage(history, a.accKey, 14),
    }));
  }, [history]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
    >
      <div className="flex items-center gap-2 mb-4">
        <Target className="w-4 h-4 text-muted-foreground" strokeWidth={2} />
        <h3 className="text-[11px] font-bold text-muted-foreground uppercase tracking-widest">
          Forecast Accuracy
        </h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {assets.map((asset, i) => {
          const avg = averages.find(a => a.key === asset.key);
          return (
            <motion.div
              key={asset.key}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: 0.1 * i }}
              className="bg-card rounded-2xl border border-border p-5 card-elevated"
            >
              <div className="flex items-center gap-2 mb-4">
                <span className="text-base">{asset.emoji}</span>
                <span className="text-xs font-bold text-foreground">{asset.label}</span>
              </div>

              <div className="flex items-end justify-around gap-1">
                <AccuracyValue value={realtimeAccuracy.oneHour[asset.key]} label="1h" />
                <div className="w-px h-10 bg-border shrink-0" />
                <AccuracyValue value={realtimeAccuracy.twelveHour[asset.key]} label="12h" />
                <div className="w-px h-10 bg-border shrink-0" />
                <AccuracyValue value={avg?.sevenDay ?? null} label="7d" />
                <div className="w-px h-10 bg-border shrink-0" />
                <AccuracyValue value={avg?.fourteenDay ?? null} label="14d" />
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}
