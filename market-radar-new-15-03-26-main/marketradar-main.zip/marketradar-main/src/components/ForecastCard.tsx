import { useState, useEffect, useRef } from "react";
import { TrendingUp, TrendingDown, Minus, ChevronDown, ChevronUp } from "lucide-react";
import { motion } from "framer-motion";
import Heatmap from "@/components/Heatmap";

// Smooth number animation hook
function useAnimatedNumber(targetValue: number, duration: number = 500) {
  const [displayValue, setDisplayValue] = useState(targetValue);
  const animationRef = useRef<number>();
  const startTimeRef = useRef<number>();
  const startValueRef = useRef(targetValue);

  useEffect(() => {
    startValueRef.current = displayValue;
    startTimeRef.current = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - (startTimeRef.current || 0);
      const progress = Math.min(elapsed / duration, 1);

      // Ease out cubic
      const easeProgress = 1 - Math.pow(1 - progress, 3);

      const current = startValueRef.current + (targetValue - startValueRef.current) * easeProgress;
      setDisplayValue(current);

      if (progress < 1) {
        animationRef.current = requestAnimationFrame(animate);
      }
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [targetValue, duration]);

  return displayValue;
}

interface ForecastCardProps {
  label: string;
  variant: "btc" | "sp500" | "gold" | "oil";
  expectedMove: number;
  confidence: number;
  currentPrice: number;
  predictedPrice: number;
  liveSources: number;
  sources?: {
    polymarket?: number;
    kalshi?: number;
    manifold?: number;
    metaculus?: number;
  };
  signalsProcessed?: number;
  drivers?: string[];
  reliability?: "high" | "medium" | "low";
  regime?: string;
  compact?: boolean;
  globalEvent?: any; // payload from GlobalEventEngine
}

const TIMEFRAME_CONFIG: Record<string, { multiplier: number; label: string; maxMove: Record<string, number> }> = {
  "1H": { multiplier: 1.0, label: "1h", maxMove: { btc: 1.2, sp500: 0.4, gold: 0.3, oil: 0.5 } },
  "4H": { multiplier: 2.0, label: "4h", maxMove: { btc: 2.2, sp500: 0.9, gold: 0.7, oil: 1.0 } },
  "24H": { multiplier: 4.9, label: "24h", maxMove: { btc: 4.0, sp500: 1.8, gold: 1.5, oil: 2.5 } },
  "3D": { multiplier: 8.0, label: "3d", maxMove: { btc: 7.0, sp500: 3.5, gold: 2.8, oil: 4.0 } },
  "7D": { multiplier: 14.0, label: "7d", maxMove: { btc: 12.0, sp500: 6.0, gold: 5.0, oil: 7.0 } },
  "14D": { multiplier: 22.0, label: "14d", maxMove: { btc: 18.0, sp500: 9.0, gold: 7.5, oil: 10.0 } },
};

// Map each asset to relevant sources based on available markets
const ASSET_SOURCE_MAP: Record<string, string[]> = {
  btc: ["polymarket", "kalshi", "manifold", "metaculus"],
  sp500: ["polymarket", "kalshi"],
  gold: ["polymarket", "kalshi"],
  oil: ["polymarket"],
};

export function ForecastCard({
  label,
  variant,
  expectedMove,
  confidence,
  currentPrice,
  liveSources,
  sources,
  signalsProcessed,
  reliability = "medium",
  compact = false,
  globalEvent,
}: ForecastCardProps) {

  // Animated values for smooth transitions during refresh
  const animatedPrice = useAnimatedNumber(currentPrice, 600);
  const animatedConfidence = useAnimatedNumber(confidence, 600);
  const animatedExpectedMove = useAnimatedNumber(expectedMove, 600);

  // Get relevant sources for this asset
  const relevantSources = ASSET_SOURCE_MAP[variant] || [];
  const sourceEntries = relevantSources
    .map((name) => ({ name, count: sources?.[name as keyof typeof sources] || 0 }))
    .filter((s) => s.count > 0);
  const [timeframe, setTimeframe] = useState("1H");

  const tf = TIMEFRAME_CONFIG[timeframe];
  const rawScaledMove = animatedExpectedMove * tf.multiplier;
  const maxAllowed = tf.maxMove[variant];
  const adjustedMove = Math.max(-maxAllowed, Math.min(maxAllowed, rawScaledMove));

  const direction = adjustedMove > 0.05 ? "UP" : adjustedMove < -0.05 ? "DOWN" : "NEUTRAL";

  const config = {
    UP: { icon: TrendingUp, color: "text-bullish", bg: "bg-bullish", label: "BULLISH" },
    DOWN: { icon: TrendingDown, color: "text-bearish", bg: "bg-bearish", label: "BEARISH" },
    NEUTRAL: { icon: Minus, color: "text-neutral", bg: "bg-neutral", label: "NEUTRAL" },
  }[direction];

  const Icon = config.icon;
  const symbol = variant === "btc" ? "₿" : variant === "gold" ? "Au" : variant === "oil" ? "OIL" : "SPX";

  const formatPrice = (price: number) =>
    price >= 1000 ? `$${price.toLocaleString("en-US", { maximumFractionDigits: 0 })}` : `$${price.toFixed(2)}`;

  const relColor = reliability === "high" ? "text-bullish" : reliability === "low" ? "text-bearish" : "text-neutral";

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-card rounded-xl border border-border p-4 card-elevated min-h-[520px]"
    >
      <div className="flex items-center justify-between mb-1.5">
        <div className="flex items-center gap-1.5">
          <span className="text-foreground font-mono font-bold text-[9px] bg-secondary px-1.5 py-0.5 rounded">{symbol}</span>
          <span className="text-foreground font-bold text-[11px]">{label}</span>
        </div>
        <div className={`px-1.5 py-0.5 rounded text-[7px] font-bold uppercase tracking-wider ${config.bg}/15 ${config.color}`}>
          {config.label}
        </div>
      </div>

      <div className="mb-1.5">
        <span className="text-lg font-black text-foreground tabular-nums font-mono">{formatPrice(animatedPrice)}</span>
      </div>

      <div className="flex gap-0.5 mb-1.5 flex-wrap">
        {Object.keys(TIMEFRAME_CONFIG).map((tfKey) => (
          <button
            key={tfKey}
            onClick={() => setTimeframe(tfKey)}
            className={`px-1.5 py-0.5 rounded text-[7px] font-bold transition-colors ${
              timeframe === tfKey ? "bg-accent text-foreground" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {tfKey}
          </button>
        ))}
      </div>

      <div className="space-y-1">
        <div className="flex items-center justify-between">
          <span className="text-[8px] text-muted-foreground font-medium uppercase tracking-wide">Move</span>
          <div className="flex items-center gap-1">
            <Icon className={`w-3 h-3 ${config.color}`} />
            <span className={`text-sm font-black ${config.color} tabular-nums font-mono`}>
              {adjustedMove >= 0 ? "+" : ""}{adjustedMove.toFixed(2)}%
            </span>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-[8px] text-muted-foreground font-medium uppercase tracking-wide">Confidence</span>
          <span className="text-[10px] font-bold text-foreground tabular-nums font-mono">{animatedConfidence.toFixed(0)}%</span>
        </div>
        <div className="h-1 w-full bg-muted rounded-full overflow-hidden">
          <motion.div
            className={`h-full rounded-full ${animatedConfidence > 60 ? "bg-bullish" : animatedConfidence > 40 ? "bg-neutral" : "bg-bearish"}`}
            initial={{ width: 0 }}
            animate={{ width: `${animatedConfidence}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
        {!compact && (
          <div className="flex items-center justify-between">
            <span className="text-[8px] text-muted-foreground font-medium uppercase tracking-wide">Reliability</span>
            <span className={`text-[8px] font-bold uppercase ${relColor}`}>{reliability}</span>
          </div>
        )}
        {!compact && sourceEntries.length > 0 && (
          <div className="flex items-center justify-between">
            <span className="text-[8px] text-muted-foreground font-medium uppercase tracking-wide">Sources</span>
            <div className="flex items-center gap-1">
              {sourceEntries.map((s) => (
                <span key={s.name} className="text-[7px] font-medium text-foreground bg-secondary/60 px-1 rounded">
                  {s.name.charAt(0).toUpperCase() + s.name.slice(1)}:{s.count}
                </span>
              ))}
            </div>
          </div>
        )}
        {!compact && signalsProcessed !== undefined && signalsProcessed > 0 && (
          <div className="flex items-center justify-between">
            <span className="text-[8px] text-muted-foreground font-medium uppercase tracking-wide">Calc</span>
            <span className="text-[8px] font-bold text-foreground font-mono">{signalsProcessed.toLocaleString()}</span>
          </div>
        )}
      </div>

      <div className="mt-3">
        {globalEvent ? (
          <>
            <Heatmap scores={globalEvent.eventProbabilities} />
            <div className="text-[11px] mt-2">
              <div className="font-semibold">Event reliability: <span className="font-mono">{(globalEvent.overallReliability*100).toFixed(0)}%</span></div>
              <div className="text-[12px] mt-1">Top drivers:</div>
              <ul className="text-[11px] list-inside list-disc mt-1 text-muted-foreground">
                {(globalEvent.topEventDrivers || []).slice(0,3).map((d:any, i:number) => (
                  <li key={i}>{d.driver} · <span className="font-mono">{(d.p*100).toFixed(0)}%</span></li>
                ))}
              </ul>
            </div>
          </>
        ) : (
          <Heatmap intensity={1 - Math.max(0, Math.min(100, animatedConfidence)) / 100} />
        )}
      </div>
    </motion.div>
  );
}
