import { motion } from "framer-motion";
import type { PredictionConsensusData } from "@/hooks/usePredictionMarkets";

export function PredictionConsensus({ data }: { data: PredictionConsensusData }) {
  const sentimentLabel = data.consensus > 0.1 ? "Bullish" : data.consensus < -0.1 ? "Bearish" : "Neutral";
  const sentimentColor = data.consensus > 0.1 ? "text-bullish" : data.consensus < -0.1 ? "text-bearish" : "text-neutral";

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card rounded-2xl border border-border p-5 card-elevated"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-lg">🎯</span>
          <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Prediction Market Consensus</h2>
        </div>
        <span className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-md ${sentimentColor} bg-secondary`}>
          {sentimentLabel}
        </span>
      </div>

      <div className="flex items-end gap-4 mb-4">
        <div>
          <span className="text-3xl font-black tabular-nums font-mono tracking-tight text-foreground">{data.score}</span>
          <span className="text-sm text-muted-foreground font-medium ml-1">/ 100</span>
        </div>
        <div className="text-[11px] text-muted-foreground font-medium mb-1">
          {data.totalContracts} contracts · {data.platforms.length} platforms
        </div>
      </div>

      {/* Score bar */}
      <div className="w-full h-2 bg-accent rounded-full overflow-hidden mb-4">
        <motion.div
          className={`h-full rounded-full ${data.score > 55 ? "bg-bullish" : data.score < 45 ? "bg-bearish" : "bg-neutral"}`}
          initial={{ width: 0 }}
          animate={{ width: `${data.score}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />
      </div>

      {/* Divergence indicator */}
      {data.divergence > 0.2 && (
        <div className="bg-neutral/10 border border-neutral/20 rounded-lg px-3 py-2 mb-3">
          <span className="text-[10px] font-semibold text-neutral">
            ⚠️ Platform Divergence: {(data.divergence * 100).toFixed(0)}% — platforms disagree, confidence reduced
          </span>
        </div>
      )}

      {/* Platform breakdown */}
      <div className="space-y-1.5">
        {data.platforms.map((p, i) => (
          <div key={i} className="flex items-center justify-between text-[11px]">
            <div className="flex items-center gap-2">
              <span className="text-foreground font-semibold">{p.platform}</span>
              <span className="text-[9px] text-muted-foreground font-mono">{Math.round(p.weight * 100)}%w</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-muted-foreground font-mono">{p.signalCount} signals</span>
              <span className={`font-bold font-mono tabular-nums ${p.sentiment > 0.05 ? "text-bullish" : p.sentiment < -0.05 ? "text-bearish" : "text-muted-foreground"}`}>
                {p.sentiment > 0 ? "+" : ""}{(p.sentiment * 100).toFixed(0)}%
              </span>
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
