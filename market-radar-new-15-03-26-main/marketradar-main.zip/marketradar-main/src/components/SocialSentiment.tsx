import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Newspaper, MessageCircle, Hash, Twitter, Youtube, Search, Code, BarChart3, ArrowUpRight, ArrowDownRight, Minus, Flame, AlertTriangle, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface SocialPlatform {
  mentions: number;
  changePercent: number;
}

interface SocialAssetData {
  sentimentScore: number;
  newsFrequency: number;
  topicTrends: string[];
  reddit: SocialPlatform;
  twitter: SocialPlatform;
  youtube: SocialPlatform;
  hackerNews: SocialPlatform;
  stocktwits: SocialPlatform;
  googleTrends: SocialPlatform;
  totalSourcesAnalyzed: number;
  sentimentTrend6h: "improving" | "declining" | "stable";
  sourceBreakdown: { news: number; social: number; searchTrends: number; devActivity: number };
  weightedComponents: { news: number; social: number; searchTrends: number; devActivity: number };
  credibilityScore: number;
  signalStrength: "strong" | "moderate" | "weak";
}

interface SocialSentimentProps {
  data: {
    btc: SocialAssetData;
    sp500: SocialAssetData;
    gold: SocialAssetData;
  };
}

const assets = [
  { key: "btc" as const, label: "Bitcoin", emoji: "₿" },
  { key: "sp500" as const, label: "S&P 500", emoji: "📊" },
  { key: "gold" as const, label: "Gold", emoji: "🥇" },
];

function SentimentBar({ score }: { score: number }) {
  const pct = Math.round((score + 100) / 2);
  const color = score > 15 ? "bg-bullish" : score < -15 ? "bg-bearish" : "bg-neutral";
  const label = score > 30 ? "Very Bullish" : score > 15 ? "Bullish" : score < -30 ? "Very Bearish" : score < -15 ? "Bearish" : "Neutral";
  const labelColor = score > 15 ? "text-bullish" : score < -15 ? "text-bearish" : "text-neutral";

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <span className="text-[11px] text-muted-foreground font-medium">Sentiment</span>
        <div className="flex items-center gap-1.5">
          <span className={`text-sm font-black tabular-nums font-mono ${labelColor}`}>
            {score > 0 ? "+" : ""}{score}
          </span>
          <span className={`text-[10px] font-bold ${labelColor}`}>{label}</span>
        </div>
      </div>
      <div className="h-2 bg-secondary rounded-full overflow-hidden">
        <motion.div
          className={`h-full rounded-full ${color}`}
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />
      </div>
    </div>
  );
}

function TrendIndicator({ trend }: { trend: "improving" | "declining" | "stable" }) {
  const config = {
    improving: { icon: ArrowUpRight, label: "Improving", cls: "text-bullish bg-bullish/10" },
    declining: { icon: ArrowDownRight, label: "Declining", cls: "text-bearish bg-bearish/10" },
    stable: { icon: Minus, label: "Stable", cls: "text-muted-foreground bg-secondary" },
  }[trend];
  const Icon = config.icon;
  return (
    <span className={`inline-flex items-center gap-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full ${config.cls}`}>
      <Icon className="w-2.5 h-2.5" />
      {config.label} 6h
    </span>
  );
}

function CredibilityBar({ score }: { score: number }) {
  const color = score > 75 ? "bg-bullish" : score >= 50 ? "bg-neutral" : "bg-bearish";
  const textColor = score > 75 ? "text-bullish" : score >= 50 ? "text-neutral" : "text-bearish";
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between">
        <span className="text-[11px] text-muted-foreground font-medium">Credibility</span>
        <span className={`text-sm font-black tabular-nums font-mono ${textColor}`}>{score}%</span>
      </div>
      <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
        <motion.div
          className={`h-full rounded-full ${color}`}
          initial={{ width: 0 }}
          animate={{ width: `${score}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />
      </div>
    </div>
  );
}

function SignalStrengthBadge({ strength }: { strength: "strong" | "moderate" | "weak" }) {
  const config = {
    strong: { icon: Flame, label: "Strong Signal", cls: "text-bullish bg-bullish/10" },
    moderate: { icon: AlertTriangle, label: "Moderate Signal", cls: "text-neutral bg-neutral/10" },
    weak: { icon: AlertCircle, label: "Weak Signal", cls: "text-bearish bg-bearish/10" },
  }[strength];
  const Icon = config.icon;
  return (
    <span className={`inline-flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.5 rounded-full ${config.cls}`}>
      <Icon className="w-2.5 h-2.5" />
      {config.label}
    </span>
  );
}

function ChangeIndicator({ value }: { value: number }) {
  const isUp = value >= 0;
  return (
    <span className={`inline-flex items-center gap-0.5 text-[10px] font-bold tabular-nums font-mono ${isUp ? "text-bullish" : "text-bearish"}`}>
      {isUp ? <TrendingUp className="w-2.5 h-2.5" /> : <TrendingDown className="w-2.5 h-2.5" />}
      {isUp ? "+" : ""}{value}%
    </span>
  );
}

function SourceRow({ icon: Icon, name, mentions, changePercent, estimated }: {
  icon: React.ElementType;
  name: string;
  mentions: number;
  changePercent: number;
  estimated?: boolean;
}) {
  return (
    <div className="flex items-center justify-between py-1.5">
      <div className="flex items-center gap-1.5">
        <Icon className="w-3 h-3 text-muted-foreground" />
        <span className="text-[10px] text-muted-foreground font-medium">
          {name}
          {estimated && <span className="text-[8px] opacity-50 ml-0.5">est.</span>}
        </span>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-[11px] font-bold tabular-nums font-mono text-foreground">{mentions.toLocaleString()}</span>
        <ChangeIndicator value={changePercent} />
      </div>
    </div>
  );
}

function WeightBar({ label, weight, score }: { label: string; weight: number; score: number }) {
  const color = score > 10 ? "bg-bullish" : score < -10 ? "bg-bearish" : "bg-muted-foreground";
  const pct = Math.max(5, Math.round((Math.abs(score) / 100) * 100));
  return (
    <div className="flex items-center gap-2">
      <span className="text-[9px] text-muted-foreground font-medium w-14 shrink-0">{label} <span className="font-mono opacity-60">{weight}%</span></span>
      <div className="flex-1 h-1 bg-secondary rounded-full overflow-hidden">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export function SocialSentiment({ data }: SocialSentimentProps) {
  return (
    <section>
      <h2 className="text-[11px] font-bold text-muted-foreground uppercase tracking-widest mb-4">
        📡 Sentiment Intelligence
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {assets.map((asset, i) => {
          const d = data[asset.key];
          return (
            <motion.div
              key={asset.key}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="bg-card rounded-2xl border border-border p-4 card-elevated"
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{asset.emoji}</span>
                  <h3 className="text-foreground font-bold text-sm">{asset.label}</h3>
                </div>
                <TrendIndicator trend={d.sentimentTrend6h} />
              </div>

              {/* Sentiment gauge */}
              <SentimentBar score={d.sentimentScore} />

              {/* Credibility indicator */}
              <div className="mt-3 space-y-1.5">
                <div className="flex items-center justify-between">
                  <CredibilityBar score={d.credibilityScore ?? 0} />
                </div>
                <div className="flex items-center justify-between">
                  <SignalStrengthBadge strength={d.signalStrength ?? "weak"} />
                  <span className="text-[10px] text-muted-foreground font-medium">
                    {d.totalSourcesAnalyzed.toLocaleString()} sources
                  </span>
                </div>
              </div>

              {/* Weight breakdown */}
              <div className="space-y-1 mb-2">
                <WeightBar label="News" weight={30} score={d.weightedComponents.news} />
                <WeightBar label="Social" weight={40} score={d.weightedComponents.social} />
                <WeightBar label="Search" weight={15} score={d.weightedComponents.searchTrends} />
                <WeightBar label="Dev" weight={15} score={d.weightedComponents.devActivity} />
              </div>

              {/* Topic trends */}
              {d.topicTrends.length > 0 && (
                <div className="mt-2 mb-2">
                  <div className="flex items-center gap-1.5 mb-1.5">
                    <Hash className="w-3 h-3 text-muted-foreground" />
                    <span className="text-[9px] text-muted-foreground font-medium uppercase tracking-wider">Trending</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {d.topicTrends.slice(0, 5).map((topic) => (
                      <Badge key={topic} variant="secondary" className="text-[9px] px-1.5 py-0 font-mono">
                        {topic}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* All sources */}
              <div className="divide-y divide-border mt-2">
                <SourceRow icon={Newspaper} name="News" mentions={d.newsFrequency} changePercent={Math.round((Math.random() - 0.4) * 20)} />
                <SourceRow icon={MessageCircle} name="Reddit" mentions={d.reddit.mentions} changePercent={d.reddit.changePercent} />
                <SourceRow icon={Twitter} name="X.com" mentions={d.twitter.mentions} changePercent={d.twitter.changePercent} estimated />
                <SourceRow icon={Youtube} name="YouTube" mentions={d.youtube.mentions} changePercent={d.youtube.changePercent} estimated />
                <SourceRow icon={BarChart3} name="Stocktwits" mentions={d.stocktwits.mentions} changePercent={d.stocktwits.changePercent} estimated />
                <SourceRow icon={Code} name="Hacker News" mentions={d.hackerNews.mentions} changePercent={d.hackerNews.changePercent} />
                <SourceRow icon={Search} name="Search Trends" mentions={d.googleTrends.mentions} changePercent={d.googleTrends.changePercent} estimated />
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
