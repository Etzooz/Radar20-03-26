import { motion } from "framer-motion";

interface PredictionData {
  sp500: { value: number; label: string; direction: string };
  btc: { value: number; label: string; direction: string };
  confidence: number;
  signalsUsed: number;
}

const getLabelColor = (label: string) => {
  if (label.includes("Fear")) return "text-bearish";
  if (label.includes("Greed")) return "text-bullish";
  return "text-neutral";
};

export const PredictionSummary = ({ data }: { data: PredictionData }) => {
  return (
    <motion.div
      className="bg-card rounded-lg border border-border p-5"
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className="flex items-center gap-2 mb-4">
        <span className="text-xl">🔮</span>
        <h2 className="text-foreground font-semibold text-lg">Tomorrow's Prediction</h2>
        <span className="ml-2 px-2.5 py-0.5 rounded-full bg-primary/15 text-primary text-xs font-semibold border border-primary/30">
          AI Forecast
        </span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="text-center">
          <p className="text-muted-foreground text-xs mb-1">S&P 500 F&G</p>
          <p className="text-2xl font-mono font-bold text-foreground">{data.sp500.value}</p>
          <p className={`text-xs font-medium ${getLabelColor(data.sp500.label)}`}>
            {data.sp500.label} → {data.sp500.direction}
          </p>
        </div>
        <div className="text-center">
          <p className="text-muted-foreground text-xs mb-1">BTC F&G</p>
          <p className="text-2xl font-mono font-bold text-foreground">{data.btc.value}</p>
          <p className={`text-xs font-medium ${getLabelColor(data.btc.label)}`}>
            {data.btc.label} → {data.btc.direction}
          </p>
        </div>
        <div className="text-center">
          <p className="text-muted-foreground text-xs mb-1">Confidence</p>
          <p className="text-2xl font-mono font-bold text-foreground">{data.confidence}%</p>
          <p className="text-xs font-medium text-bullish">High</p>
        </div>
        <div className="text-center">
          <p className="text-muted-foreground text-xs mb-1">Signals Used</p>
          <p className="text-2xl font-mono font-bold text-foreground">{data.signalsUsed}</p>
          <p className="text-xs font-medium text-muted-foreground">Markets + Indicators</p>
        </div>
      </div>
    </motion.div>
  );
};
