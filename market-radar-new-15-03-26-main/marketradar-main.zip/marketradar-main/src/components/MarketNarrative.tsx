import { motion } from "framer-motion";
import { Bot } from "lucide-react";

interface MarketNarrativeProps {
  narrative: string;
}

export function MarketNarrative({ narrative }: MarketNarrativeProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card rounded-2xl border border-border p-5 card-elevated"
    >
      <div className="flex items-center gap-2 mb-3">
        <Bot className="w-4 h-4 text-muted-foreground" />
        <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-widest">AI Market Narrative</h2>
      </div>
      <p className="text-[13px] text-foreground leading-relaxed font-medium">
        {narrative}
      </p>
    </motion.div>
  );
}
