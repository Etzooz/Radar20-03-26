import { motion } from "framer-motion";
import { Activity } from "lucide-react";
import type { VolatilityContext as VolContextType } from "@/hooks/usePredictionMarkets";

const assets = [
  { key: "btc" as const, label: "BTC", emoji: "₿" },
  { key: "sp500" as const, label: "S&P 500", emoji: "📊" },
  { key: "gold" as const, label: "Gold", emoji: "🥇" },
];

export function VolatilityContextPanel({ data }: { data: VolContextType }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card rounded-2xl border border-border p-5 card-elevated"
    >
      <div className="flex items-center gap-2 mb-4">
        <Activity className="w-4 h-4 text-muted-foreground" />
        <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Market Volatility</h2>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {assets.map((asset) => {
          const vol = data[asset.key];
          return (
            <div key={asset.key} className="bg-secondary/60 rounded-lg p-3 text-center">
              <span className="text-sm">{asset.emoji}</span>
              <p className="text-[10px] text-muted-foreground font-semibold uppercase mt-1">{asset.label}</p>
              <div className="mt-2 space-y-1">
                <div className="flex justify-between text-[10px]">
                  <span className="text-muted-foreground">1H</span>
                  <span className="font-mono font-bold text-foreground tabular-nums">{vol.hourly.toFixed(2)}%</span>
                </div>
                <div className="flex justify-between text-[10px]">
                  <span className="text-muted-foreground">24H</span>
                  <span className="font-mono font-bold text-foreground tabular-nums">{vol.daily.toFixed(2)}%</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
}
