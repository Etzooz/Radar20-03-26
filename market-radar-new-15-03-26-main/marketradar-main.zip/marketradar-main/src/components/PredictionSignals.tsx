import { motion } from "framer-motion";

interface Signal {
  title: string;
  sentiment: number;
  probability: number;
  volume: string;
  source: string;
}

const getSentimentLabel = (s: number) =>
  s >= 0.4 ? "Bullish" : s <= -0.4 ? "Bearish" : "Neutral";

const getSentimentStyle = (s: number) => {
  if (s >= 0.4) return "bg-bullish/15 text-bullish border-bullish/30";
  if (s <= -0.4) return "bg-bearish/15 text-bearish border-bearish/30";
  return "bg-neutral/15 text-neutral border-neutral/30";
};

const getBarColor = (s: number) => {
  if (s >= 0.4) return "bg-bullish";
  if (s <= -0.4) return "bg-bearish";
  return "bg-neutral";
};

export const PredictionSignals = ({ signals }: { signals: Signal[] }) => {
  return (
    <div className="bg-card rounded-lg border border-border p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-foreground font-semibold text-lg flex items-center gap-2">
          <span>📊</span> Prediction Market Signals
        </h3>
        <span className="flex items-center gap-1.5 text-xs text-bullish font-mono">
          <span className="w-1.5 h-1.5 rounded-full bg-bullish animate-pulse-glow" />
          LIVE
        </span>
      </div>

      <div className="space-y-3">
        {signals.map((signal, i) => (
          <motion.div
            key={i}
            className="bg-secondary/50 rounded-md p-3.5"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <div className="flex items-start justify-between gap-3 mb-2">
              <p className="text-foreground text-sm font-medium leading-snug">{signal.title}</p>
              <span className={`shrink-0 px-2 py-0.5 rounded text-xs font-semibold border ${getSentimentStyle(signal.sentiment)}`}>
                {signal.sentiment > 0 ? "+" : ""}{signal.sentiment.toFixed(2)} · {getSentimentLabel(signal.sentiment)}
              </span>
            </div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground font-mono mb-2">
              <span>Prob: <span className="text-foreground">{signal.probability}%</span></span>
              <span>Vol: <span className="text-foreground">{signal.volume}</span></span>
              <span className="ml-auto">{signal.source}</span>
            </div>
            <div className="w-full h-1 bg-secondary rounded-full overflow-hidden">
              <motion.div
                className={`h-full rounded-full ${getBarColor(signal.sentiment)}`}
                initial={{ width: 0 }}
                animate={{ width: `${signal.probability}%` }}
                transition={{ duration: 0.8, delay: 0.3 + i * 0.1 }}
              />
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
