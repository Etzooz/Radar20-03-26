import { motion } from "framer-motion";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from "recharts";

// --- Types ---

export interface WhaleTransaction {
  id: string;
  asset: "BTC" | "ETH" | "SOL";
  type: "accumulation" | "selling" | "exchange_inflow" | "exchange_outflow";
  amountUsd: number;
  exchange: string;
  timestamp: string;
}

export interface WhaleScoreData {
  btc: number;
  eth: number;
  sol: number;
}

export interface WhaleHeatmapCell {
  hour: string;
  btc: number;
  eth: number;
  sol: number;
}

export interface WhaleData {
  transactions: WhaleTransaction[];
  scores: WhaleScoreData;
  heatmap: WhaleHeatmapCell[];
  summary: {
    totalVolume24h: number;
    netFlow: number;
    dominantActivity: string;
  };
}

// --- Helpers ---

const typeLabels: Record<string, { label: string; icon: string; color: string }> = {
  accumulation: { label: "Accumulation", icon: "🟢", color: "text-bullish" },
  selling: { label: "Selling", icon: "🔴", color: "text-bearish" },
  exchange_inflow: { label: "Exchange Inflow", icon: "➡️", color: "text-neutral" },
  exchange_outflow: { label: "Exchange Outflow", icon: "⬅️", color: "text-bullish" },
};

const assetColors: Record<string, string> = {
  BTC: "hsl(var(--bullish))",
  ETH: "hsl(var(--neutral))",
  SOL: "hsl(152 60% 55%)",
};

function formatUsd(v: number): string {
  if (v >= 1e9) return `$${(v / 1e9).toFixed(1)}B`;
  if (v >= 1e6) return `$${(v / 1e6).toFixed(1)}M`;
  if (v >= 1e3) return `$${(v / 1e3).toFixed(0)}K`;
  return `$${v.toFixed(0)}`;
}

// --- Sub-components ---

function WhaleScoreGauge({ asset, score }: { asset: string; score: number }) {
  const label = score >= 70 ? "Strong Buy" : score >= 55 ? "Accumulating" : score >= 45 ? "Neutral" : score >= 30 ? "Distributing" : "Strong Sell";
  const color = score >= 55 ? "text-bullish" : score <= 45 ? "text-bearish" : "text-muted-foreground";
  const barColor = score >= 55 ? "bg-bullish" : score <= 45 ? "bg-bearish" : "bg-neutral";

  return (
    <div className="flex-1 min-w-0">
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-xs font-semibold text-foreground">{asset}</span>
        <span className={`text-xs font-bold font-mono ${color}`}>{score}</span>
      </div>
      <div className="h-2 bg-secondary rounded-full overflow-hidden">
        <motion.div
          className={`h-full rounded-full ${barColor}`}
          initial={{ width: 0 }}
          animate={{ width: `${score}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />
      </div>
      <p className={`text-[10px] mt-1 font-medium ${color}`}>{label}</p>
    </div>
  );
}

function WhaleTransactionRow({ tx, index }: { tx: WhaleTransaction; index: number }) {
  const meta = typeLabels[tx.type] ?? typeLabels.accumulation;
  return (
    <motion.div
      className="flex items-center gap-3 py-2.5 border-b border-border last:border-0"
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
    >
      <span className="text-sm">{meta.icon}</span>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-bold text-foreground">{tx.asset}</span>
          <span className={`text-[10px] font-medium ${meta.color}`}>{meta.label}</span>
        </div>
        <p className="text-[10px] text-muted-foreground truncate">{tx.exchange}</p>
      </div>
      <div className="text-right">
        <p className="text-xs font-bold font-mono text-foreground">{formatUsd(tx.amountUsd)}</p>
        <p className="text-[10px] text-muted-foreground font-mono">{tx.timestamp}</p>
      </div>
    </motion.div>
  );
}

// --- Main Exports ---

export function WhaleActivityDashboard({ transactions, summary }: { transactions: WhaleTransaction[]; summary: WhaleData["summary"] }) {
  return (
    <div className="bg-card rounded-lg border border-border p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-foreground font-semibold text-sm flex items-center gap-2">
            <span>🐋</span> Whale Activity
          </h3>
          <p className="text-muted-foreground text-[10px] mt-0.5">Large transactions &gt; $1M · Monitored exchanges</p>
        </div>
        <div className="flex items-center gap-3 text-[10px]">
          <div className="text-right">
            <p className="text-muted-foreground">24h Volume</p>
            <p className="font-bold font-mono text-foreground">{formatUsd(summary.totalVolume24h)}</p>
          </div>
          <div className="text-right">
            <p className="text-muted-foreground">Net Flow</p>
            <p className={`font-bold font-mono ${summary.netFlow >= 0 ? "text-bullish" : "text-bearish"}`}>
              {summary.netFlow >= 0 ? "+" : ""}{formatUsd(Math.abs(summary.netFlow))}
            </p>
          </div>
        </div>
      </div>

      {/* Exchange badges */}
      <div className="flex gap-1.5 mb-3">
        {["Binance", "Coinbase", "Kraken"].map((ex) => (
          <span key={ex} className="text-[10px] font-medium bg-secondary text-secondary-foreground px-2 py-0.5 rounded-md">
            {ex}
          </span>
        ))}
      </div>

      {/* Transaction list */}
      <div className="max-h-[280px] overflow-y-auto">
        {transactions.length === 0 ? (
          <p className="text-muted-foreground text-xs text-center py-8">No whale activity detected</p>
        ) : (
          transactions.slice(0, 10).map((tx, i) => (
            <WhaleTransactionRow key={tx.id} tx={tx} index={i} />
          ))
        )}
      </div>
    </div>
  );
}

export function WhaleScorePanel({ scores }: { scores: WhaleScoreData }) {
  return (
    <div className="bg-card rounded-lg border border-border p-5">
      <h3 className="text-foreground font-semibold text-sm flex items-center gap-2 mb-1">
        <span>📊</span> Whale Score
      </h3>
      <p className="text-muted-foreground text-[10px] mb-4">
        Composite score based on whale accumulation vs distribution patterns
      </p>
      <div className="flex gap-4">
        <WhaleScoreGauge asset="BTC" score={scores.btc} />
        <WhaleScoreGauge asset="ETH" score={scores.eth} />
        <WhaleScoreGauge asset="SOL" score={scores.sol} />
      </div>
    </div>
  );
}

export function WhaleChartMarkers({ transactions }: { transactions: WhaleTransaction[] }) {
  // Group by asset and show volume over time
  const assets = ["BTC", "ETH", "SOL"] as const;
  const chartData = assets.map((asset) => {
    const assetTxs = transactions.filter((t) => t.asset === asset);
    const accumulation = assetTxs.filter((t) => t.type === "accumulation" || t.type === "exchange_outflow")
      .reduce((s, t) => s + t.amountUsd, 0);
    const distribution = assetTxs.filter((t) => t.type === "selling" || t.type === "exchange_inflow")
      .reduce((s, t) => s + t.amountUsd, 0);
    return { asset, accumulation: accumulation / 1e6, distribution: distribution / 1e6 };
  });

  return (
    <div className="bg-card rounded-lg border border-border p-5">
      <h3 className="text-foreground font-semibold text-sm flex items-center gap-2 mb-1">
        <span>📍</span> Whale Flow Chart
      </h3>
      <p className="text-muted-foreground text-[10px] mb-4">Accumulation vs Distribution volume ($M)</p>
      <div className="h-[180px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} barGap={4}>
            <XAxis dataKey="asset" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={35} tickFormatter={(v) => `$${v}M`} />
            <Tooltip
              contentStyle={{
                background: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                fontSize: "11px",
              }}
              formatter={(value: number) => [`$${value.toFixed(1)}M`]}
            />
            <Bar dataKey="accumulation" name="Accumulation" radius={[4, 4, 0, 0]} maxBarSize={40}>
              {chartData.map((_, i) => (
                <Cell key={i} fill="hsl(var(--bullish))" opacity={0.8} />
              ))}
            </Bar>
            <Bar dataKey="distribution" name="Distribution" radius={[4, 4, 0, 0]} maxBarSize={40}>
              {chartData.map((_, i) => (
                <Cell key={i} fill="hsl(var(--bearish))" opacity={0.8} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export function WhaleAccumulationHeatmap({ heatmap }: { heatmap: WhaleHeatmapCell[] }) {
  if (heatmap.length === 0) {
    return (
      <div className="bg-card rounded-lg border border-border p-5">
        <h3 className="text-foreground font-semibold text-sm flex items-center gap-2 mb-1">
          <span>🔥</span> Accumulation Heatmap
        </h3>
        <p className="text-muted-foreground text-xs text-center py-8">No heatmap data yet</p>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-lg border border-border p-5">
      <h3 className="text-foreground font-semibold text-sm flex items-center gap-2 mb-1">
        <span>🔥</span> Accumulation Heatmap
      </h3>
      <p className="text-muted-foreground text-[10px] mb-4">Whale accumulation intensity by hour (24h)</p>
      <div className="h-[160px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={heatmap}>
            <XAxis
              dataKey="hour"
              tick={{ fontSize: 9, fill: "hsl(var(--muted-foreground))" }}
              axisLine={false}
              tickLine={false}
              interval={3}
            />
            <YAxis hide />
            <Tooltip
              contentStyle={{
                background: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                fontSize: "11px",
              }}
              formatter={(value: number) => [`${value.toFixed(0)}`, ""]}
            />
            <Area type="monotone" dataKey="btc" name="BTC" stroke="hsl(var(--bullish))" fill="hsl(var(--bullish))" fillOpacity={0.15} strokeWidth={2} dot={false} />
            <Area type="monotone" dataKey="eth" name="ETH" stroke="hsl(var(--neutral))" fill="hsl(var(--neutral))" fillOpacity={0.1} strokeWidth={2} dot={false} />
            <Area type="monotone" dataKey="sol" name="SOL" stroke="hsl(152 60% 55%)" fill="hsl(152 60% 55%)" fillOpacity={0.1} strokeWidth={1.5} dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <div className="flex items-center justify-center gap-4 mt-2 text-[10px] text-muted-foreground">
        <span className="flex items-center gap-1"><span className="w-3 h-0.5 rounded-full bg-bullish inline-block" /> BTC</span>
        <span className="flex items-center gap-1"><span className="w-3 h-0.5 rounded-full bg-neutral inline-block" /> ETH</span>
        <span className="flex items-center gap-1"><span className="w-3 h-0.5 rounded-full" style={{ background: "hsl(152 60% 55%)" }} /> SOL</span>
      </div>
    </div>
  );
}
