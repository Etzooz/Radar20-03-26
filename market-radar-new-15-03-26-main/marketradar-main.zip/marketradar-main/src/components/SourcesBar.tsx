import { motion } from "framer-motion";

interface SourceBadge {
  name: string;
  count: number;
  type: string;
  status: string;
}

export const SourcesBar = ({ sources }: { sources: SourceBadge[] }) => {
  return (
    <div className="flex flex-wrap gap-2">
      {sources.map((s, i) => (
        <motion.div
          key={s.name}
          className="bg-secondary/80 rounded-md px-3 py-1.5 flex items-center gap-2 text-xs border border-border"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: i * 0.1 }}
        >
          <span className={`w-1.5 h-1.5 rounded-full ${s.count > 0 ? "bg-bullish" : "bg-muted-foreground"}`} />
          <span className="text-foreground font-medium">{s.name}</span>
          <span className="text-muted-foreground font-mono">{s.count}</span>
          <span className="text-muted-foreground">·</span>
          <span className="text-muted-foreground">{s.type}</span>
        </motion.div>
      ))}
    </div>
  );
};
