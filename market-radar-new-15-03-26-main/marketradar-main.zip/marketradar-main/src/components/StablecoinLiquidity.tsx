import { motion } from "framer-motion";


export interface StablecoinFlowEvent {
  id: string;
  coin: "USDT" | "USDC";
  type: "mint" | "inflow" | "outflow";
  amountUsd: number;
  exchange: string;
  timestamp: string;
}

export interface StablecoinFlowBar {
  label: string;
  value: number;
  type: "inflow" | "outflow";
}

export interface StablecoinTimelineMarker {
  time: string;
  usdt_inflow: number;
  usdt_outflow: number;
  usdc_inflow: number;
  usdc_outflow: number;
}

export interface StablecoinData {
  events: StablecoinFlowEvent[];
  flowBars: StablecoinFlowBar[];
  timeline: StablecoinTimelineMarker[];
  liquidityScore: number;
  liquidityTrend: "Bullish" | "Neutral" | "Bearish";
  usdtMinted24h: number;
  usdtNetFlow: number;
  usdcNetFlow: number;
}

function formatM(v: number): string {
  if (Math.abs(v) >= 1e9) return `$${(v / 1e9).toFixed(1)}B`;
  if (Math.abs(v) >= 1e6) return `$${(v / 1e6).toFixed(0)}M`;
  if (Math.abs(v) >= 1e3) return `$${(v / 1e3).toFixed(0)}K`;
  return `$${v.toFixed(0)}`;
}

const trendColor = (t: string) =>
  t === "Bullish" ? "text-bullish" : t === "Bearish" ? "text-bearish" : "text-neutral";

const trendBg = (t: string) =>
  t === "Bullish" ? "bg-bullish/15" : t === "Bearish" ? "bg-bearish/15" : "bg-neutral/15";

// --- 1. Dashboard Widget ---
export const StablecoinDashboard = ({ data }: { data: StablecoinData }) => {
  const flowSign = (v: number) => (v >= 0 ? "+" : "") + formatM(v);

  return (
    <motion.div
      className="bg-card rounded-lg border border-border p-5"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <h3 className="text-foreground font-semibold text-lg flex items-center gap-2 mb-1">
        <span>💧</span> Stablecoin Liquidity
      </h3>
      <p className="text-muted-foreground text-xs mb-4">USDT & USDC exchange flows · updated every 5 min</p>

      <div className="grid grid-cols-2 gap-3">
        {/* USDT Minted */}
        <div className="bg-secondary/60 rounded-md p-3">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">USDT Minted (24h)</p>
          <p className="text-foreground font-mono font-bold text-sm mt-1">{formatM(data.usdtMinted24h)}</p>
          {data.usdtMinted24h > 200_000_000 && (
            <span className="text-[10px] text-bullish font-medium">🔥 Strong bullish</span>
          )}
          {data.usdtMinted24h > 50_000_000 && data.usdtMinted24h <= 200_000_000 && (
            <span className="text-[10px] text-bullish font-medium">Bullish liquidity</span>
          )}
        </div>

        {/* Liquidity Trend */}
        <div className={`rounded-md p-3 ${trendBg(data.liquidityTrend)}`}>
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Liquidity Trend</p>
          <p className={`font-bold text-sm mt-1 ${trendColor(data.liquidityTrend)}`}>{data.liquidityTrend}</p>
          <p className="text-[10px] text-muted-foreground font-mono">Score: {data.liquidityScore}</p>
        </div>

        {/* USDT Exchange Flow */}
        <div className="bg-secondary/60 rounded-md p-3">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">USDT Exchange Flow</p>
          <p className={`font-mono font-bold text-sm mt-1 ${data.usdtNetFlow >= 0 ? "text-bullish" : "text-bearish"}`}>
            {flowSign(data.usdtNetFlow)}
          </p>
        </div>

        {/* USDC Exchange Flow */}
        <div className="bg-secondary/60 rounded-md p-3">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">USDC Exchange Flow</p>
          <p className={`font-mono font-bold text-sm mt-1 ${data.usdcNetFlow >= 0 ? "text-bullish" : "text-bearish"}`}>
            {flowSign(data.usdcNetFlow)}
          </p>
        </div>
      </div>
    </motion.div>
  );
};

// --- 2. Flow Heatmap ---
export const StablecoinFlowHeatmap = ({ bars }: { bars: StablecoinFlowBar[] }) => {
  const maxVal = Math.max(...bars.map((b) => Math.abs(b.value)), 1);

  return (
    <motion.div
      className="bg-card rounded-lg border border-border p-5"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.05 }}
    >
      <h3 className="text-foreground font-semibold text-lg flex items-center gap-2 mb-1">
        <span>🗺️</span> Stablecoin Flow Heatmap
      </h3>
      <p className="text-muted-foreground text-xs mb-4">Bar width = flow magnitude · Green = inflow · Red = outflow</p>

      <div className="space-y-2.5">
        {bars.map((bar, i) => {
          const pct = Math.round((Math.abs(bar.value) / maxVal) * 100);
          const isInflow = bar.type === "inflow";
          const label =
            pct > 75
              ? isInflow ? "Strong inflow" : "Strong outflow"
              : pct > 40
                ? isInflow ? "Medium inflow" : "Moderate outflow"
                : isInflow ? "Low inflow" : "Low outflow";

          return (
            <motion.div
              key={bar.label}
              className="flex items-center gap-3"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <span className="text-xs text-muted-foreground font-medium w-24 shrink-0 truncate">{bar.label}</span>
              <div className="flex-1 h-4 bg-secondary rounded-sm overflow-hidden">
                <motion.div
                  className={`h-full rounded-sm ${isInflow ? "bg-bullish" : "bg-bearish"}`}
                  initial={{ width: 0 }}
                  animate={{ width: `${pct}%` }}
                  transition={{ duration: 0.6, delay: i * 0.08 }}
                />
              </div>
              <span className={`text-[10px] font-medium w-24 text-right ${isInflow ? "text-bullish" : "text-bearish"}`}>
                {label}
              </span>
            </motion.div>
          );
        })}
      </div>

      <div className="flex items-center justify-between mt-3 text-[10px] text-muted-foreground font-mono">
        <span className="flex items-center gap-1"><span className="w-3 h-1.5 rounded-sm bg-bearish inline-block" /> Outflow</span>
        <span className="flex items-center gap-1"><span className="w-3 h-1.5 rounded-sm bg-secondary inline-block" /> Neutral</span>
        <span className="flex items-center gap-1"><span className="w-3 h-1.5 rounded-sm bg-bullish inline-block" /> Inflow</span>
      </div>
    </motion.div>
  );
};

// --- 3. Liquidity Score Gauge ---
export const StablecoinLiquidityScore = ({ score, trend }: { score: number; trend: string }) => {
  // Score range roughly -10 to +10
  const normalized = Math.max(0, Math.min(100, (score + 10) * 5));

  return (
    <motion.div
      className="bg-card rounded-lg border border-border p-5"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
    >
      <h3 className="text-foreground font-semibold text-lg flex items-center gap-2 mb-1">
        <span>📊</span> Liquidity Score
      </h3>
      <p className="text-muted-foreground text-xs mb-4">Composite score based on mint events + exchange flows</p>

      <div className="flex items-center gap-4">
        {/* Gauge bar */}
        <div className="flex-1">
          <div className="h-3 rounded-full bg-secondary overflow-hidden">
            <motion.div
              className={`h-full rounded-full ${normalized > 60 ? "bg-bullish" : normalized < 40 ? "bg-bearish" : "bg-neutral"}`}
              initial={{ width: 0 }}
              animate={{ width: `${normalized}%` }}
              transition={{ duration: 0.8 }}
            />
          </div>
          <div className="flex justify-between mt-1 text-[10px] text-muted-foreground font-mono">
            <span>Bearish</span>
            <span>Neutral</span>
            <span>Bullish</span>
          </div>
        </div>

        <div className="text-center shrink-0">
          <p className={`text-2xl font-mono font-black ${trendColor(trend)}`}>{score > 0 ? "+" : ""}{score}</p>
          <p className={`text-xs font-semibold ${trendColor(trend)}`}>{trend}</p>
        </div>
      </div>
    </motion.div>
  );
};

// --- 4. Accumulation Heatmap ---
export const StablecoinAccumulationHeatmap = ({ timeline }: { timeline: StablecoinTimelineMarker[] }) => {
  // Compute net flow per time slot and map to intensity
  const heatData = timeline.map((t) => {
    const netFlow = (t.usdt_inflow + t.usdc_inflow) - (t.usdt_outflow + t.usdc_outflow);
    return { time: t.time, netFlow };
  });
  const maxAbs = Math.max(...heatData.map((d) => Math.abs(d.netFlow)), 1);

  const getIntensity = (net: number) => {
    const ratio = net / maxAbs;
    if (ratio > 0.6) return { bg: "bg-bullish", opacity: "opacity-90", label: "Strong inflow" };
    if (ratio > 0.3) return { bg: "bg-bullish", opacity: "opacity-50", label: "Moderate inflow" };
    if (ratio > 0.05) return { bg: "bg-bullish", opacity: "opacity-25", label: "Light inflow" };
    if (ratio < -0.6) return { bg: "bg-bearish", opacity: "opacity-90", label: "Strong outflow" };
    if (ratio < -0.3) return { bg: "bg-bearish", opacity: "opacity-50", label: "Moderate outflow" };
    if (ratio < -0.05) return { bg: "bg-bearish", opacity: "opacity-25", label: "Light outflow" };
    return { bg: "bg-secondary", opacity: "opacity-100", label: "Neutral" };
  };

  return (
    <motion.div
      className="bg-card rounded-lg border border-border p-5"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.15 }}
    >
      <h3 className="text-foreground font-semibold text-lg flex items-center gap-2 mb-1">
        <span>🔥</span> Stablecoin Accumulation Heatmap
      </h3>
      <p className="text-muted-foreground text-xs mb-4">24h net flow intensity · Green = accumulation · Red = distribution</p>

      <div className="grid grid-cols-6 sm:grid-cols-8 md:grid-cols-12 gap-1.5">
        {heatData.map((d, i) => {
          const info = getIntensity(d.netFlow);
          return (
            <motion.div
              key={d.time}
              className="group relative"
              initial={{ opacity: 0, scale: 0.7 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.02, type: "spring", stiffness: 300 }}
            >
              <div
                className={`aspect-square rounded-md ${info.bg} ${info.opacity} border border-border/30 cursor-pointer transition-transform group-hover:scale-110`}
              />
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 hidden group-hover:block z-10">
                <div className="bg-popover border border-border rounded-md px-2 py-1 shadow-md whitespace-nowrap">
                  <p className="text-[10px] font-mono text-foreground">{d.time}</p>
                  <p className={`text-[10px] font-semibold ${d.netFlow >= 0 ? "text-bullish" : "text-bearish"}`}>
                    {d.netFlow >= 0 ? "+" : ""}{formatM(d.netFlow)}
                  </p>
                  <p className="text-[9px] text-muted-foreground">{info.label}</p>
                </div>
              </div>
              <p className="text-[8px] text-muted-foreground text-center mt-0.5 truncate">{i % 3 === 0 ? d.time : ""}</p>
            </motion.div>
          );
        })}
      </div>

      <div className="flex items-center justify-between mt-3 text-[10px] text-muted-foreground font-mono">
        <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-bearish/90 inline-block" /> Outflow</span>
        <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-bearish/25 inline-block" /> Light out</span>
        <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-secondary inline-block" /> Neutral</span>
        <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-bullish/25 inline-block" /> Light in</span>
        <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-bullish/90 inline-block" /> Inflow</span>
      </div>
    </motion.div>
  );
};
