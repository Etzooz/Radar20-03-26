// Aggregate prediction markets expected oil price estimator
// Usage: node src/polymarket_oil.js
// Fetches oil-related markets from multiple prediction market platforms (Polymarket, PredictIt, Manifold)
// and computes a heuristic expected price by treating binary "> threshold" markets as samples of the
// survival function (P(price > threshold)).

async function fetchJson(url) {
  try {
    const res = await fetch(url, { headers: { 'Accept': 'application/json', 'User-Agent': 'market-oracle/1.0' } });
    if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
    return await res.json();
  } catch (e) {
    return null;
  }
}

function extractThreshold(title) {
  if (!title) return null;
  // Try to extract dollar threshold like "$70", "70 USD", "above 70", ">70"
  const dollar = title.match(/\$\s*([0-9]+(?:\.[0-9]+)?)/);
  if (dollar) return parseFloat(dollar[1]);
  const above = title.match(/(?:above|over|greater than|>=|>|more than)\s*\$?\s*([0-9]+(?:\.[0-9]+)?)/i);
  if (above) return parseFloat(above[1]);
  const plain = title.match(/\b([0-9]{2,3}(?:\.[0-9]+)?)\b\s*(?:usd|dollars|\$)?/i);
  if (plain) return parseFloat(plain[1]);
  return null;
}

function probabilityFromMarket(m) {
  // Try many common fields across platforms and normalize to 0..1
  const tries = [];
  if (!m) return null;
  // Polymarket style
  if (m.probability != null) tries.push(m.probability);
  if (m.lastTradePrice != null) tries.push(m.lastTradePrice);
  if (m.lastPrice != null) tries.push(m.lastPrice);
  if (m.bestBid != null) tries.push(m.bestBid);
  if (m.prob != null) tries.push(m.prob);
  // PredictIt: contracts have lastTradePrice
  if (m.lastTradePricePercent != null) tries.push(m.lastTradePricePercent);
  // Manifold: 'probability' or 'lastProb'
  if (m.probabilityRaw != null) tries.push(m.probabilityRaw);
  if (m.probability != null) tries.push(m.probability);
  // Contracts inside market
  if (Array.isArray(m.contracts)) {
    for (const c of m.contracts) {
      if (c.lastTradePrice != null) tries.push(c.lastTradePrice);
      if (c.probability != null) tries.push(c.probability);
      if (c.bestBuyYesCost != null) tries.push(c.bestBuyYesCost);
      if (c.bid != null) tries.push(c.bid);
    }
  }

  for (const t of tries) {
    if (t == null) continue;
    const n = Number(t);
    if (isNaN(n)) continue;
    // normalize
    if (n > 1) return n / 100;
    if (n >= 0 && n <= 1) return n;
  }
  return null;
}

async function fetchPolymarket() {
  const endpoints = [
    'https://api.polymarket.com/v1/markets?search=oil&limit=200',
    'https://polymarket.com/api/markets?search=oil&limit=200',
  ];
  for (const url of endpoints) {
    const d = await fetchJson(url);
    if (!d) continue;
    let arr = null;
    if (Array.isArray(d)) arr = d;
    if (Array.isArray(d.markets)) arr = d.markets;
    if (Array.isArray(d.results)) arr = d.results;
    if (!arr) continue;
    return arr.map(m => ({
      source: 'polymarket',
      id: m.id || m.slug || null,
      title: m.title || m.name || m.description || '',
      probability: probabilityFromMarket(m),
      raw: m
    }));
  }
  return [];
}

async function fetchPredictIt() {
  // PredictIt's market data endpoint
  const url = 'https://www.predictit.org/api/marketdata/all/';
  const d = await fetchJson(url);
  if (!d) return [];
  // PredictIt returns an object with Markets array
  const markets = d.Markets || d.markets || d;
  if (!Array.isArray(markets)) return [];
  const out = [];
  for (const m of markets) {
    // Each market has Contracts array
    if (!Array.isArray(m.Contracts) && !Array.isArray(m.contracts)) continue;
    const contracts = m.Contracts || m.contracts || [];
    for (const c of contracts) {
      const title = `${m.Name || m.name || ''} ${c.Name || c.name || ''}`.trim();
      const prob = probabilityFromMarket(c) || probabilityFromMarket(m);
      out.push({ source: 'predictit', id: `${m.MarketId || m.marketId || m.id || ''}:${c.ContractId || c.contractId || c.id || ''}`, title, probability: prob, raw: c });
    }
  }
  return out;
}

async function fetchManifold() {
  // Use Manifold search endpoint
  const url = 'https://manifold.markets/api/v0/search?q=oil&limit=200';
  const d = await fetchJson(url);
  if (!d || !Array.isArray(d)) return [];
  return d.map(m => ({
    source: 'manifold',
    id: m.id || m.slug || null,
    title: m.question || m.title || m.name || '',
    probability: probabilityFromMarket(m) || m.probability || m.probabilityRaw,
    raw: m
  }));
}

async function gatherAll() {
  const all = [];
  const [poly, predictit, manifold] = await Promise.all([
    fetchPolymarket(),
    fetchPredictIt(),
    fetchManifold()
  ]);
  all.push(...(poly || []));
  all.push(...(predictit || []));
  all.push(...(manifold || []));
  // Filter null probabilities
  return all.filter(x => x && x.title && x.probability != null && !isNaN(x.probability)).map(x => ({
    ...x,
    probability: x.probability > 1 ? x.probability / 100 : x.probability,
    threshold: extractThreshold(x.title)
  })).filter(x => x.threshold != null);
}

function groupByDateHint(items) {
  const groups = new Map();
  for (const c of items) {
    const m = c.raw || {};
    // try common date fields
    const hints = [];
    if (m.closeTime) hints.push(new Date(m.closeTime).toISOString().slice(0,10));
    if (m.closesAt) hints.push(new Date(m.closesAt).toISOString().slice(0,10));
    const titleDate = c.title.match(/\d{4}-\d{2}-\d{2}/);
    if (titleDate) hints.push(titleDate[0]);
    const month = c.title.match(/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b/i);
    const key = (hints[0] || (month ? month[0] : 'no_date')).toString();
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(c);
  }
  return groups;
}

function computeExpectedFromGroup(items) {
  items.sort((a,b) => a.threshold - b.threshold);
  // build survival function S(t) approximately from given thresholds: S(t_i) = P(price > t_i)
  // We'll integrate piecewise: E = 
  let expected = 0;
  for (let i = 0; i < items.length - 1; i++) {
    const t = items[i].threshold;
    const nextT = items[i+1].threshold;
    const p = items[i].probability;
    expected += p * (nextT - t);
  }
  // area from 0..minT assume S(t)=1
  const minT = items[0].threshold;
  expected += 1 * minT;
  // tail above maxT approximate as p_max * maxT (simple heuristic)
  const maxT = items[items.length-1].threshold;
  const pmax = items[items.length-1].probability;
  expected += pmax * maxT;
  return expected;
}

async function main() {
  const all = await gatherAll();
  if (!all || all.length === 0) {
    console.error('No threshold-style markets found across Polymarket, PredictIt, Manifold.');
    return;
  }

  const groups = groupByDateHint(all);
  for (const [key, items] of groups.entries()) {
    const est = computeExpectedFromGroup(items);
    console.log(`Group: ${key} — markets used: ${items.length}`);
    console.log(`Estimated expected price (heuristic): $${est.toFixed(2)}`);
    console.log('Sources and markets:');
    for (const it of items) {
      console.log(`  [${it.source}] ${it.threshold} -> ${(it.probability*100).toFixed(2)}%  ${it.title.substring(0,120)}`);
    }
    console.log('---');
  }
}

main().catch(e => { console.error(e); process.exit(1); });
