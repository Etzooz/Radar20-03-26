// Anomaly Detector
// Detects prediction market divergence, sentiment spikes, and abnormal volatility

import type { Signal, Anomaly, AlertSeverity } from "./types"
import { getSignalHistory } from "./temporalMemory"

// ============================================
// CONFIGURATION
// ============================================

const THRESHOLDS = {
  DIVERGENCE: 0.25, // 25% difference = divergence
  SENTIMENT_SPIKE: 0.4, // 0.4 change in sentiment = spike
  VOLATILITY_EXPAND: 2.0, // 2x normal volatility = expansion
  VOLUME_SURGE: 3.0, // 3x normal volume = surge
}

// ============================================
// DIVERGENCE DETECTION
// ============================================

// Detect when prediction markets disagree significantly
export function detectPredictionDivergence(signals: Signal[]): Anomaly[] {
  const anomalies: Anomaly[] = []

  // Group by topic
  const byTopic = new Map<string, Signal[]>()

  for (const signal of signals) {
    if (signal.type !== "prediction_market") continue

    if (!byTopic.has(signal.topic)) {
      byTopic.set(signal.topic, [])
    }
    byTopic.get(signal.topic)!.push(signal)
  }

  // Check each topic
  for (const [topic, topicSignals] of byTopic) {
    if (topicSignals.length < 2) continue

    const values = topicSignals.map(s => s.value)
    const max = Math.max(...values)
    const min = Math.min(...values)
    const diff = max - min

    if (diff > THRESHOLDS.DIVERGENCE) {
      const sources = topicSignals.map(s => s.source).join(", ")

      anomalies.push({
        id: `divergence_${topic}_${Date.now()}`,
        type: "prediction_divergence",
        topic,
        severity: diff > 0.4 ? "high" : diff > 0.3 ? "medium" : "low",
        description: `Prediction markets disagree: ${sources}`,
        detected_at: Date.now(),
        values: {
          current: max,
          expected: values.reduce((a, b) => a + b, 0) / values.length,
          deviation: diff,
        },
      })
    }
  }

  return anomalies
}

// ============================================
// SENTIMENT SPIKE DETECTION
// ============================================

export function detectSentimentSpikes(signals: Signal[]): Anomaly[] {
  const anomalies: Anomaly[] = []

  // Group sentiment signals by topic
  const byTopic = new Map<string, Signal[]>()

  for (const signal of signals) {
    if (signal.type !== "sentiment") continue

    if (!byTopic.has(signal.topic)) {
      byTopic.set(signal.topic, [])
    }
    byTopic.get(signal.topic)!.push(signal)
  }

  // Check each topic
  for (const [topic, topicSignals] of byTopic) {
    // Get historical data
    const history = getSignalHistory(`sentiment_${topic}`, 10)

    if (history.length < 2) continue

    const current = topicSignals[0]?.value || 0
    const previous = history[history.length - 2]?.value || 0
    const change = Math.abs(current - previous)

    if (change > THRESHOLDS.SENTIMENT_SPIKE) {
      anomalies.push({
        id: `sentiment_spike_${topic}_${Date.now()}`,
        type: "sentiment_spike",
        topic,
        severity: change > 0.6 ? "high" : change > 0.5 ? "medium" : "low",
        description: `Sentiment shifted from ${previous.toFixed(2)} to ${current.toFixed(2)}`,
        detected_at: Date.now(),
        values: {
          current,
          expected: previous,
          deviation: change,
        },
      })
    }
  }

  return anomalies
}

// ============================================
// VOLATILITY EXPANSION DETECTION
// ============================================

export function detectVolatilityExpansion(signals: Signal[]): Anomaly[] {
  const anomalies: Anomaly[] = []

  // Group by topic
  const byTopic = new Map<string, Signal[]>()

  for (const signal of signals) {
    if (!byTopic.has(signal.topic)) {
      byTopic.set(signal.topic, [])
    }
    byTopic.get(signal.topic)!.push(signal)
  }

  // Check each topic
  for (const [topic, topicSignals] of byTopic) {
    const history = getSignalHistory(`${topic}_volatility`, 20)

    if (history.length < 10) continue

    // Calculate recent volatility vs historical
    const recent = history.slice(-5)
    const older = history.slice(-20, -5)

    if (recent.length < 2 || older.length < 2) continue

    const recentVol = calculateStdDev(recent.map(p => p.value))
    const olderVol = calculateStdDev(older.map(p => p.value))

    if (olderVol === 0) continue

    const volatilityRatio = recentVol / olderVol

    if (volatilityRatio > THRESHOLDS.VOLATILITY_EXPAND) {
      anomalies.push({
        id: `volatility_${topic}_${Date.now()}`,
        type: "volatility_expansion",
        topic,
        severity: volatilityRatio > 3 ? "high" : volatilityRatio > 2.5 ? "medium" : "low",
        description: `Volatility expanded ${volatilityRatio.toFixed(1)}x`,
        detected_at: Date.now(),
        values: {
          current: recentVol,
          expected: olderVol,
          deviation: volatilityRatio,
        },
      })
    }
  }

  return anomalies
}

// ============================================
// VOLUME SURGE DETECTION
// ============================================

export function detectVolumeSurge(signals: Signal[]): Anomaly[] {
  const anomalies: Anomaly[] = []

  // Look for signals with high volume metadata
  for (const signal of signals) {
    const volume = signal.metadata?.volume as number | undefined

    if (!volume) continue

    const history = getSignalHistory(`volume_${signal.topic}`, 20)

    if (history.length < 10) continue

    const avgVolume = history.reduce((sum, p) => sum + p.value, 0) / history.length

    if (avgVolume === 0) continue

    const volumeRatio = volume / avgVolume

    if (volumeRatio > THRESHOLDS.VOLUME_SURGE) {
      anomalies.push({
        id: `volume_${signal.topic}_${Date.now()}`,
        type: "volume_surge",
        topic: signal.topic,
        severity: volumeRatio > 5 ? "high" : volumeRatio > 4 ? "medium" : "low",
        description: `Volume surged ${volumeRatio.toFixed(1)}x above average`,
        detected_at: Date.now(),
        values: {
          current: volume,
          expected: avgVolume,
          deviation: volumeRatio,
        },
      })
    }
  }

  return anomalies
}

// ============================================
// MASTER ANOMALY DETECTION
// ============================================

export function detectAllAnomalies(signals: Signal[]): Anomaly[] {
  const anomalies: Anomaly[] = [
    ...detectPredictionDivergence(signals),
    ...detectSentimentSpikes(signals),
    ...detectVolatilityExpansion(signals),
    ...detectVolumeSurge(signals),
  ]

  // Sort by severity
  const severityOrder: Record<AlertSeverity, number> = {
    high: 0,
    medium: 1,
    low: 2,
    critical: -1,
  }

  return anomalies.sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity])
}

// ============================================
// UTILITIES
// ============================================

function calculateStdDev(values: number[]): number {
  if (values.length < 2) return 0

  const mean = values.reduce((a, b) => a + b, 0) / values.length
  const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length

  return Math.sqrt(variance)
}

export function getAnomaliesByTopic(anomalies: Anomaly[], topic: string): Anomaly[] {
  return anomalies.filter(a => a.topic === topic)
}

export function getCriticalAnomalies(anomalies: Anomaly[]): Anomaly[] {
  return anomalies.filter(a => a.severity === "critical" || a.severity === "high")
}
