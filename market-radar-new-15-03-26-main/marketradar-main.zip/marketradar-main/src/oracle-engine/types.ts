// Oracle Engine - Core Types
// Unified signal and forecast types for the market intelligence platform

// ============================================
// UNIFIED SIGNAL STRUCTURE
// ============================================

export type Signal = {
  id: string
  source: string
  topic: string
  value: number
  confidence: number
  timestamp: number
  type: SignalType
  metadata?: Record<string, unknown>
}

export type SignalType =
  | "prediction_market"
  | "macro"
  | "sentiment"
  | "technical"
  | "news"
  | "geopolitical"

// ============================================
// TEMPORAL MEMORY
// ============================================

export type TimeSeriesPoint = {
  timestamp: number
  value: number
}

export type SignalHistory = {
  signalId: string
  history: TimeSeriesPoint[]
}

export type PredictionOutcome = {
  topic: string
  predicted: number
  actual: number | null
  resolvedAt: number | null
  correct: boolean | null
}

// ============================================
// FORECAST TYPES
// ============================================

export type ForecastHorizon = "1d" | "7d" | "30d" | "90d"

export type Forecast = {
  topic: string
  probability_now: number
  forecast_1d: number
  forecast_7d: number
  forecast_30d: number
  forecast_90d: number
  confidence: number
  generated_at: number
  signals_used: string[]
}

export type ForecastOutput = {
  topic: string
  probability_now: number
  forecast_1d: number
  forecast_7d: number
  forecast_30d: number
  forecast_90d: number
  confidence: number
}

// ============================================
// TECHNICAL ANALYSIS TYPES
// ============================================

export type Candle = {
  timestamp: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export type PriceLevel = {
  price: number
  type: "support" | "resistance"
  touches: number
  strength: number
  lastTested: number
}

export type PivotPoints = {
  pivot: number
  r1: number
  r2: number
  r3: number
  s1: number
  s2: number
  s3: number
  timestamp: number
}

export type BreakoutSignal = {
  type: "bullish_breakout" | "bearish_breakdown" | "bullish_rejection" | "bearish_rejection"
  price: number
  level: number
  volume: number
  timestamp: number
  confidence: number
}

// ============================================
// EARLY WARNING TYPES
// ============================================

export type AlertSeverity = "low" | "medium" | "high" | "critical"

export type Alert = {
  id: string
  topic: string
  severity: AlertSeverity
  reason: string
  timestamp: number
  relatedSignals: string[]
  metadata?: Record<string, unknown>
}

// ============================================
// NEWS TYPES
// ============================================

export type NewsSignal = {
  id: string
  headline: string
  source: string
  url?: string
  sentiment: number // -1 to 1
  timestamp: number
  topics: string[]
}

export type NewsHeadline = {
  headline: string
  source: string
  sentiment: number
  timestamp: number
  relatedTopics: string[]
}

// ============================================
// PREDICTABILITY TYPES
// ============================================

export type PredictabilityScore = {
  topic: string
  predictability_score: number // 0-1
  signal_strength: number // 0-1
  volatility: number // 0-1
  historical_accuracy?: number
  signal_agreement: number // 0-1
}

// ============================================
// ANOMALY TYPES
// ============================================

export type Anomaly = {
  id: string
  type: "prediction_divergence" | "sentiment_spike" | "volatility_expansion" | "volume_surge"
  topic: string
  severity: AlertSeverity
  description: string
  detected_at: number
  values: {
    current: number
    expected: number
    deviation: number
  }
}

// ============================================
// SIGNAL WEIGHTS FOR FORECASTING
// ============================================

export const SIGNAL_WEIGHTS = {
  market_probability: 0.35,
  momentum_signal: 0.15,
  macro_signal: 0.15,
  sentiment_signal: 0.10,
  technical_signal: 0.15,
  historical_accuracy: 0.10,
} as const

// ============================================
// SOURCE IDENTIFIERS
// ============================================

export const SIGNAL_SOURCES = {
  // Prediction Markets
  POLYMARKET: "polymarket",
  KALSHI: "kalshi",
  MANIFOLD: "manifold",
  METACULUS: "metaculus",
  PREDICTIT: "predictit",
  PREDICTIONBOOK: "predictionbook",

  // Macro
  FRED: "fred",
  BLS: "bls",
  WORLD_BANK: "world_bank",
  IMF: "imf",

  // Sentiment
  GOOGLE_TRENDS: "google_trends",
  FEAR_GREED: "fear_greed",
  NEWS_SENTIMENT: "news_sentiment",

  // Technical
  TECHNICAL: "technical",

  // News
  NEWS_API: "news_api",
  GDELT: "gdelt",
  CRYPTO_NEWS: "crypto_news",
  FINANCIAL_NEWS: "financial_news",

  // Geopolitical
  GEOPOLITICAL: "geopolitical",
} as const

// ============================================
// TOPIC CATEGORIES
// ============================================

export const TOPIC_CATEGORIES = {
  CRYPTO: ["Bitcoin", "Ethereum", "Crypto", "Altcoin"],
  STOCKS: ["S&P 500", "Nasdaq", "Dow Jones", "Stock Market"],
  COMMODITIES: ["Oil", "Gold", "Silver", "Natural Gas"],
  ECONOMY: ["Recession", "Inflation", "GDP", "Interest Rates"],
  GEOPOLITICS: ["War", "Conflict", "Election", "Trade"],
  TECH: ["AI", "Technology", "Semiconductors"],
  ENERGY: ["Energy", "Solar", "Nuclear", "Power"],
} as const
