// Temporal Memory Module
// Stores and retrieves historical signals and prediction outcomes

import type { TimeSeriesPoint, SignalHistory, PredictionOutcome, Signal } from "./types"

// In-memory storage
const signalHistoryStore = new Map<string, TimeSeriesPoint[]>()
const predictionOutcomes: PredictionOutcome[] = []
const signalCache = new Map<string, Signal>()

// Constants
const MAX_HISTORY_POINTS = 1000
const CACHE_TTL = 5 * 60 * 1000 // 5 minutes

// ============================================
// SIGNAL HISTORY MANAGEMENT
// ============================================

export function storeSignalValue(signalId: string, value: number, timestamp: number = Date.now()): void {
  let history = signalHistoryStore.get(signalId) || []

  history.push({ timestamp, value })

  // Keep only last MAX_HISTORY_POINTS
  if (history.length > MAX_HISTORY_POINTS) {
    history = history.slice(-MAX_HISTORY_POINTS)
  }

  signalHistoryStore.set(signalId, history)
}

export function getSignalHistory(signalId: string, limit?: number): TimeSeriesPoint[] {
  const history = signalHistoryStore.get(signalId) || []
  return limit ? history.slice(-limit) : history
}

export function getSignalHistoryRange(
  signalId: string,
  startTime: number,
  endTime: number = Date.now()
): TimeSeriesPoint[] {
  const history = signalHistoryStore.get(signalId) || []
  return history.filter(p => p.timestamp >= startTime && p.timestamp <= endTime)
}

export function getAllSignalIds(): string[] {
  return Array.from(signalHistoryStore.keys())
}

export function clearSignalHistory(signalId?: string): void {
  if (signalId) {
    signalHistoryStore.delete(signalId)
  } else {
    signalHistoryStore.clear()
  }
}

// ============================================
// SIGNAL CACHE
// ============================================

export function cacheSignal(signal: Signal): void {
  const key = `${signal.source}:${signal.topic}`
  signalCache.set(key, signal)
}

export function getCachedSignal(source: string, topic: string): Signal | null {
  const key = `${source}:${topic}`
  return signalCache.get(key) || null
}

export function getAllCachedSignals(): Signal[] {
  return Array.from(signalCache.values())
}

export function clearSignalCache(): void {
  signalCache.clear()
}

// ============================================
// PREDICTION OUTCOMES
// ============================================

export function storePredictionOutcome(outcome: PredictionOutcome): void {
  predictionOutcomes.push(outcome)
}

export function getPredictionOutcomes(topic?: string): PredictionOutcome[] {
  if (topic) {
    return predictionOutcomes.filter(o => o.topic === topic)
  }
  return [...predictionOutcomes]
}

export function resolvePrediction(
  topic: string,
  actualValue: number,
  resolvedAt: number = Date.now()
): boolean | null {
  // Find unresolved prediction for topic
  const prediction = predictionOutcomes.find(
    o => o.topic === topic && o.resolvedAt === null
  )

  if (!prediction) return null

  // Update the prediction
  prediction.actual = actualValue
  prediction.resolvedAt = resolvedAt

  // Determine if correct (within 10% margin)
  const margin = Math.abs(prediction.predicted - actualValue)
  prediction.correct = margin <= 0.1

  return prediction.correct
}

export function calculateHistoricalAccuracy(topic?: string): number {
  const outcomes = topic ? predictionOutcomes.filter(o => o.topic === topic) : predictionOutcomes
  const resolved = outcomes.filter(o => o.correct !== null)

  if (resolved.length === 0) return 0

  const correct = resolved.filter(o => o.correct).length
  return correct / resolved.length
}

// ============================================
// TIME SERIES ANALYSIS
// ============================================

export function calculateMovingAverage(signalId: string, window: number): number | null {
  const history = getSignalHistory(signalId, window)
  if (history.length < window) return null

  const sum = history.slice(-window).reduce((acc, p) => acc + p.value, 0)
  return sum / window
}

export function calculateVolatility(signalId: string, window: number = 20): number {
  const history = getSignalHistory(signalId, window)
  if (history.length < 2) return 0

  const values = history.map(p => p.value)
  const mean = values.reduce((a, b) => a + b, 0) / values.length
  const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length

  return Math.sqrt(variance)
}

export function detectTrend(signalId: string, window: number = 10): "up" | "down" | "neutral" {
  const history = getSignalHistory(signalId, window)
  if (history.length < 2) return "neutral"

  const recent = history.slice(-Math.min(5, Math.floor(window / 2)))
  const older = history.slice(0, Math.min(5, Math.floor(window / 2)))

  const recentAvg = recent.reduce((a, b) => a + b.value, 0) / recent.length
  const olderAvg = older.reduce((a, b) => a + b.value, 0) / older.length

  const diff = recentAvg - olderAvg

  if (diff > 0.05) return "up"
  if (diff < -0.05) return "down"
  return "neutral"
}

// ============================================
// AGGREGATE STATISTICS
// ============================================

export function getTopicsWithHistory(): string[] {
  const topics = new Set<string>()
  for (const history of signalHistoryStore.values()) {
    // Extract topic from signal ID (format: source:topic)
    for (const key of signalHistoryStore.keys()) {
      const parts = key.split(":")
      if (parts.length >= 2) {
        topics.add(parts.slice(1).join(":"))
      }
    }
  }
  return Array.from(topics)
}

export function getSignalCount(): number {
  return signalHistoryStore.size
}

export function getOutcomeCount(): number {
  return predictionOutcomes.length
}

// ============================================
// EXPORT/IMPORT
// ============================================

export function exportHistory(): string {
  return JSON.stringify({
    signalHistory: Array.from(signalHistoryStore.entries()),
    outcomes: predictionOutcomes,
  })
}

export function importHistory(data: string): void {
  try {
    const parsed = JSON.parse(data)
    if (parsed.signalHistory) {
      for (const [key, value] of parsed.signalHistory) {
        signalHistoryStore.set(key, value as TimeSeriesPoint[])
      }
    }
    if (parsed.outcomes) {
      predictionOutcomes.push(...parsed.outcomes)
    }
  } catch (e) {
    console.error("Failed to import history:", e)
  }
}
