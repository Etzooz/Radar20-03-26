// Technical Signals Module
// Support/Resistance, Pivot Points, and Breakout Detection

import type { Candle, PriceLevel, PivotPoints, BreakoutSignal } from "../types"

// ============================================
// SUPPORT AND RESISTANCE DETECTION
// ============================================

// Find local highs and lows in candles
function findLocalExtrema(candles: Candle[], windowSize: number = 5): { highs: number[]; lows: number[] } {
  const highs: number[] = []
  const lows: number[] = []

  for (let i = windowSize; i < candles.length - windowSize; i++) {
    const current = candles[i]
    let isHigh = true
    let isLow = true

    // Check if local high
    for (let j = i - windowSize; j <= i + windowSize; j++) {
      if (j !== i && candles[j].high >= current.high) {
        isHigh = false
        break
      }
    }

    // Check if local low
    for (let j = i - windowSize; j <= i + windowSize; j++) {
      if (j !== i && candles[j].low <= current.low) {
        isLow = false
        break
      }
    }

    if (isHigh) highs.push(current.high)
    if (isLow) lows.push(current.low)
  }

  return { highs, lows }
}

// Cluster price levels that are close together
function clusterLevels(prices: number[], threshold: number = 0.02): number[] {
  if (prices.length === 0) return []

  const sorted = [...prices].sort((a, b) => a - b)
  const clusters: number[][] = []

  let currentCluster = [sorted[0]]

  for (let i = 1; i < sorted.length; i++) {
    const diff = (sorted[i] - currentCluster[currentCluster.length - 1]) / currentCluster[currentCluster.length - 1]

    if (diff <= threshold) {
      currentCluster.push(sorted[i])
    } else {
      clusters.push(currentCluster)
      currentCluster = [sorted[i]]
    }
  }
  clusters.push(currentCluster)

  // Return cluster centers (average)
  return clusters.map(cluster => cluster.reduce((a, b) => a + b, 0) / cluster.length)
}

// Detect support and resistance levels
export function detectSupportResistance(candles: Candle[]): PriceLevel[] {
  if (candles.length < 20) return []

  const { highs, lows } = findLocalExtrema(candles)

  const resistanceLevels = clusterLevels(highs)
  const supportLevels = clusterLevels(lows)

  const levels: PriceLevel[] = []

  // Create resistance levels
  for (const price of resistanceLevels) {
    const touches = highs.filter(h => Math.abs((h - price) / price) < 0.02).length
    const lastTested = candles.filter(c => c.high >= price * 0.98 && c.high <= price * 1.02).pop()?.timestamp || 0

    levels.push({
      price,
      type: "resistance",
      touches,
      strength: Math.min(1, touches / 5),
      lastTested,
    })
  }

  // Create support levels
  for (const price of supportLevels) {
    const touches = lows.filter(l => Math.abs((l - price) / price) < 0.02).length
    const lastTested = candles.filter(c => c.low >= price * 0.98 && c.low <= price * 1.02).pop()?.timestamp || 0

    levels.push({
      price,
      type: "support",
      touches,
      strength: Math.min(1, touches / 5),
      lastTested,
    })
  }

  // Sort by strength
  return levels.sort((a, b) => b.strength - a.strength)
}

// Get nearest support/resistance levels
export function getNearestLevels(currentPrice: number, levels: PriceLevel[], count: number = 3): {
  support: PriceLevel[]
  resistance: PriceLevel[]
} {
  const support = levels
    .filter(l => l.type === "support" && l.price < currentPrice)
    .sort((a, b) => b.price - a.price)
    .slice(0, count)

  const resistance = levels
    .filter(l => l.type === "resistance" && l.price > currentPrice)
    .sort((a, b) => a.price - b.price)
    .slice(0, count)

  return { support, resistance }
}

// ============================================
// PIVOT POINTS
// ============================================

export function calculatePivotPoints(candle: Candle): PivotPoints {
  const high = candle.high
  const low = candle.low
  const close = candle.close

  const pivot = (high + low + close) / 3

  const r1 = 2 * pivot - low
  const r2 = pivot + (high - low)
  const r3 = high + 2 * (pivot - low)

  const s1 = 2 * pivot - high
  const s2 = pivot - (high - low)
  const s3 = low - 2 * (high - pivot)

  return {
    pivot,
    r1,
    r2,
    r3,
    s1,
    s2,
    s3,
    timestamp: candle.timestamp,
  }
}

export function calculatePivotPointsSeries(candles: Candle[]): PivotPoints[] {
  // Group candles by day
  const dailyCandles = new Map<string, Candle>()

  for (const candle of candles) {
    const date = new Date(candle.timestamp).toISOString().split("T")[0]
    if (!dailyCandles.has(date)) {
      dailyCandles.set(date, candle)
    }
  }

  const pivots: PivotPoints[] = []

  for (const candle of dailyCandles.values()) {
    pivots.push(calculatePivotPoints(candle))
  }

  return pivots
}

// ============================================
// BREAKOUT DETECTION
// ============================================

export function detectBreakouts(candles: Candle[], levels: PriceLevel[]): BreakoutSignal[] {
  if (candles.length < 2 || levels.length === 0) return []

  const signals: BreakoutSignal[] = []
  const currentCandle = candles[candles.length - 1]
  const prevCandle = candles[candles.length - 2]

  // Get average volume
  const avgVolume = candles.slice(-20).reduce((sum, c) => sum + c.volume, 0) / Math.min(20, candles.length)
  const volumeRatio = currentCandle.volume / avgVolume

  // Check for resistance breakouts
  for (const level of levels.filter(l => l.type === "resistance")) {
    // Bullish breakout
    if (prevCandle.close < level.price && currentCandle.close > level.price) {
      signals.push({
        type: "bullish_breakout",
        price: currentCandle.close,
        level: level.price,
        volume: volumeRatio,
        timestamp: currentCandle.timestamp,
        confidence: Math.min(1, level.strength * volumeRatio),
      })
    }
    // Rejection at resistance
    else if (prevCandle.close < level.price && currentCandle.close < level.price && currentCandle.high > level.price) {
      signals.push({
        type: "bullish_rejection",
        price: currentCandle.close,
        level: level.price,
        volume: volumeRatio,
        timestamp: currentCandle.timestamp,
        confidence: level.strength * 0.7,
      })
    }
  }

  // Check for support breakouts
  for (const level of levels.filter(l => l.type === "support")) {
    // Bearish breakdown
    if (prevCandle.close > level.price && currentCandle.close < level.price) {
      signals.push({
        type: "bearish_breakdown",
        price: currentCandle.close,
        level: level.price,
        volume: volumeRatio,
        timestamp: currentCandle.timestamp,
        confidence: Math.min(1, level.strength * volumeRatio),
      })
    }
    // Rejection at support
    else if (prevCandle.close > level.price && currentCandle.close > level.price && currentCandle.low < level.price) {
      signals.push({
        type: "bearish_rejection",
        price: currentCandle.close,
        level: level.price,
        volume: volumeRatio,
        timestamp: currentCandle.timestamp,
        confidence: level.strength * 0.7,
      })
    }
  }

  // Sort by confidence
  return signals.sort((a, b) => b.confidence - a.confidence)
}

// ============================================
// TECHNICAL INDICATORS
// ============================================

// Simple Moving Average
export function calculateSMA(candles: Candle[], period: number): number | null {
  if (candles.length < period) return null

  const recent = candles.slice(-period)
  const sum = recent.reduce((acc, c) => acc + c.close, 0)
  return sum / period
}

// Exponential Moving Average
export function calculateEMA(candles: Candle[], period: number): number | null {
  if (candles.length < period) return null

  const multiplier = 2 / (period + 1)
  let ema = candles.slice(0, period).reduce((acc, c) => acc + c.close, 0) / period

  for (let i = period; i < candles.length; i++) {
    ema = (candles[i].close - ema) * multiplier + ema
  }

  return ema
}

// RSI (Relative Strength Index)
export function calculateRSI(candles: Candle[], period: number = 14): number | null {
  if (candles.length < period + 1) return null

  const changes: number[] = []
  for (let i = 1; i < candles.length; i++) {
    changes.push(candles[i].close - candles[i - 1].close)
  }

  const recentChanges = changes.slice(-period)
  const gains = recentChanges.filter(c => c > 0)
  const losses = recentChanges.filter(c => c < 0).map(c => Math.abs(c))

  const avgGain = gains.length > 0 ? gains.reduce((a, b) => a + b, 0) / period : 0
  const avgLoss = losses.length > 0 ? losses.reduce((a, b) => a + b, 0) / period : 0

  if (avgLoss === 0) return 100

  const rs = avgGain / avgLoss
  return 100 - 100 / (1 + rs)
}

// MACD
export function calculateMACD(
  candles: Candle[],
  fastPeriod: number = 12,
  slowPeriod: number = 26,
  signalPeriod: number = 9
): { macd: number; signal: number; histogram: number } | null {
  const emaFast = calculateEMA(candles, fastPeriod)
  const emaSlow = calculateEMA(candles, slowPeriod)

  if (emaFast === null || emaSlow === null) return null

  const macdLine = emaFast - emaSlow

  // For signal line, we'd need historical MACD values
  // Simplified version returning just the MACD line
  return {
    macd: macdLine,
    signal: macdLine * 0.9, // Simplified
    histogram: macdLine * 0.1,
  }
}
