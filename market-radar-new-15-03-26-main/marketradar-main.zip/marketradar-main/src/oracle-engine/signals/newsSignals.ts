// News Signals Module
// News Aggregator and Sentiment Analyzer

import type { NewsSignal, NewsHeadline, Signal } from "../types"

// ============================================
// NEWS AGGREGATOR
// ============================================

// Demo news sources (in production, these would be real API calls)
const NEWS_SOURCES = [
  "Reuters",
  "Bloomberg",
  "CNBC",
  "Coindesk",
  "Yahoo Finance",
  "MarketWatch",
]

// Store cached news
const newsCache: NewsSignal[] = []
const CACHE_TTL = 60 * 1000 // 1 minute

// Fetch news from multiple sources
export async function fetchNews(): Promise<NewsSignal[]> {
  const now = Date.now()

  // Return cached if still valid
  if (newsCache.length > 0 && now - newsCache[0].timestamp < CACHE_TTL) {
    return newsCache
  }

  // In production, this would fetch from real APIs
  // For now, generate demo news
  const news = generateDemoNews()

  // Update cache
  newsCache.length = 0
  newsCache.push(...news)

  return news
}

// Generate demo news for development
function generateDemoNews(): NewsSignal[] {
  const demoNews: NewsSignal[] = [
    {
      id: "1",
      headline: "Oil prices surge amid supply concerns",
      source: "Reuters",
      url: "https://reuters.com",
      sentiment: 0.7,
      timestamp: Date.now(),
      topics: ["Oil", "Commodities"],
    },
    {
      id: "2",
      headline: "Bitcoin breaks $100K resistance level",
      source: "Coindesk",
      url: "https://coindesk.com",
      sentiment: 0.8,
      timestamp: Date.now() - 60000,
      topics: ["Bitcoin", "Crypto"],
    },
    {
      id: "3",
      headline: "Fed signals potential rate cut in coming months",
      source: "Bloomberg",
      url: "https://bloomberg.com",
      sentiment: 0.5,
      timestamp: Date.now() - 120000,
      topics: ["Fed", "Economy"],
    },
    {
      id: "4",
      headline: "Tech stocks rally on AI optimism",
      source: "CNBC",
      url: "https://cnbc.com",
      sentiment: 0.6,
      timestamp: Date.now() - 180000,
      topics: ["Technology", "AI"],
    },
    {
      id: "5",
      headline: "Geopolitical tensions rise in Middle East",
      source: "Reuters",
      url: "https://reuters.com",
      sentiment: -0.5,
      timestamp: Date.now() - 240000,
      topics: ["Geopolitics", "Energy"],
    },
    {
      id: "6",
      headline: "Gold reaches new all-time high",
      source: "Yahoo Finance",
      url: "https://finance.yahoo.com",
      sentiment: 0.4,
      timestamp: Date.now() - 300000,
      topics: ["Gold", "Commodities"],
    },
  ]

  return demoNews
}

// Get latest headlines for display
export function getLatestHeadlines(limit: number = 5): NewsHeadline[] {
  return newsCache.slice(0, limit).map(n => ({
    headline: n.headline,
    source: n.source,
    sentiment: n.sentiment,
    timestamp: n.timestamp,
    relatedTopics: n.topics,
  }))
}

// Get news by topic
export function getNewsByTopic(topic: string): NewsSignal[] {
  return newsCache.filter(n =>
    n.topics.some(t => t.toLowerCase().includes(topic.toLowerCase()))
  )
}

// ============================================
// SENTIMENT ANALYZER
// ============================================

// Simple sentiment analysis (in production, use NLP APIs)
const POSITIVE_WORDS = [
  "surge", "rally", "gain", "rise", "increase", "bullish", "optimism",
  "growth", "positive", "breakthrough", "success", "improve", "higher",
]

const NEGATIVE_WORDS = [
  "fall", "drop", "decline", "crash", "bearish", "concern", "risk",
  "fear", "worst", "crisis", "tension", "conflict", "recession",
]

export function analyzeSentiment(text: string): number {
  const lower = text.toLowerCase()

  let score = 0
  let count = 0

  for (const word of POSITIVE_WORDS) {
    if (lower.includes(word)) {
      score += 1
      count++
    }
  }

  for (const word of NEGATIVE_WORDS) {
    if (lower.includes(word)) {
      score -= 1
      count++
    }
  }

  if (count === 0) return 0

  // Normalize to -1 to 1
  return Math.max(-1, Math.min(1, score / count))
}

// Convert sentiment to signal
export function newsToSignal(news: NewsSignal): Signal {
  return {
    id: `news_${news.id}`,
    source: news.source,
    topic: news.topics[0] || "General",
    value: (news.sentiment + 1) / 2, // Convert -1..1 to 0..1
    confidence: 0.6,
    timestamp: news.timestamp,
    type: "news",
    metadata: {
      headline: news.headline,
      originalSentiment: news.sentiment,
    },
  }
}

// Get aggregate sentiment for topic
export function getTopicSentiment(topic: string): number {
  const topicNews = getNewsByTopic(topic)

  if (topicNews.length === 0) return 0

  const sum = topicNews.reduce((acc, n) => acc + n.sentiment, 0)
  return sum / topicNews.length
}

// Get all news signals
export function getAllNewsSignals(): Signal[] {
  return newsCache.map(newsToSignal)
}

// ============================================
// NEWS TICKER FORMATTER
// ============================================

export function formatTickerItem(headline: NewsHeadline): string {
  const emoji = headline.sentiment > 0.2 ? "🟢" : headline.sentiment < -0.2 ? "🔴" : "⚪"
  return `${emoji} ${headline.headline} (${headline.source})`
}

// Get ticker-ready text
export function getTickerText(): string {
  const headlines = getLatestHeadlines(3)
  return headlines.map(formatTickerItem).join(" | ")
}

// ============================================
// SENTIMENT TRENDS
// ============================================

// Track sentiment changes
export function getSentimentTrend(topic: string): "improving" | "declining" | "stable" {
  const topicNews = getNewsByTopic(topic)

  if (topicNews.length < 2) return "stable"

  const recent = topicNews[0]?.sentiment || 0
  const older = topicNews[topicNews.length - 1]?.sentiment || 0
  const diff = recent - older

  if (diff > 0.2) return "improving"
  if (diff < -0.2) return "declining"
  return "stable"
}
