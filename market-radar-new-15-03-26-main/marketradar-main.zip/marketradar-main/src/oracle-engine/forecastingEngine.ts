// Forecasting Engine
// Combines all signals into probability forecasts

import type { Signal, Forecast, ForecastOutput, SignalType } from "./types"
import { SIGNAL_WEIGHTS } from "./types"
import { storeSignalValue, calculateHistoricalAccuracy, getSignalHistory } from "./temporalMemory"

// ============================================
// SIGNAL AGGREGATION
// ============================================

// Group signals by type
function groupByType(signals: Signal[]): Record<SignalType, Signal[]> {
  const grouped: Record<SignalType, Signal[]> = {
    prediction_market: [],
    macro: [],
    sentiment: [],
    technical: [],
    news: [],
    geopolitical: [],
  }

  for (const signal of signals) {
    if (grouped[signal.type]) {
      grouped[signal.type].push(signal)
    }
  }

  return grouped
}

// Get average value for a signal type
function getAverageForType(signals: Signal[], type: SignalType): number | null {
  const typeSignals = signals.filter((s) => s.type === type)
  if (typeSignals.length === 0) return null

  // Weighted by confidence
  let totalWeight = 0
  let weightedSum = 0

  for (const signal of typeSignals) {
    const weight = signal.confidence
    weightedSum += signal.value * weight
    totalWeight += weight
  }

  return totalWeight > 0 ? weightedSum / totalWeight : null
}

// ============================================
// FORECAST GENERATION
// ============================================

export function generateForecast(
  topic: string,
  signals: Signal[]
): Forecast {
  const grouped = groupByType(signals)

  // Get signal values for each type
  const marketProb = getAverageForType(signals, "prediction_market")
  const momentumSignal = getAverageForType(signals, "technical") // Use technical as momentum proxy
  const macroSignal = getAverageForType(signals, "macro")
  const sentimentSignal = getAverageForType(signals, "sentiment")
  const technicalSignal = getAverageForType(signals, "technical")
  const historicalAccuracy = calculateHistoricalAccuracy(topic)

  // Calculate weighted forecast
  let forecast1d = 0
  let forecast7d = 0
  let forecast30d = 0
  let forecast90d = 0
  let totalWeight = 0

  // Market probability (35%)
  if (marketProb !== null) {
    const weight = SIGNAL_WEIGHTS.market_probability
    forecast1d += marketProb * weight
    forecast7d += marketProb * weight * 1.02 // Slight upward bias for longer horizons
    forecast30d += marketProb * weight * 1.05
    forecast90d += marketProb * weight * 1.08
    totalWeight += weight
  }

  // Momentum signal (15%)
  if (momentumSignal !== null) {
    const weight = SIGNAL_WEIGHTS.momentum_signal
    forecast1d += momentumSignal * weight
    forecast7d += momentumSignal * weight * 1.03
    forecast30d += momentumSignal * weight * 1.08
    forecast90d += momentumSignal * weight * 1.12
    totalWeight += weight
  }

  // Macro signal (15%)
  if (macroSignal !== null) {
    const weight = SIGNAL_WEIGHTS.macro_signal
    forecast1d += macroSignal * weight
    forecast7d += macroSignal * weight * 1.01
    forecast30d += macroSignal * weight * 1.03
    forecast90d += macroSignal * weight * 1.05
    totalWeight += weight
  }

  // Sentiment signal (10%)
  if (sentimentSignal !== null) {
    const weight = SIGNAL_WEIGHTS.sentiment_signal
    forecast1d += sentimentSignal * weight
    forecast7d += sentimentSignal * weight * 1.02
    forecast30d += sentimentSignal * weight * 1.04
    forecast90d += sentimentSignal * weight * 1.06
    totalWeight += weight
  }

  // Technical signal (15%)
  if (technicalSignal !== null) {
    const weight = SIGNAL_WEIGHTS.technical_signal
    forecast1d += technicalSignal * weight
    forecast7d += technicalSignal * weight * 1.02
    forecast30d += technicalSignal * weight * 1.04
    forecast90d += technicalSignal * weight * 1.06
    totalWeight += weight
  }

  // Historical accuracy adjustment (10%)
  if (historicalAccuracy > 0) {
    const weight = SIGNAL_WEIGHTS.historical_accuracy
    const accuracyMultiplier = 0.5 + historicalAccuracy * 0.5 // Scale to 0.5-1.0
    forecast1d *= accuracyMultiplier
    forecast7d *= accuracyMultiplier
    forecast30d *= accuracyMultiplier
    forecast90d *= accuracyMultiplier
    totalWeight += weight
  }

  // Normalize by actual weight used
  if (totalWeight > 0) {
    forecast1d /= totalWeight
    forecast7d /= totalWeight
    forecast30d /= totalWeight
    forecast90d /= totalWeight
  }

  // Calculate confidence based on signal coverage
  const signalTypes = Object.values(grouped).filter((arr) => arr.length > 0).length
  const confidence = Math.min(1, signalTypes / 5) * 0.5 + 0.5

  // Get current probability
  const probabilityNow = marketProb ?? 0.5

  // Store for historical tracking
  storeSignalValue(`${topic}:probability`, probabilityNow)

  return {
    topic,
    probability_now: probabilityNow,
    forecast_1d: Math.max(0, Math.min(1, forecast1d)),
    forecast_7d: Math.max(0, Math.min(1, forecast7d)),
    forecast_30d: Math.max(0, Math.min(1, forecast30d)),
    forecast_90d: Math.max(0, Math.min(1, forecast90d)),
    confidence,
    generated_at: Date.now(),
    signals_used: signals.map((s) => s.id),
  }
}

// Generate forecasts for multiple topics
export function generateAllForecasts(
  signals: Signal[]
): Forecast[] {
  // Group signals by topic
  const byTopic = new Map<string, Signal[]>()

  for (const signal of signals) {
    if (!byTopic.has(signal.topic)) {
      byTopic.set(signal.topic, [])
    }
    byTopic.get(signal.topic)!.push(signal)
  }

  // Generate forecast for each topic
  const forecasts: Forecast[] = []

  for (const [topic, topicSignals] of byTopic) {
    const forecast = generateForecast(topic, topicSignals)
    forecasts.push(forecast)
  }

  // Sort by confidence
  return forecasts.sort((a, b) => b.confidence - a.confidence)
}

// Get forecast for specific topic
export function getForecast(topic: string, signals: Signal[]): Forecast | null {
  const topicSignals = signals.filter((s) => s.topic === topic)
  if (topicSignals.length === 0) return null

  return generateForecast(topic, topicSignals)
}

// Simplify forecast for output
export function simplifyForecast(forecast: Forecast): ForecastOutput {
  return {
    topic: forecast.topic,
    probability_now: forecast.probability_now,
    forecast_1d: forecast.forecast_1d,
    forecast_7d: forecast.forecast_7d,
    forecast_30d: forecast.forecast_30d,
    forecast_90d: forecast.forecast_90d,
    confidence: forecast.confidence,
  }
}

// Calculate probability change
export function calculateProbabilityChange(forecast: Forecast): {
  change_1d: number
  change_7d: number
  change_30d: number
  change_90d: number
} {
  return {
    change_1d: forecast.forecast_1d - forecast.probability_now,
    change_7d: forecast.forecast_7d - forecast.probability_now,
    change_30d: forecast.forecast_30d - forecast.probability_now,
    change_90d: forecast.forecast_90d - forecast.probability_now,
  }
}
