// Oracle Engine - Main API Export
// Unified Market Intelligence Platform

// Core Types
export * from "./types"

// Temporal Memory
export * from "./temporalMemory"

// Forecasting Engine
export * from "./forecastingEngine"

// Analysis Engines
export * from "./anomalyDetector"
export * from "./earlyWarningEngine"

// Signals
export * from "./signals/technicalSignals"
export * from "./signals/newsSignals"

// Main API Functions

import type { Signal, Forecast, Alert, Anomaly, PredictabilityScore, NewsHeadline, PriceLevel, BreakoutSignal, Candle } from "./types"
import { generateAllForecasts, getForecast, simplifyForecast } from "./forecastingEngine"
import { detectAllAnomalies } from "./anomalyDetector"
import { generateAlerts } from "./earlyWarningEngine"
import { storeSignalValue, getSignalHistory, calculateHistoricalAccuracy, calculateVolatility } from "./temporalMemory"
import { detectSupportResistance, getNearestLevels, calculatePivotPoints, detectBreakouts } from "./signals/technicalSignals"
import { fetchNews, getLatestHeadlines, getTickerText, getAllNewsSignals } from "./signals/newsSignals"

// ============================================
// MAIN API FUNCTIONS
// ============================================

// Collect all signals from all sources
export async function getSignals(): Promise<Signal[]> {
  const signals: Signal[] = []

  // Get news signals
  const newsSignals = getAllNewsSignals()
  signals.push(...newsSignals)

  return signals
}

// Get all forecasts
export function getForecasts(signals: Signal[]): Forecast[] {
  return generateAllForecasts(signals)
}

// Get support/resistance levels
export function getSupportResistanceLevels(candles: Candle[]): PriceLevel[] {
  return detectSupportResistance(candles)
}

// Get nearest levels to current price
export function getLevelsForPrice(candles: Candle[], currentPrice: number): {
  support: PriceLevel[]
  resistance: PriceLevel[]
} {
  const levels = detectSupportResistance(candles)
  return getNearestLevels(currentPrice, levels)
}

// Get breakout signals
export function getBreakoutSignals(candles: Candle[]): BreakoutSignal[] {
  const levels = detectSupportResistance(candles)
  return detectBreakouts(candles, levels)
}

// Get early warnings
export function getEarlyWarnings(signals: Signal[]): Alert[] {
  return generateAlerts(signals)
}

// Get predictability index for a topic
export function getPredictabilityIndex(topic: string, signals: Signal[]): PredictabilityScore {
  const topicSignals = signals.filter(s => s.topic === topic)

  // Calculate signal agreement
  const values = topicSignals.map(s => s.value)
  const mean = values.reduce((a, b) => a + b, 0) / values.length
  const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length
  const signalAgreement = 1 - Math.sqrt(variance) * 2

  // Calculate signal strength
  const avgConfidence = topicSignals.reduce((sum, s) => sum + s.confidence, 0) / topicSignals.length

  // Calculate volatility
  const volatility = calculateVolatility(topic, 20)

  // Historical accuracy
  const historicalAccuracy = calculateHistoricalAccuracy(topic)

  // Overall predictability score
  const predictability = (signalAgreement * 0.3 + avgConfidence * 0.3 + (1 - volatility) * 0.2 + historicalAccuracy * 0.2)

  return {
    topic,
    predictability_score: Math.max(0, Math.min(1, predictability)),
    signal_strength: avgConfidence,
    volatility: Math.min(1, volatility),
    historical_accuracy: historicalAccuracy,
    signal_agreement: Math.max(0, Math.min(1, signalAgreement)),
  }
}

// Get latest news headline
export async function getLatestNewsHeadline(): Promise<NewsHeadline | null> {
  await fetchNews()
  const headlines = getLatestHeadlines(1)
  return headlines[0] || null
}

// Get news ticker text
export async function getNewsTicker(): Promise<string> {
  await fetchNews()
  return getTickerText()
}

// ============================================
// SIGNAL STORAGE
// ============================================

// Store a signal for historical tracking
export function recordSignal(signal: Signal): void {
  storeSignalValue(`${signal.topic}:${signal.type}`, signal.value, signal.timestamp)
}

// Get signal history
export function getSignalHistoryForTopic(topic: string, type?: string): ReturnType<typeof getSignalHistory> {
  const key = type ? `${topic}:${type}` : topic
  return getSignalHistory(key)
}

// ============================================
// CONVENIENCE FUNCTIONS
// ============================================

// Format probability as percentage
export function formatProbability(prob: number): string {
  return `${(prob * 100).toFixed(1)}%`
}

// Get sentiment color
export function getSentimentColor(sentiment: number): string {
  if (sentiment > 0.3) return "green"
  if (sentiment < -0.3) return "red"
  return "gray"
}

// Get severity color
export function getSeverityColor(severity: string): string {
  switch (severity) {
    case "critical":
    case "high":
      return "red"
    case "medium":
      return "orange"
    case "low":
      return "yellow"
    default:
      return "gray"
  }
}

// Default export
export default {
  getSignals,
  getForecasts,
  getSupportResistanceLevels,
  getLevelsForPrice,
  getBreakoutSignals,
  getEarlyWarnings,
  getPredictabilityIndex,
  getLatestNewsHeadline,
  getNewsTicker,
  recordSignal,
  getSignalHistoryForTopic,
  formatProbability,
  getSentimentColor,
  getSeverityColor,
}
