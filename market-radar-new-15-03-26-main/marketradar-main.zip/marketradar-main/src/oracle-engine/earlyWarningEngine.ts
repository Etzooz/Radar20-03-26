// Early Warning Engine
// Triggers alerts when prediction probabilities spike, volatility expands, etc.

import type { Signal, Alert, AlertSeverity } from "./types"
import { getSignalHistory } from "./temporalMemory"
import { detectAllAnomalies } from "./anomalyDetector"

// ============================================
// CONFIGURATION
// ============================================

const ALERT_THRESHOLDS = {
  PROBABILITY_SPIKE: 0.15, // 15% change in 1 hour
  VOLATILITY_EXPAND: 1.5, // 1.5x normal volatility
  SENTIMENT_SHIFT: 0.3, // 0.3 change in sentiment
  SUPPORT_BREAK: 0.05, // 5% break from support
  RESISTANCE_BREAK: 0.05, // 5% break from resistance
}

// ============================================
// ALERT GENERATION
// ============================================

// Generate alerts based on signal changes
export function generateAlerts(signals: Signal[]): Alert[] {
  const alerts: Alert[] = []

  // 1. Check for probability spikes
  alerts.push(...detectProbabilitySpikes(signals))

  // 2. Check for volatility expansion
  alerts.push(...detectVolatilityAlerts(signals))

  // 3. Check for sentiment shifts
  alerts.push(...detectSentimentShifts(signals))

  // 4. Add alerts from anomaly detector
  const anomalies = detectAllAnomalies(signals)
  for (const anomaly of anomalies) {
    alerts.push({
      id: anomaly.id,
      topic: anomaly.topic,
      severity: anomaly.severity,
      reason: anomaly.description,
      timestamp: anomaly.detected_at,
      relatedSignals: [],
      metadata: anomaly,
    })
  }

  // Sort by severity
  return sortAlerts(alerts)
}

// ============================================
// PROBABILITY SPIKE DETECTION
// ============================================

function detectProbabilitySpikes(signals: Signal[]): Alert[] {
  const alerts: Alert[] = []

  // Group by topic
  const byTopic = new Map<string, Signal[]>()

  for (const signal of signals) {
    if (signal.type !== "prediction_market") continue

    if (!byTopic.has(signal.topic)) {
      byTopic.set(signal.topic, [])
    }
    byTopic.get(signal.topic)!.push(signal)
  }

  // Check each topic
  for (const [topic, topicSignals] of byTopic) {
    // Get historical probability
    const history = getSignalHistory(`probability_${topic}`, 10)

    if (history.length < 2) continue

    const current = topicSignals[0]?.value || 0
    const previous = history[history.length - 2]?.value || 0
    const change = current - previous

    // Check for spike
    if (Math.abs(change) > ALERT_THRESHOLDS.PROBABILITY_SPIKE) {
      const direction = change > 0 ? "increased" : "decreased"

      alerts.push({
        id: `spike_${topic}_${Date.now()}`,
        topic,
        severity: Math.abs(change) > 0.25 ? "high" : Math.abs(change) > 0.2 ? "medium" : "low",
        reason: `Probability ${direction} by ${(Math.abs(change) * 100).toFixed(1)}%`,
        timestamp: Date.now(),
        relatedSignals: topicSignals.map(s => s.id),
      })
    }
  }

  return alerts
}

// ============================================
// VOLATILITY ALERTS
// ============================================

function detectVolatilityAlerts(signals: Signal[]): Alert[] {
  const alerts: Alert[] = []

  // Check each signal for volatility changes
  for (const signal of signals) {
    const history = getSignalHistory(`volatility_${signal.topic}`, 20)

    if (history.length < 10) continue

    const recent = history.slice(-5)
    const older = history.slice(-20, -5)

    if (recent.length < 2 || older.length < 2) continue

    const recentVol = calculateStdDev(recent.map(p => p.value))
    const olderVol = calculateStdDev(older.map(p => p.value))

    if (olderVol === 0) continue

    const ratio = recentVol / olderVol

    if (ratio > ALERT_THRESHOLDS.VOLATILITY_EXPAND) {
      alerts.push({
        id: `volatility_${signal.topic}_${Date.now()}`,
        topic: signal.topic,
        severity: ratio > 2.5 ? "high" : ratio > 2 ? "medium" : "low",
        reason: `Volatility expanded ${ratio.toFixed(1)}x above normal`,
        timestamp: Date.now(),
        relatedSignals: [signal.id],
      })
    }
  }

  return alerts
}

// ============================================
// SENTIMENT SHIFT ALERTS
// ============================================

function detectSentimentShifts(signals: Signal[]): Alert[] {
  const alerts: Alert[] = []

  // Group sentiment signals by topic
  const byTopic = new Map<string, Signal[]>()

  for (const signal of signals) {
    if (signal.type !== "sentiment") continue

    if (!byTopic.has(signal.topic)) {
      byTopic.set(signal.topic, [])
    }
    byTopic.get(signal.topic)!.push(signal)
  }

  // Check each topic
  for (const [topic, topicSignals] of byTopic) {
    const history = getSignalHistory(`sentiment_${topic}`, 10)

    if (history.length < 2) continue

    const current = topicSignals[0]?.value || 0
    const previous = history[history.length - 2]?.value || 0
    const change = current - previous

    if (Math.abs(change) > ALERT_THRESHOLDS.SENTIMENT_SHIFT) {
      const sentiment = change > 0 ? "improved" : "deteriorated"

      alerts.push({
        id: `sentiment_${topic}_${Date.now()}`,
        topic,
        severity: Math.abs(change) > 0.5 ? "high" : Math.abs(change) > 0.4 ? "medium" : "low",
        reason: `Market sentiment ${sentiment} significantly`,
        timestamp: Date.now(),
        relatedSignals: topicSignals.map(s => s.id),
      })
    }
  }

  return alerts
}

// ============================================
// ALERT UTILITIES
// ============================================

function sortAlerts(alerts: Alert[]): Alert[] {
  const severityOrder: Record<AlertSeverity, number> = {
    critical: 0,
    high: 1,
    medium: 2,
    low: 3,
  }

  return alerts.sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity])
}

function calculateStdDev(values: number[]): number {
  if (values.length < 2) return 0

  const mean = values.reduce((a, b) => a + b, 0) / values.length
  const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length

  return Math.sqrt(variance)
}

// Get active alerts (from last hour)
export function getActiveAlerts(alerts: Alert[]): Alert[] {
  const oneHourAgo = Date.now() - 60 * 60 * 1000

  return alerts.filter(a => a.timestamp > oneHourAgo)
}

// Get alerts by severity
export function getAlertsBySeverity(alerts: Alert[], severity: AlertSeverity): Alert[] {
  return alerts.filter(a => a.severity === severity)
}

// Get alerts by topic
export function getAlertsByTopic(alerts: Alert[], topic: string): Alert[] {
  return alerts.filter(a => a.topic === topic)
}

// Format alert for display
export function formatAlert(alert: Alert): string {
  const severityEmoji = {
    critical: "🔴",
    high: "🟠",
    medium: "🟡",
    low: "🟢",
  }

  return `${severityEmoji[alert.severity]} ${alert.topic}: ${alert.reason}`
}
