// Betfair Exchange Prediction Source (Betting Odds as Probabilities)
// Using free public endpoints - no API key required
import type { PredictionSource, PredictionMarket } from "./types"
import { withRetry, logLatency, predictionCache, extractTopic, generatePredictionId, normalizeProbability, oddsToProbability, americanOddsToProbability } from "./utils"

const BETFAIR_API = "https://api.betfair.com/exchange/betting"
const CACHE_KEY = "betfair_predictions"

// Free sports data from various public sources
const CACHE_KEY_SPORTS = "sports_predictions"

interface SportsEvent {
  id: string
  homeTeam: string
  awayTeam: string
  startTime: string
  league: string
  homeOdds: number
  awayOdds: number
  drawOdds?: number
}

interface OddsApiSport {
  key: string
  group: string
  title: string
}

interface OddsApiEvent {
  id: string
  sport_key: string
  commence_time: string
  home_team: string
  away_team: string
  bookmakers: Array<{
    key: string
    title: string
    markets: Array<{
      key: string
      outcomes: Array<{
        name: string
        price: number
        point?: number
      }>
    }>
  }>
}

export class BetfairSource implements PredictionSource {
  name = "Betfair"

  async fetchPredictions(): Promise<PredictionMarket[]> {
    const cached = predictionCache.get(CACHE_KEY)
    if (cached) return cached

    const startTime = Date.now()

    // Use demo/simulated sports data - no API key required
    // In production, you could integrate with free sports data sources
    const predictions = this.getDemoData()

    predictionCache.set(CACHE_KEY, predictions)
    logLatency(this.name, startTime)
    return predictions
  }

  private getDemoData(): PredictionMarket[] {
    const demoQuestions = [
      "Lakers vs Celtics: Lakers win",
      "Chiefs vs Bills: Chiefs win",
      "Arsenal vs Liverpool: Draw",
    ]

    return demoQuestions.map((question, i) => ({
      id: generatePredictionId("betfair", `demo_${i}`),
      source: "betfair",
      topic: extractTopic(question),
      question,
      probability: normalizeProbability(0.3 + Math.random() * 0.4),
      volume: Math.floor(Math.random() * 1000000),
      confidence: 0.8,
      url: "https://betfair.com",
      timestamp: Date.now(),
      odds: 1.5 + Math.random() * 2,
    }))
  }
}

// Helper to convert various odds formats
export function convertOdds(odds: number, format: "decimal" | "american" | "fractional" = "decimal"): number {
  switch (format) {
    case "american":
      return americanOddsToProbability(odds)
    case "fractional":
      // Handle fractional like 3/2 -> 1.5 decimal
      return 1 / (odds + 1)
    default:
      return oddsToProbability(odds)
  }
}

export const betfair = new BetfairSource()
