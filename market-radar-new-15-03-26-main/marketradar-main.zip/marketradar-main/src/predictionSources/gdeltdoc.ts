// GDELT Document API - Geopolitical Prediction Signals
import type { PredictionSource, PredictionMarket } from "./types"
import { withRetry, logLatency, predictionCache, extractTopic, generatePredictionId, normalizeProbability } from "./utils"

const GDELT_DOC_API = "https://api.gdeltproject.org/api/v2/doc/doc"
const CACHE_KEY = "gdelt_predictions"

// Google Trends
const GOOGLE_TRENDS_API = "https://trends.google.com/trends/api"
const CACHE_KEY_TRENDS = "google_trends_predictions"

// Fear & Greed Index
const FEAR_GREED_API = "https://api.alternative.me/fng"
const CACHE_KEY_FG = "fear_greed_predictions"

interface GdeltArticle {
  seendate: string
  url: string
  title: string
  socialimage: string
  domain: string
  language: string
  sentiment: number
  tone: number
}

interface GdeltResponse {
  articles: GdeltArticle[]
  nextPage: string | null
}

interface GoogleTrendsWidget {
  request: {
    widgets: Array<{
      keyword: string
      geo: string
      comparisonItem: Array<{ keyword: string; geo: string; time: string }>
    }>
  }
}

interface FearGreedIndex {
  data: Array<{
    value: string
    value_classification: string
    timestamp: string
    time_until_update: string
  }>
}

export class GdeltSource implements PredictionSource {
  name = "GDELT"

  async fetchPredictions(): Promise<PredictionMarket[]> {
    const cached = predictionCache.get(CACHE_KEY)
    if (cached) return cached

    const startTime = Date.now()

    try {
      // Fetch latest geopolitical articles
      const response = await withRetry(async () => {
        const res = await fetch(
          `${GDELT_DOC_API}?format=json&mode=artlist&sort=DateDesc&maxrecords=50&query=politics OR war OR election OR economy`
        )
        if (!res.ok) throw new Error(`GDELT API error: ${res.status}`)
        return res.json() as Promise<GdeltResponse>
      })

      const predictions: PredictionMarket[] = []

      // Analyze sentiment to generate prediction signals
      const sentimentTopics = this.analyzeSentiment(response.articles || [])

      for (const topic of sentimentTopics) {
        predictions.push({
          id: generatePredictionId("gdelt", topic.topic),
          source: "gdelt",
          topic: topic.topic,
          question: topic.question,
          probability: topic.probability,
          confidence: topic.confidence,
          url: "https://www.gdeltproject.org",
          timestamp: Date.now(),
          rawData: topic.rawData,
        })
      }

      predictionCache.set(CACHE_KEY, predictions)
      logLatency(this.name, startTime)
      return predictions
    } catch (error) {
      console.error("GDELT fetch error:", error)
      return this.getDemoData()
    }
  }

  private analyzeSentiment(articles: GdeltArticle[]): Array<{
    topic: string
    question: string
    probability: number
    confidence: number
    rawData: unknown
  }> {
    const topics: Array<{
      topic: string
      question: string
      probability: number
      confidence: number
      rawData: unknown
    }> = []

    // Analyze overall sentiment
    const avgSentiment = articles.reduce((sum, a) => sum + a.sentiment, 0) / (articles.length || 1)
    const avgTone = articles.reduce((sum, a) => sum + a.tone, 0) / (articles.length || 1)

    // Convert sentiment (-10 to 10) to probability (0 to 1)
    // Positive sentiment -> higher probability of stability
    const sentimentProb = normalizeProbability((avgSentiment + 10) / 20)
    const confidence = Math.min(0.7, articles.length / 100)

    // Generate geopolitical topics based on article content
    const topicKeywords: Record<string, string> = {
      "Geopolitical Stability": "Will geopolitical tensions remain stable in the next 30 days?",
      "Economic Outlook": "Will global economic conditions improve in the next quarter?",
      "Political Risk": "Will political risk decrease globally?",
    }

    for (const [topic, question] of Object.entries(topicKeywords)) {
      topics.push({
        topic,
        question,
        probability: sentimentProb,
        confidence,
        rawData: { avgSentiment, avgTone, articleCount: articles.length },
      })
    }

    return topics
  }

  private getDemoData(): PredictionMarket[] {
    const demoQuestions = [
      { topic: "Geopolitical Stability", question: "Will geopolitical tensions escalate in Q2?" },
      { topic: "Economic Outlook", question: "Will global markets show positive growth?" },
    ]

    return demoQuestions.map((q, i) => ({
      id: generatePredictionId("gdelt", `demo_${i}`),
      source: "gdelt",
      topic: q.topic,
      question: q.question,
      probability: normalizeProbability(0.4 + Math.random() * 0.3),
      confidence: 0.4,
      url: "https://www.gdeltproject.org",
      timestamp: Date.now(),
    }))
  }
}

// Google Trends as crowd attention predictor
export class GoogleTrendsSource implements PredictionSource {
  name = "GoogleTrends"

  async fetchPredictions(): Promise<PredictionMarket[]> {
    const cached = predictionCache.get(CACHE_KEY_TRENDS)
    if (cached) return cached

    const startTime = Date.now()

    // Note: Google Trends API is limited, using demo data
    // In production, you'd use the Google Trends API
    const predictions: PredictionMarket[] = []

    const demoTopics = [
      "Bitcoin",
      "Recession",
      "Inflation",
      "AI",
      "Stock Market",
    ]

    for (const topic of demoTopics) {
      predictions.push({
        id: generatePredictionId("googletrends", topic.toLowerCase()),
        source: "googletrends",
        topic: extractTopic(topic),
        question: `Search interest in ${topic}`,
        probability: normalizeProbability(0.3 + Math.random() * 0.5),
        confidence: 0.3,
        url: `https://trends.google.com/trends?q=${encodeURIComponent(topic)}`,
        timestamp: Date.now(),
      })
    }

    predictionCache.set(CACHE_KEY_TRENDS, predictions)
    logLatency(this.name, startTime)
    return predictions
  }
}

// Fear & Greed Index
export class FearGreedSource implements PredictionSource {
  name = "FearGreed"

  async fetchPredictions(): Promise<PredictionMarket[]> {
    const cached = predictionCache.get(CACHE_KEY_FG)
    if (cached) return cached

    const startTime = Date.now()

    try {
      const response = await withRetry(async () => {
        const res = await fetch(FEAR_GREED_API)
        if (!res.ok) throw new Error(`FearGreed API error: ${res.status}`)
        return res.json() as Promise<FearGreedIndex>
      })

      const latest = response.data[0]
      const value = parseInt(latest.value) / 100 // 0 to 1

      // Fear & Greed Index: 0 = Extreme Fear, 1 = Extreme Greed
      // Use as proxy for market prediction
      const predictions: PredictionMarket[] = [
        {
          id: generatePredictionId("feargreed", "index"),
          source: "feargreed",
          topic: "Crypto Market Sentiment",
          question: "Crypto Fear & Greed Index",
          probability: value, // Higher = more greedy = potentially overbought
          confidence: 0.6,
          url: "https://alternative.me/crypto/fear-and-greed-index/",
          timestamp: Date.now(),
          rawData: latest,
        },
      ]

      predictionCache.set(CACHE_KEY_FG, predictions)
      logLatency(this.name, startTime)
      return predictions
    } catch (error) {
      console.error("FearGreed fetch error:", error)
      return this.getDemoData()
    }
  }

  private getDemoData(): PredictionMarket[] {
    return [
      {
        id: generatePredictionId("feargreed", "demo"),
        source: "feargreed",
        topic: "Crypto Market Sentiment",
        question: "Crypto Fear & Greed Index",
        probability: normalizeProbability(0.5),
        confidence: 0.5,
        url: "https://alternative.me/crypto/fear-and-greed-index/",
        timestamp: Date.now(),
      },
    ]
  }
}

export const gdelt = new GdeltSource()
export const googleTrends = new GoogleTrendsSource()
export const fearGreed = new FearGreedSource()
