// Metaculus Prediction Source
import type { PredictionSource, PredictionMarket } from "./types"
import { withRetry, logLatency, predictionCache, extractTopic, generatePredictionId, normalizeProbability } from "./utils"

const METACULUS_API = "https://www.metaculus.com/api2"
const CACHE_KEY = "metaculus_predictions"

interface MetaculusQuestion {
  id: number
  title: string
  slug: string
  description: string
  url: string
  published: number
  close_time: number
  resolve_time?: number
  status: string
  type: string
  categories: string[]
  votes: number
  comments: number
  views: number
  activity: number
  communities: string[]
  prediction: {
    value: number
    density: Array<{ x: number; y: number }>
    quantiles: Array<{ q: number; x: number }>
  }
}

interface MetaculusResponse {
  results: MetaculusQuestion[]
  count: number
  next: string | null
}

export class MetaculusSource implements PredictionSource {
  name = "Metaculus"

  async fetchPredictions(): Promise<PredictionMarket[]> {
    const cached = predictionCache.get(CACHE_KEY)
    if (cached) return cached

    const startTime = Date.now()

    try {
      const response = await withRetry(async () => {
        const res = await fetch(`${METACULUS_API}/questions?status=open&limit=100&order_by=activity`)
        if (!res.ok) throw new Error(`Metaculus API error: ${res.status}`)
        return res.json() as Promise<MetaculusResponse>
      })

      const predictions: PredictionMarket[] = []

      for (const question of response.results || []) {
        if (question.close_time && question.close_time < Date.now() * 1000) continue

        predictions.push({
          id: generatePredictionId("metaculus", question.id.toString()),
          source: "metaculus",
          topic: extractTopic(question.title),
          question: question.title,
          probability: normalizeProbability(question.prediction?.value || 0.5),
          volume: question.votes,
          confidence: question.votes > 1000 ? 0.9 : question.votes > 100 ? 0.7 : 0.5,
          url: question.url,
          timestamp: Date.now(),
          rawData: question,
          outcome: "Yes",
        })
      }

      predictionCache.set(CACHE_KEY, predictions)
      logLatency(this.name, startTime)
      return predictions
    } catch (error) {
      console.error("Metaculus fetch error:", error)
      return this.getDemoData()
    }
  }

  private getDemoData(): PredictionMarket[] {
    const demoQuestions = [
      "Will AGI be achieved by 2030?",
      "Will nuclear fusion achieve net energy gain?",
      "Will human lifespan exceed 120 years?",
      "Will quantum computing break encryption?",
    ]

    return demoQuestions.map((question, i) => ({
      id: generatePredictionId("metaculus", `demo_${i}`),
      source: "metaculus",
      topic: extractTopic(question),
      question,
      probability: normalizeProbability(0.3 + Math.random() * 0.5),
      volume: Math.floor(Math.random() * 5000),
      confidence: 0.7,
      url: `https://www.metaculus.com/questions/demo_${i}`,
      timestamp: Date.now(),
    }))
  }
}

export const metaculus = new MetaculusSource()
