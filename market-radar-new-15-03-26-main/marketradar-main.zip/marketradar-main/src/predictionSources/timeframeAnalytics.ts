// Timeframe Analytics Module
// Tracks probability change over time

import type { PredictionMarket, TimeframeAnalytics, ProbabilityHistoryPoint } from "./types"
import { getPredictionHistory } from "./aggregator"

const MS_PER_HOUR = 60 * 60 * 1000
const MS_PER_DAY = 24 * MS_PER_HOUR

// Time periods in milliseconds
const PERIODS = {
  HOUR: MS_PER_HOUR,
  DAY: MS_PER_DAY,
  WEEK: 7 * MS_PER_DAY,
  MONTH: 30 * MS_PER_DAY,
}

// Get probability change over a time period
function getChangeForPeriod(
  history: ProbabilityHistoryPoint[],
  periodMs: number
): number {
  const now = Date.now()
  const cutoff = now - periodMs

  // Get points within the period
  const recentPoints = history.filter((p) => p.timestamp >= cutoff)

  if (recentPoints.length < 2) return 0

  // Get earliest and latest in period
  const sorted = [...recentPoints].sort((a, b) => a.timestamp - b.timestamp)
  const earliest = sorted[0]
  const latest = sorted[sorted.length - 1]

  return latest.probability - earliest.probability
}

// Calculate momentum score
function calculateMomentumScore(
  change24h: number,
  change7d: number,
  change30d: number
): number {
  // Weighted average with recent changes weighted more
  // Recent momentum is more predictive
  const weighted =
    change24h * 0.5 + change7d * 0.3 + change30d * 0.2

  // Normalize to -1 to 1 range
  // Positive = bullish momentum, negative = bearish
  return Math.max(-1, Math.min(1, weighted))
}

// Get timeframe analytics for a specific topic
export function getTimeframeAnalyticsForTopic(
  topic: string,
  predictions: PredictionMarket[]
): TimeframeAnalytics[] {
  const results: TimeframeAnalytics[] = []

  // Get historical data
  const historyMap = getPredictionHistory(topic)

  if (historyMap.size === 0) {
    // If no history, use current predictions
    const currentProb =
      predictions.reduce((sum, p) => sum + p.probability, 0) / predictions.length

    return [
      {
        topic,
        probability: currentProb,
        change_24h: 0,
        change_7d: 0,
        change_30d: 0,
        momentum_score: 0,
        history: [],
      },
    ]
  }

  // Calculate for each source
  for (const [source, history] of historyMap) {
    const currentPrediction = predictions.find(
      (p) => p.topic === topic && p.source === source
    )
    const currentProb = currentPrediction?.probability || 0

    const change24h = getChangeForPeriod(history, PERIODS.DAY)
    const change7d = getChangeForPeriod(history, PERIODS.WEEK)
    const change30d = getChangeForPeriod(history, PERIODS.MONTH)

    const momentum_score = calculateMomentumScore(change24h, change7d, change30d)

    results.push({
      topic,
      probability: currentProb,
      change_24h: change24h,
      change_7d: change7d,
      change_30d: change30d,
      momentum_score,
      history: history.slice(-50), // Last 50 points
    })
  }

  // Add aggregate if multiple sources
  if (historyMap.size > 1) {
    const allHistory: ProbabilityHistoryPoint[] = []
    for (const history of historyMap.values()) {
      allHistory.push(...history)
    }

    // Sort by timestamp
    allHistory.sort((a, b) => a.timestamp - b.timestamp)

    // Calculate aggregate changes
    const aggregate24h = getChangeForPeriod(allHistory, PERIODS.DAY)
    const aggregate7d = getChangeForPeriod(allHistory, PERIODS.WEEK)
    const aggregate30d = getChangeForPeriod(allHistory, PERIODS.MONTH)

    const currentProb =
      predictions
        .filter((p) => p.topic === topic)
        .reduce((sum, p) => sum + p.probability, 0) /
      predictions.filter((p) => p.topic === topic).length

    results.push({
      topic,
      probability: currentProb,
      change_24h: aggregate24h,
      change_7d: aggregate7d,
      change_30d: aggregate30d,
      momentum_score: calculateMomentumScore(aggregate24h, aggregate7d, aggregate30d),
      history: allHistory.slice(-50),
    })
  }

  return results
}

// Get all timeframe analytics
export function getAllTimeframeAnalytics(
  predictions: PredictionMarket[]
): TimeframeAnalytics[] {
  // Get unique topics
  const topics = [...new Set(predictions.map((p) => p.topic))]

  const results: TimeframeAnalytics[] = []

  for (const topic of topics) {
    const topicPredictions = predictions.filter((p) => p.topic === topic)
    const analytics = getTimeframeAnalyticsForTopic(topic, topicPredictions)

    // Add aggregate (last in list)
    if (analytics.length > 0) {
      results.push(analytics[analytics.length - 1])
    }
  }

  return results.sort((a, b) => Math.abs(b.momentum_score) - Math.abs(a.momentum_score))
}

// Get trending topics (by momentum)
export function getTrendingTopics(
  predictions: PredictionMarket[],
  limit: number = 10
): TimeframeAnalytics[] {
  const analytics = getAllTimeframeAnalytics(predictions)

  // Sort by absolute momentum score
  return analytics
    .filter((a) => a.history.length > 0) // Only with history
    .sort((a, b) => Math.abs(b.momentum_score) - Math.abs(a.momentum_score))
    .slice(0, limit)
}

// Get topics with most change in last 24h
export function getMostChangedLast24h(
  predictions: PredictionMarket[],
  limit: number = 10
): TimeframeAnalytics[] {
  const analytics = getAllTimeframeAnalytics(predictions)

  return analytics
    .filter((a) => a.change_24h !== 0)
    .sort((a, b) => Math.abs(b.change_24h) - Math.abs(a.change_24h))
    .slice(0, limit)
}

// Get bullish topics (positive momentum)
export function getBullishTopics(
  predictions: PredictionMarket[],
  limit: number = 10
): TimeframeAnalytics[] {
  const analytics = getAllTimeframeAnalytics(predictions)

  return analytics
    .filter((a) => a.momentum_score > 0 && a.history.length > 0)
    .sort((a, b) => b.momentum_score - a.momentum_score)
    .slice(0, limit)
}

// Get bearish topics (negative momentum)
export function getBearishTopics(
  predictions: PredictionMarket[],
  limit: number = 10
): TimeframeAnalytics[] {
  const analytics = getAllTimeframeAnalytics(predictions)

  return analytics
    .filter((a) => a.momentum_score < 0 && a.history.length > 0)
    .sort((a, b) => a.momentum_score - b.momentum_score)
    .slice(0, limit)
}

// Format change as percentage string
export function formatChange(change: number): string {
  const percent = Math.abs(change * 100).toFixed(1)
  const sign = change > 0 ? "+" : change < 0 ? "-" : ""
  return `${sign}${percent}%`
}

// Get momentum label
export function getMomentumLabel(score: number): string {
  if (score > 0.5) return "Strong Bullish"
  if (score > 0.2) return "Bullish"
  if (score > -0.2) return "Neutral"
  if (score > -0.5) return "Bearish"
  return "Strong Bearish"
}
