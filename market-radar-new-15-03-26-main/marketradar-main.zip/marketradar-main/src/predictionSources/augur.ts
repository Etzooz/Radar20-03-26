// Augur (v2) Prediction Source
import type { PredictionSource, PredictionMarket } from "./types"
import { withRetry, logLatency, predictionCache, extractTopic, generatePredictionId, normalizeProbability } from "./utils"

// Augur GraphQL endpoint
const AUGUR_GRAPHQL = "https://api.augur.net/graphql"
const CACHE_KEY = "augur_predictions"

interface AugurMarket {
  id: string
  question: string
  description: string
  endDate: number
  finalizationDate: number
  volume: string
  liquidity: string
  fee: string
  reportingFee: string
  outcomes: Array<{
    id: string
    name: string
    price: string
    volume: string
  }>
}

export class AugurSource implements PredictionSource {
  name = "Augur"

  async fetchPredictions(): Promise<PredictionMarket[]> {
    const cached = predictionCache.get(CACHE_KEY)
    if (cached) return cached

    const startTime = Date.now()

    // Augur uses GraphQL, so we need to construct a query
    const query = {
      query: `
        query {
          markets(first: 50, sortBy: volume) {
            id
            question
            description
            endDate
            finalizationDate
            volume
            liquidity
            outcomes {
              id
              name
              price
              volume
            }
          }
        }
      `,
    }

    try {
      const response = await withRetry(async () => {
        const res = await fetch(AUGUR_GRAPHQL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(query),
        })
        if (!res.ok) throw new Error(`Augur API error: ${res.status}`)
        return res.json() as Promise<{ data: { markets: AugurMarket[] } }>
      })

      const predictions: PredictionMarket[] = []

      for (const market of response.data?.markets || []) {
        // Get the "Yes" outcome (usually outcome 1)
        const yesOutcome = market.outcomes.find(
          (o) => o.name.toLowerCase().includes("yes") || o.name === "1"
        )

        predictions.push({
          id: generatePredictionId("augur", market.id),
          source: "augur",
          topic: extractTopic(market.question),
          question: market.question,
          probability: normalizeProbability(parseFloat(yesOutcome?.price || "0.5")),
          volume: parseFloat(market.volume),
          liquidity: parseFloat(market.liquidity),
          confidence: parseFloat(market.volume) > 100000 ? 0.9 : parseFloat(market.volume) > 10000 ? 0.7 : 0.5,
          url: `https://augur.net/markets/${market.id}`,
          timestamp: Date.now(),
          rawData: market,
          outcome: "Yes",
        })
      }

      predictionCache.set(CACHE_KEY, predictions)
      logLatency(this.name, startTime)
      return predictions
    } catch (error) {
      console.error("Augur fetch error:", error)
      return this.getDemoData()
    }
  }

  private getDemoData(): PredictionMarket[] {
    const demoQuestions = [
      "Will there be a major pandemic by 2027?",
      "Will global temps rise above 2C by 2030?",
    ]

    return demoQuestions.map((question, i) => ({
      id: generatePredictionId("augur", `demo_${i}`),
      source: "augur",
      topic: extractTopic(question),
      question,
      probability: normalizeProbability(0.3 + Math.random() * 0.5),
      volume: Math.floor(Math.random() * 50000),
      confidence: 0.5,
      url: "https://augur.net",
      timestamp: Date.now(),
    }))
  }
}

export const augur = new AugurSource()
