// Arbitrage Detector
// Detects disagreement across prediction platforms

import type { PredictionMarket, ArbitrageOpportunity } from "./types"
import { calculateStdDev } from "./utils"

// Threshold configurations
const ARBITRAGE_THRESHOLDS = {
  HIGH: 0.20, // 20% difference = high severity
  MEDIUM: 0.15, // 15% difference = medium severity
  LOW: 0.10, // 10% difference = low severity
}

// Detect arbitrage opportunities within a topic
export function detectArbitrageForTopic(predictions: PredictionMarket[]): ArbitrageOpportunity[] {
  const opportunities: ArbitrageOpportunity[] = []

  // Need at least 2 predictions from different sources
  if (predictions.length < 2) return opportunities

  // Group by source
  const bySource = new Map<string, PredictionMarket[]>()
  for (const p of predictions) {
    if (!bySource.has(p.source)) {
      bySource.set(p.source, [])
    }
    bySource.get(p.source)!.push(p)
  }

  // Only check if we have multiple sources
  if (bySource.size < 2) return opportunities

  // Get unique sources with their probabilities
  const sourceProbs: Array<{ source: string; probability: number }> = []

  for (const [source, sourcePredictions] of bySource) {
    // Use average probability for each source
    const avgProb = sourcePredictions.reduce((sum, p) => sum + p.probability, 0) / sourcePredictions.length
    sourceProbs.push({ source, probability: avgProb })
  }

  // Calculate max difference
  const probabilities = sourceProbs.map((s) => s.probability)
  const maxProb = Math.max(...probabilities)
  const minProb = Math.min(...probabilities)
  const maxDifference = maxProb - minProb

  // Determine severity
  let severity: "high" | "medium" | "low" = "low"
  if (maxDifference >= ARBITRAGE_THRESHOLDS.HIGH) {
    severity = "high"
  } else if (maxDifference >= ARBITRAGE_THRESHOLDS.MEDIUM) {
    severity = "medium"
  } else if (maxDifference >= ARBITRAGE_THRESHOLDS.LOW) {
    severity = "low"
  }

  // Only report if above threshold
  if (maxDifference >= ARBITRAGE_THRESHOLDS.LOW) {
    opportunities.push({
      type: "prediction_arbitrage",
      severity,
      topic: predictions[0].topic,
      sources: sourceProbs.map((s) => s.source),
      probabilities: sourceProbs.map((s) => s.probability),
      max_difference: maxDifference,
      timestamp: Date.now(),
    })
  }

  return opportunities
}

// Detect all arbitrage opportunities across predictions
export function detectAllArbitrage(predictions: PredictionMarket[]): ArbitrageOpportunity[] {
  const opportunities: ArbitrageOpportunity[] = []

  // Group by topic
  const byTopic = new Map<string, PredictionMarket[]>()
  for (const p of predictions) {
    if (!byTopic.has(p.topic)) {
      byTopic.set(p.topic, [])
    }
    byTopic.get(p.topic)!.push(p)
  }

  // Check each topic
  for (const [topic, topicPredictions] of byTopic) {
    const topicOpportunities = detectArbitrageForTopic(topicPredictions)
    opportunities.push(...topicOpportunities)
  }

  // Sort by severity and difference
  return opportunities.sort((a, b) => {
    const severityOrder = { high: 0, medium: 1, low: 2 }
    const severityDiff = severityOrder[a.severity] - severityOrder[b.severity]
    if (severityDiff !== 0) return severityDiff
    return b.max_difference - a.max_difference
  })
}

// Get high severity arbitrage only
export function getHighSeverityArbitrage(predictions: PredictionMarket[]): ArbitrageOpportunity[] {
  return detectAllArbitrage(predictions).filter((a) => a.severity === "high")
}

// Calculate disagreement score (0-1)
export function calculateDisagreementScore(predictions: PredictionMarket[]): number {
  if (predictions.length < 2) return 0

  const probabilities = predictions.map((p) => p.probability)
  const stdDev = calculateStdDev(probabilities)

  // Normalize: std dev of 0.5 = max disagreement (1)
  return Math.min(1, stdDev * 2)
}

// Get most disagreed topics
export function getMostDisagreedTopics(
  predictions: PredictionMarket[],
  limit: number = 10
): Array<{ topic: string; disagreement: number; sources: string[] }> {
  const byTopic = new Map<string, PredictionMarket[]>()

  for (const p of predictions) {
    if (!byTopic.has(p.topic)) {
      byTopic.set(p.topic, [])
    }
    byTopic.get(p.topic)!.push(p)
  }

  const disagreements: Array<{ topic: string; disagreement: number; sources: string[] }> = []

  for (const [topic, topicPredictions] of byTopic) {
    if (topicPredictions.length < 2) continue

    const disagreement = calculateDisagreementScore(topicPredictions)
    const sources = [...new Set(topicPredictions.map((p) => p.source))]

    disagreements.push({ topic, disagreement, sources })
  }

  return disagreements
    .filter((d) => d.sources.length >= 2)
    .sort((a, b) => b.disagreement - a.disagreement)
    .slice(0, limit)
}

// Calculate source-specific bias
export function calculateSourceBias(
  predictions: PredictionMarket[],
  aggregatedProbability: number
): Map<string, number> {
  const bias = new Map<string, number>()

  const bySource = new Map<string, PredictionMarket[]>()

  for (const p of predictions) {
    if (!bySource.has(p.source)) {
      bySource.set(p.source, [])
    }
    bySource.get(p.source)!.push(p)
  }

  for (const [source, sourcePredictions] of bySource) {
    const avgProb = sourcePredictions.reduce((sum, p) => sum + p.probability, 0) / sourcePredictions.length
    bias.set(source, avgProb - aggregatedProbability)
  }

  return bias
}
