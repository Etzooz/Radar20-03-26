// Kalshi Prediction Source
import type { PredictionSource, PredictionMarket } from './types'
import { withRetry, logLatency, predictionCache, extractTopic, generatePredictionId, normalizeProbability } from './utils'

const KALSHI_API = "https://api.kalshi.com/trade-api/v2"
const CACHE_KEY = "kalshi_predictions"

interface KalshiMarket {
  id: string
  title: string
  subtitle: string
  status: string
  exchange: string
  market_type: string
  event_type: string
  close_time: string
  settle_time: string
  volume: number
  open_interest: number
  rules: string
  description: string
  strike: string
  yes_ask: number
  yes_bid: number
  no_ask: number
  no_bid: number
  last_price: number
}

interface KalshiResponse {
  markets: KalshiMarket[]
  cursor: string | null
}

export class KalshiSource implements PredictionSource {
  name = "Kalshi"

  async fetchPredictions(): Promise<PredictionMarket[]> {
    const cached = predictionCache.get(CACHE_KEY)
    if (cached) return cached

    const startTime = Date.now()

    try {
      const response = await withRetry(async () => {
        const res = await fetch(`${KALSHI_API}/markets?status=active&limit=100`)
        if (!res.ok) throw new Error(`Kalshi API error: ${res.status}`)
        return res.json() as Promise<KalshiResponse>
      })

      const predictions: PredictionMarket[] = []

      for (const market of response.markets || []) {
        // Use mid-price between yes bid/ask
        const yesMid = (market.yes_bid + market.yes_ask) / 2
        const probability = yesMid || market.last_price || 0.5

        predictions.push({
          id: generatePredictionId("kalshi", market.id),
          source: "kalshi",
          topic: extractTopic(market.title),
          question: market.title,
          probability: normalizeProbability(probability),
          volume: market.volume,
          liquidity: market.open_interest,
          confidence: market.volume > 100000 ? 0.9 : market.volume > 10000 ? 0.7 : 0.5,
          url: `https://kalshi.com/markets/${market.id}`,
          timestamp: Date.now(),
          rawData: market,
          outcome: "Yes",
        })
      }

      predictionCache.set(CACHE_KEY, predictions)
      logLatency(this.name, startTime)
      return predictions
    } catch (error) {
      console.error("Kalshi fetch error:", error)
      return this.getDemoData()
    }
  }

  private getDemoData(): PredictionMarket[] {
    const demoQuestions = [
      "Will GDP growth exceed 3% in Q1 2026?",
      "Will CPI inflation exceed 4% annually?",
      "Will unemployment drop below 4%?",
      "Will S&P 500 reach 6000?",
      "Will oil prices exceed $100/barrel?",
      "Will Fed maintain rates in 2026?",
    ]

    return demoQuestions.map((question, i) => ({
      id: generatePredictionId("kalshi", `demo_${i}`),
      source: "kalshi",
      topic: extractTopic(question),
      question,
      probability: normalizeProbability(0.3 + Math.random() * 0.5),
      volume: Math.floor(Math.random() * 500000),
      liquidity: Math.floor(Math.random() * 200000),
      confidence: 0.7,
      url: `https://kalshi.com/markets/demo_${i}`,
      timestamp: Date.now(),
    }))
  }
}

export const kalshi = new KalshiSource()
