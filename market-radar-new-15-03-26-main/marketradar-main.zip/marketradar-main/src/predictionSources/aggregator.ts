// Aggregated Prediction Engine
// Combines predictions from multiple sources using weighted averages

import type { PredictionMarket, AggregatedPrediction } from "./types"
import { SOURCE_WEIGHTS } from "./types"
import { calculateVariance, calculateStdDev } from "./utils"

// In-memory history for timeframe analytics
const predictionHistory = new Map<string, Map<string, { timestamp: number; probability: number }[]>>()
// topic -> source -> history[]

// Store prediction for historical tracking
export function storePredictionHistory(prediction: PredictionMarket): void {
  const topicHistory = predictionHistory.get(prediction.topic) || new Map()
  const sourceHistory = topicHistory.get(prediction.source) || []

  sourceHistory.push({
    timestamp: prediction.timestamp,
    probability: prediction.probability,
  })

  // Keep only last 100 entries per source per topic
  if (sourceHistory.length > 100) {
    sourceHistory.shift()
  }

  topicHistory.set(prediction.source, sourceHistory)
  predictionHistory.set(prediction.topic, topicHistory)
}

// Get historical predictions
export function getPredictionHistory(
  topic: string,
  source?: string
): Map<string, { timestamp: number; probability: number }[]> {
  const topicHistory = predictionHistory.get(topic)
  if (!topicHistory) return new Map()

  if (source) {
    const sourceHistory = topicHistory.get(source)
    return sourceHistory ? new Map([[source, sourceHistory]]) : new Map()
  }

  return topicHistory
}

// Aggregate predictions for a single topic
export function aggregatePredictionsForTopic(
  predictions: PredictionMarket[]
): AggregatedPrediction {
  if (predictions.length === 0) {
    return {
      topic: "",
      aggregated_probability: 0,
      source_count: 0,
      variance: 0,
      confidence: 0,
      sources: [],
      predictions: [],
    }
  }

  // Get unique sources
  const sources = [...new Set(predictions.map((p) => p.source))]

  // Calculate weighted average
  let totalWeight = 0
  let weightedSum = 0

  for (const prediction of predictions) {
    const weight = SOURCE_WEIGHTS[prediction.source] || 0.5
    const confidenceWeight = prediction.confidence || 0.5
    const volumeWeight = Math.log10((prediction.volume || 1) + 1) / 10 // Log scale volume
    const finalWeight = weight * confidenceWeight * (1 + volumeWeight)

    weightedSum += prediction.probability * finalWeight
    totalWeight += finalWeight
  }

  const aggregated_probability = totalWeight > 0 ? weightedSum / totalWeight : 0

  // Calculate variance
  const probabilities = predictions.map((p) => p.probability)
  const variance = calculateVariance(probabilities)

  // Calculate confidence based on:
  // - More sources = higher confidence
  // - Higher liquidity = higher confidence
  // - Lower variance = higher confidence
  const sourceMultiplier = Math.min(sources.length / 5, 1) // Max at 5 sources
  const liquidityAvg = predictions.reduce((sum, p) => sum + (p.liquidity || p.volume || 0), 0) / predictions.length
  const liquidityMultiplier = Math.min(Math.log10(liquidityAvg + 1) / 10, 1)
  const variancePenalty = Math.max(0, 1 - variance * 4) // Penalize high variance

  const confidence = (sourceMultiplier * 0.4 + liquidityMultiplier * 0.3 + variancePenalty * 0.3)

  return {
    topic: predictions[0].topic,
    aggregated_probability,
    source_count: sources.length,
    variance,
    confidence: Math.min(1, Math.max(0, confidence)),
    sources,
    predictions,
  }
}

// Aggregate all predictions by topic
export function aggregateAllPredictions(
  predictions: PredictionMarket[]
): AggregatedPrediction[] {
  // Store all predictions for history
  predictions.forEach(storePredictionHistory)

  // Group by topic
  const byTopic = new Map<string, PredictionMarket[]>()

  for (const prediction of predictions) {
    const topic = prediction.topic
    if (!byTopic.has(topic)) {
      byTopic.set(topic, [])
    }
    byTopic.get(topic)!.push(prediction)
  }

  // Aggregate each topic
  const results: AggregatedPrediction[] = []

  for (const [topic, topicPredictions] of byTopic) {
    const aggregated = aggregatePredictionsForTopic(topicPredictions)
    aggregated.topic = topic
    results.push(aggregated)
  }

  // Sort by confidence
  return results.sort((a, b) => b.confidence - a.confidence)
}

// Get weighted probability for a specific topic
export function getAggregatedProbabilityForTopic(
  predictions: PredictionMarket[],
  topic: string
): AggregatedPrediction | null {
  const topicPredictions = predictions.filter(
    (p) => p.topic.toLowerCase() === topic.toLowerCase()
  )

  if (topicPredictions.length === 0) return null

  return aggregatePredictionsForTopic(topicPredictions)
}

// Calculate agreement score between sources
export function calculateAgreementScore(predictions: PredictionMarket[]): number {
  if (predictions.length < 2) return 1

  const probabilities = predictions.map((p) => p.probability)
  const stdDev = calculateStdDev(probabilities)

  // Convert std dev to 0-1 agreement score
  // Std dev of 0 = 1 (perfect agreement)
  // Std dev of 0.5 = 0 (no agreement)
  return Math.max(0, 1 - stdDev * 2)
}

// Get top predictions across all sources
export function getTopPredictions(
  predictions: PredictionMarket[],
  limit: number = 10,
  sortBy: "probability" | "volume" | "confidence" = "confidence"
): PredictionMarket[] {
  return [...predictions]
    .sort((a, b) => {
      switch (sortBy) {
        case "probability":
          return b.probability - a.probability
        case "volume":
          return (b.volume || 0) - (a.volume || 0)
        case "confidence":
        default:
          return (b.confidence || 0) - (a.confidence || 0)
      }
    })
    .slice(0, limit)
}

// Get predictions by source
export function getPredictionsBySource(
  predictions: PredictionMarket[],
  source: string
): PredictionMarket[] {
  return predictions.filter((p) => p.source === source)
}

// Get sources summary
export function getSourcesSummary(predictions: PredictionMarket[]): Array<{
  source: string
  count: number
  avgProbability: number
  avgConfidence: number
  totalVolume: number
}> {
  const bySource = new Map<string, PredictionMarket[]>()

  for (const prediction of predictions) {
    if (!bySource.has(prediction.source)) {
      bySource.set(prediction.source, [])
    }
    bySource.get(prediction.source)!.push(prediction)
  }

  const summary: Array<{
    source: string
    count: number
    avgProbability: number
    avgConfidence: number
    totalVolume: number
  }> = []

  for (const [source, sourcePredictions] of bySource) {
    summary.push({
      source,
      count: sourcePredictions.length,
      avgProbability:
        sourcePredictions.reduce((sum, p) => sum + p.probability, 0) / sourcePredictions.length,
      avgConfidence:
        sourcePredictions.reduce((sum, p) => sum + (p.confidence || 0), 0) / sourcePredictions.length,
      totalVolume: sourcePredictions.reduce((sum, p) => sum + (p.volume || 0), 0),
    })
  }

  return summary.sort((a, b) => b.count - a.count)
}

// Clear prediction history (for testing)
export function clearPredictionHistory(): void {
  predictionHistory.clear()
}
