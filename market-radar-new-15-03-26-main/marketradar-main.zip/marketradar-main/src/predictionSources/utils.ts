// Utility functions for prediction sources
import type { PredictionMarket, CacheConfig } from './types'

// Simple in-memory cache with TTL
class SimpleCache<T> {
  private cache: Map<string, { data: T; expires: number }> = new Map()
  private config: CacheConfig

  constructor(config: CacheConfig = { ttl: 5 * 60 * 1000, maxSize: 100 }) {
    this.config = config
  }

  get(key: string): T | null {
    const entry = this.cache.get(key)
    if (!entry) return null
    if (Date.now() > entry.expires) {
      this.cache.delete(key)
      return null
    }
    return entry.data
  }

  set(key: string, data: T): void {
    // Evict oldest if at capacity
    if (this.cache.size >= this.config.maxSize) {
      const oldestKey = this.cache.keys().next().value
      if (oldestKey) this.cache.delete(oldestKey)
    }
    this.cache.set(key, {
      data,
      expires: Date.now() + this.config.ttl,
    })
  }

  clear(): void {
    this.cache.clear()
  }
}

// Global cache instance
export const predictionCache = new SimpleCache<PredictionMarket[]>({
  ttl: 5 * 60 * 1000, // 5 minutes
  maxSize: 50,
})

// Retry decorator for API calls
export async function withRetry<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  delay: number = 1000
): Promise<T> {
  let lastError: Error | undefined

  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn()
    } catch (error) {
      lastError = error as Error
      if (i < maxRetries - 1) {
        await new Promise(resolve => setTimeout(resolve, delay * (i + 1)))
      }
    }
  }
  throw lastError
}

// Logging utility
export function logLatency(source: string, startTime: number): void {
  const latency = Date.now() - startTime
  console.log(`[${source}] Fetched in ${latency}ms`)
}

// Convert betting odds to probability
export function oddsToProbability(odds: number): number {
  if (odds <= 0) return 0
  return 1 / odds
}

// Convert American odds to probability
export function americanOddsToProbability(americanOdds: number): number {
  if (americanOdds > 0) {
    return 100 / (americanOdds + 100)
  } else {
    return Math.abs(americanOdds) / (Math.abs(americanOdds) + 100)
  }
}

// Convert fractional odds to probability
export function fractionalOddsToProbability(numerator: number, denominator: number): number {
  if (denominator === 0) return 0
  return denominator / (numerator + denominator)
}

// Normalize probability to 0-1 range
export function normalizeProbability(prob: number): number {
  return Math.max(0, Math.min(1, prob))
}

// Extract topic from question/title using keyword matching
export function extractTopic(question: string): string {
  const questionLower = question.toLowerCase()

  // Common topic keywords
  const topicPatterns: Record<string, string[]> = {
    'Crypto': ['bitcoin', 'btc', 'ethereum', 'eth', 'crypto', 'solana', 'dogecoin'],
    'Stock Market': ['stock', 's&p', 'sp500', 'nasdaq', 'dow', 'apple', 'google', 'meta', 'tesla'],
    'Elections': ['election', 'president', 'vote', 'republican', 'democrat', 'congress'],
    'Economy': ['recession', 'inflation', 'gdp', 'fed', 'interest rate', 'unemployment'],
    'Commodities': ['oil', 'gold', 'silver', 'natural gas', 'wheat', 'corn'],
    'Technology': ['ai', 'artificial intelligence', 'tech', 'software', 'semiconductor'],
    'Geopolitics': ['war', 'russia', 'china', 'ukraine', 'israel', 'nato', 'conflict'],
    'Sports': ['super bowl', 'nfl', 'nba', 'football', 'soccer', 'olympics'],
    'Climate': ['weather', 'temperature', 'hurricane', 'climate', 'carbon'],
    'Health': ['covid', 'pandemic', 'virus', 'vaccine', 'health'],
  }

  for (const [topic, keywords] of Object.entries(topicPatterns)) {
    if (keywords.some(kw => questionLower.includes(kw))) {
      return topic
    }
  }

  // Default to first few words
  return question.split(' ').slice(0, 3).join(' ').replace(/[^a-zA-Z0-9]/g, '')
}

// Generate unique ID for prediction
export function generatePredictionId(source: string, marketId: string): string {
  return `${source}:${marketId}`.toLowerCase().replace(/[^a-z0-9]/g, '_')
}

// Debounce function
export function debounce<T extends (...args: unknown[]) => unknown>(
  fn: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timeoutId: ReturnType<typeof setTimeout>
  return (...args: Parameters<T>) => {
    clearTimeout(timeoutId)
    timeoutId = setTimeout(() => fn(...args), delay)
  }
}

// Calculate variance
export function calculateVariance(values: number[]): number {
  if (values.length === 0) return 0
  const mean = values.reduce((a, b) => a + b, 0) / values.length
  return values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length
}

// Calculate standard deviation
export function calculateStdDev(values: number[]): number {
  return Math.sqrt(calculateVariance(values))
}

// Clean HTML/text
export function cleanText(text: string): string {
  return text
    .replace(/<[^>]*>/g, '')
    .replace(/&[^;]+;/g, ' ')
    .trim()
}

// Sleep utility
export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}
