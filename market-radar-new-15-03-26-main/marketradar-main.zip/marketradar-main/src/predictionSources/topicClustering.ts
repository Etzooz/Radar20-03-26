// Topic Clustering Module
// Groups predictions into topics using NLP similarity and keyword matching

import type { PredictionMarket, TopicCluster } from "./types"
import { extractTopic } from "./utils"

// Tokenize text into words
function tokenize(text: string): Set<string> {
  return new Set(
    text
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, " ")
      .split(/\s+/)
      .filter((word) => word.length > 2)
  )
}

// Calculate Jaccard similarity between two sets
function jaccardSimilarity(setA: Set<string>, setB: Set<string>): number {
  const intersection = new Set([...setA].filter((x) => setB.has(x)))
  const union = new Set([...setA, ...setB])
  return intersection.size / (union.size || 1)
}

// Cosine similarity using term frequency
function cosineSimilarity(tokensA: string[], tokensB: string[]): number {
  const freqA = tokensA.reduce((acc, token) => {
    acc[token] = (acc[token] || 0) + 1
    return acc
  }, {} as Record<string, number>)

  const freqB = tokensB.reduce((acc, token) => {
    acc[token] = (acc[token] || 0) + 1
    return acc
  }, {} as Record<string, number>)

  const allTokens = new Set([...Object.keys(freqA), ...Object.keys(freqB)])

  let dotProduct = 0
  let normA = 0
  let normB = 0

  for (const token of allTokens) {
    const a = freqA[token] || 0
    const b = freqB[token] || 0
    dotProduct += a * b
    normA += a * a
    normB += b * b
  }

  const magnitude = Math.sqrt(normA) * Math.sqrt(normB)
  return magnitude > 0 ? dotProduct / magnitude : 0
}

// Fuzzy string matching using Levenshtein distance
function levenshteinDistance(str1: string, str2: string): number {
  const m = str1.length
  const n = str2.length

  if (m === 0) return n
  if (n === 0) return m

  const dp: number[][] = Array(m + 1)
    .fill(null)
    .map(() => Array(n + 1).fill(0))

  for (let i = 0; i <= m; i++) dp[i][0] = i
  for (let j = 0; j <= n; j++) dp[0][j] = j

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = str1[i - 1] === str2[j - 1] ? 0 : 1
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1, // deletion
        dp[i][j - 1] + 1, // insertion
        dp[i - 1][j - 1] + cost // substitution
      )
    }
  }

  return dp[m][n]
}

// Check if two strings are similar using fuzzy matching
function isSimilar(str1: string, str2: string, threshold: number = 0.7): boolean {
  const tokensA = Array.from(tokenize(str1))
  const tokensB = Array.from(tokenize(str2))

  // Check token overlap
  const jaccard = jaccardSimilarity(tokenize(str1), tokenize(str2))
  if (jaccard >= threshold) return true

  // Check cosine similarity
  const cosine = cosineSimilarity(tokensA, tokensB)
  if (cosine >= threshold) return true

  // Check fuzzy match on full strings
  const maxLen = Math.max(str1.length, str2.length)
  if (maxLen === 0) return true
  const distance = levenshteinDistance(str1.toLowerCase(), str2.toLowerCase())
  const similarity = 1 - distance / maxLen
  if (similarity >= threshold) return true

  return false
}

// Extract keywords from text
function extractKeywords(text: string): string[] {
  const tokens = tokenize(text)

  // Common stop words to filter out
  const stopWords = new Set([
    "will", "there", "have", "been", "would", "could", "should", "might",
    "must", "shall", "does", "doing", "done", "make", "made", "take", "took",
    "come", "came", "going", "want", "need", "know", "think", "believe",
    "what", "which", "when", "where", "why", "how", "than", "then", "after",
    "before", "above", "below", "between", "into", "through", "during", "under",
    "again", "further", "once", "here", "all", "both", "each", "few", "more",
    "most", "other", "some", "such", "only", "own", "same", "so", "than",
    "too", "very", "just", "also", "now", "the", "and", "but", "for", "with",
    "this", "that", "from", "they", "them", "their", "these", "those", "are",
    "was", "were", "has", "had", "not", "any", "can", "about", "into", "over",
  ])

  return Array.from(tokens).filter((t) => !stopWords.has(t))
}

// Cluster predictions by topic similarity
export function clusterByTopic(
  predictions: PredictionMarket[],
  similarityThreshold: number = 0.5
): TopicCluster[] {
  const clusters: TopicCluster[] = []
  const assigned = new Set<string>()

  for (const prediction of predictions) {
    if (assigned.has(prediction.id)) continue

    // Start a new cluster
    const cluster: TopicCluster = {
      topic: prediction.topic || extractTopic(prediction.question),
      keywords: extractKeywords(prediction.question),
      predictions: [prediction],
    }

    assigned.add(prediction.id)

    // Find similar predictions
    for (const other of predictions) {
      if (assigned.has(other.id)) continue

      const otherTopic = other.topic || extractTopic(other.question)

      if (
        isSimilar(cluster.topic, otherTopic, similarityThreshold) ||
        isSimilar(prediction.question, other.question, similarityThreshold)
      ) {
        cluster.predictions.push(other)
        assigned.add(other.id)

        // Merge keywords
        const otherKeywords = extractKeywords(other.question)
        cluster.keywords = [...new Set([...cluster.keywords, ...otherKeywords])]
      }
    }

    // Calculate centroid (average probability)
    if (cluster.predictions.length > 0) {
      cluster.centroid =
        cluster.predictions.reduce((sum, p) => sum + p.probability, 0) /
        cluster.predictions.length
    }

    clusters.push(cluster)
  }

  return clusters
}

// Get the most relevant topic for a prediction
export function matchTopic(prediction: PredictionMarket, knownTopics: string[]): string {
  const question = prediction.question
  const topic = prediction.topic || extractTopic(question)

  // Check if it matches any known topic
  for (const known of knownTopics) {
    if (isSimilar(topic, known, 0.6)) {
      return known
    }
  }

  // Check keywords
  const keywords = extractKeywords(question)
  for (const known of knownTopics) {
    const knownTokens = tokenize(known)
    const overlap = [...keywords].filter((k) => knownTokens.has(k)).length
    if (overlap >= 2) {
      return known
    }
  }

  return topic
}

// Predefined topic templates
export const TOPIC_TEMPLATES: Record<string, string[]> = {
  "Crypto": ["bitcoin", "btc", "ethereum", "eth", "crypto", "solana", "dogecoin", "altcoin"],
  "Stock Market": ["stock", "s&p", "sp500", "nasdaq", "dow", "market", "share"],
  "Elections": ["election", "president", "vote", "republican", "democrat", "congress", "senate"],
  "Economy": ["recession", "inflation", "gdp", "fed", "interest", "unemployment", "economic"],
  "Commodities": ["oil", "gold", "silver", "natural gas", "wheat", "corn", "commodity"],
  "Technology": ["ai", "artificial", "intelligence", "tech", "software", "semiconductor", "chip"],
  "Geopolitics": ["war", "russia", "china", "ukraine", "israel", "nato", "conflict", "military"],
  "Sports": ["super bowl", "nfl", "nba", "football", "soccer", "olympics", "championship"],
  "Climate": ["weather", "temperature", "hurricane", "climate", "carbon", "emissions", "warming"],
  "Health": ["covid", "pandemic", "virus", "vaccine", "health", "disease", "outbreak"],
  "Real Estate": ["housing", "real estate", "mortgage", "property", "home", "rent"],
  "Energy": ["energy", "solar", "wind", "nuclear", "power", "electricity"],
}

// Map prediction to predefined topic
export function mapToPredefinedTopic(prediction: PredictionMarket): string {
  const question = prediction.question.toLowerCase()

  for (const [topic, keywords] of Object.entries(TOPIC_TEMPLATES)) {
    if (keywords.some((kw) => question.includes(kw))) {
      return topic
    }
  }

  return prediction.topic || extractTopic(prediction.question)
}

// Get topic distribution
export function getTopicDistribution(
  predictions: PredictionMarket[]
): Array<{ topic: string; count: number; avgProbability: number }> {
  const distribution: Record<string, { count: number; totalProb: number }> = {}

  for (const prediction of predictions) {
    const topic = mapToPredefinedTopic(prediction)
    if (!distribution[topic]) {
      distribution[topic] = { count: 0, totalProb: 0 }
    }
    distribution[topic].count++
    distribution[topic].totalProb += prediction.probability
  }

  return Object.entries(distribution).map(([topic, data]) => ({
    topic,
    count: data.count,
    avgProbability: data.totalProb / data.count,
  }))
}
