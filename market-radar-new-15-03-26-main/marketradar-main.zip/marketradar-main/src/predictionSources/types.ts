// Unified Prediction Market Data Structure
// All sources normalize to this format

export type PredictionMarket = {
  id: string
  source: string
  topic: string
  question: string
  probability: number // 0 → 1
  volume?: number
  liquidity?: number
  confidence?: number
  url?: string
  timestamp: number
  // Additional metadata
  rawData?: unknown
  odds?: number // Original odds if from betting
  outcome?: string // Yes/No/Other
}

// Source weights for aggregation
export const SOURCE_WEIGHTS: Record<string, number> = {
  kalshi: 1.0,
  polymarket: 1.0,
  metaculus: 0.9,
  manifold: 0.8,
  betfair: 0.9,
  oddsapi: 0.9,
  predictit: 0.7,
  augur: 0.6,
  predictionbook: 0.5,
  gdelt: 0.4,
  googletrends: 0.3,
  feargreed: 0.5,
  sxbet: 0.7,
  novig: 0.7,
}

// Prediction source interface
export interface PredictionSource {
  name: string
  fetchPredictions(): Promise<PredictionMarket[]>
  fetchPredictionsByTopic?(topic: string): Promise<PredictionMarket[]>
}

// Aggregated prediction result
export type AggregatedPrediction = {
  topic: string
  aggregated_probability: number
  source_count: number
  variance: number
  confidence: number
  sources: string[]
  predictions: PredictionMarket[]
}

// Arbitrage detection result
export type ArbitrageOpportunity = {
  type: 'prediction_arbitrage'
  severity: 'high' | 'medium' | 'low'
  topic: string
  sources: string[]
  probabilities: number[]
  max_difference: number
  timestamp: number
}

// Timeframe analytics result
export type TimeframeAnalytics = {
  topic: string
  probability: number
  change_24h: number
  change_7d: number
  change_30d: number
  momentum_score: number
  history: ProbabilityHistoryPoint[]
}

export type ProbabilityHistoryPoint = {
  timestamp: number
  probability: number
  source?: string
}

// Heatmap-ready data structure
export type HeatmapData = {
  topic: string
  probability: number
  change_24h: number
  change_7d: number
  source_count: number
  disagreement_score: number
  confidence: number
}

// Cache configuration
export interface CacheConfig {
  ttl: number // Time to live in milliseconds
  maxSize: number // Maximum number of entries
}

// API response types
export type APIResponse<T> = {
  data?: T
  error?: string
  timestamp: number
}

// Topic clustering result
export type TopicCluster = {
  topic: string
  keywords: string[]
  predictions: PredictionMarket[]
  centroid?: number
}
