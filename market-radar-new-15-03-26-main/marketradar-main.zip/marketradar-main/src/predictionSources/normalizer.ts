// Data Normalizer Module
// Ensures all prediction sources conform to the unified data structure

import type { PredictionMarket } from "./types"
import { normalizeProbability, generatePredictionId } from "./utils"

// Normalize any prediction data to the standard format
export function normalizePrediction(data: PredictionMarket): PredictionMarket {
  return {
    id: data.id || generatePredictionId(data.source, data.question),
    source: data.source,
    topic: data.topic,
    question: data.question,
    probability: normalizeProbability(data.probability),
    volume: data.volume || 0,
    liquidity: data.liquidity || 0,
    confidence: data.confidence || 0.5,
    url: data.url,
    timestamp: data.timestamp || Date.now(),
    rawData: data.rawData,
    odds: data.odds,
    outcome: data.outcome,
  }
}

// Normalize an array of predictions
export function normalizePredictions(predictions: PredictionMarket[]): PredictionMarket[] {
  return predictions.map(normalizePrediction)
}

// Validate prediction data
export function validatePrediction(prediction: PredictionMarket): {
  valid: boolean
  errors: string[]
} {
  const errors: string[] = []

  if (!prediction.source) errors.push("Missing source")
  if (!prediction.question) errors.push("Missing question")
  if (prediction.probability === undefined || prediction.probability === null) {
    errors.push("Missing probability")
  } else if (prediction.probability < 0 || prediction.probability > 1) {
    errors.push("Probability must be between 0 and 1")
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}

// Deduplicate predictions
export function deduplicatePredictions(predictions: PredictionMarket[]): PredictionMarket[] {
  const seen = new Map<string, PredictionMarket>()

  for (const prediction of predictions) {
    const key = `${prediction.source}:${prediction.topic}:${prediction.question}`.toLowerCase()

    if (!seen.has(key)) {
      seen.set(key, prediction)
    } else {
      // Keep the one with higher confidence or volume
      const existing = seen.get(key)!
      if ((prediction.confidence || 0) > (existing.confidence || 0) ||
          (prediction.volume || 0) > (existing.volume || 0)) {
        seen.set(key, prediction)
      }
    }
  }

  return Array.from(seen.values())
}

// Filter predictions by criteria
export function filterPredictions(
  predictions: PredictionMarket[],
  filters: {
    sources?: string[]
    topics?: string[]
    minConfidence?: number
    minVolume?: number
    minProbability?: number
    maxProbability?: number
  }
): PredictionMarket[] {
  return predictions.filter((p) => {
    if (filters.sources?.length && !filters.sources.includes(p.source)) return false
    if (filters.topics?.length && !filters.topics.includes(p.topic)) return false
    if (filters.minConfidence && (p.confidence || 0) < filters.minConfidence) return false
    if (filters.minVolume && (p.volume || 0) < filters.minVolume) return false
    if (filters.minProbability && p.probability < filters.minProbability) return false
    if (filters.maxProbability && p.probability > filters.maxProbability) return false
    return true
  })
}

// Sort predictions
export function sortPredictions(
  predictions: PredictionMarket[],
  sortBy: "probability" | "volume" | "confidence" | "timestamp" = "confidence",
  order: "asc" | "desc" = "desc"
): PredictionMarket[] {
  const multiplier = order === "desc" ? -1 : 1

  return [...predictions].sort((a, b) => {
    let aVal: number, bVal: number

    switch (sortBy) {
      case "probability":
        aVal = a.probability
        bVal = b.probability
        break
      case "volume":
        aVal = a.volume || 0
        bVal = b.volume || 0
        break
      case "confidence":
        aVal = a.confidence || 0
        bVal = b.confidence || 0
        break
      case "timestamp":
        aVal = a.timestamp
        bVal = b.timestamp
        break
      default:
        return 0
    }

    return (aVal - bVal) * multiplier
  })
}

// Get predictions by source
export function getPredictionsBySource(
  predictions: PredictionMarket[],
  source: string
): PredictionMarket[] {
  return predictions.filter((p) => p.source === source)
}

// Get predictions by topic
export function getPredictionsByTopic(
  predictions: PredictionMarket[],
  topic: string
): PredictionMarket[] {
  return predictions.filter(
    (p) => p.topic.toLowerCase() === topic.toLowerCase()
  )
}

// Group predictions by source
export function groupBySource(
  predictions: PredictionMarket[]
): Record<string, PredictionMarket[]> {
  return predictions.reduce((acc, p) => {
    if (!acc[p.source]) acc[p.source] = []
    acc[p.source].push(p)
    return acc
  }, {} as Record<string, PredictionMarket[]>)
}

// Group predictions by topic
export function groupByTopic(
  predictions: PredictionMarket[]
): Record<string, PredictionMarket[]> {
  return predictions.reduce((acc, p) => {
    if (!acc[p.topic]) acc[p.topic] = []
    acc[p.topic].push(p)
    return acc
  }, {} as Record<string, PredictionMarket[]>)
}

// Calculate aggregate statistics
export function calculateStats(predictions: PredictionMarket[]): {
  total: number
  sources: string[]
  topics: string[]
  avgProbability: number
  avgConfidence: number
  totalVolume: number
} {
  return {
    total: predictions.length,
    sources: [...new Set(predictions.map((p) => p.source))],
    topics: [...new Set(predictions.map((p) => p.topic))],
    avgProbability:
      predictions.reduce((sum, p) => sum + p.probability, 0) / (predictions.length || 1),
    avgConfidence:
      predictions.reduce((sum, p) => sum + (p.confidence || 0), 0) / (predictions.length || 1),
    totalVolume: predictions.reduce((sum, p) => sum + (p.volume || 0), 0),
  }
}
