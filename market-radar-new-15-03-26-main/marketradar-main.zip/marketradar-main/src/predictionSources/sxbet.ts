// SX Bet Prediction Source
import type { PredictionSource, PredictionMarket } from "./types"
import { withRetry, logLatency, predictionCache, extractTopic, generatePredictionId, normalizeProbability } from "./utils"

const SX_BET_API = "https://api.sx.bet"
const CACHE_KEY = "sxbet_predictions"

interface SxBetMarket {
  id: string
  title: string
  description: string
  slug: string
  category: string
  status: string
  expiresAt: string
  volume: number
  liquidity: number
  outcomes: Array<{
    id: string
    title: string
    price: number
    volume: number
  }>
}

export class SxBetSource implements PredictionSource {
  name = "SX Bet"

  async fetchPredictions(): Promise<PredictionMarket[]> {
    const cached = predictionCache.get(CACHE_KEY)
    if (cached) return cached

    const startTime = Date.now()

    try {
      const response = await withRetry(async () => {
        const res = await fetch(`${SX_BET_API}/markets?status=active&limit=50`)
        if (!res.ok) throw new Error(`SX Bet API error: ${res.status}`)
        return res.json() as Promise<SxBetMarket[]>
      })

      const predictions: PredictionMarket[] = []

      for (const market of response || []) {
        // Get the Yes outcome
        const yesOutcome = market.outcomes.find(
          (o) => o.title.toLowerCase().includes("yes") || o.title === "Yes"
        )

        predictions.push({
          id: generatePredictionId("sxbet", market.id),
          source: "sxbet",
          topic: extractTopic(market.title),
          question: market.title,
          probability: normalizeProbability(yesOutcome?.price || 0.5),
          volume: market.volume,
          liquidity: market.liquidity,
          confidence: market.liquidity > 50000 ? 0.9 : market.liquidity > 10000 ? 0.7 : 0.5,
          url: `https://sx.bet/markets/${market.slug}`,
          timestamp: Date.now(),
          rawData: market,
          outcome: "Yes",
        })
      }

      predictionCache.set(CACHE_KEY, predictions)
      logLatency(this.name, startTime)
      return predictions
    } catch (error) {
      console.error("SX Bet fetch error:", error)
      return this.getDemoData()
    }
  }

  private getDemoData(): PredictionMarket[] {
    const demoQuestions = [
      "Will BTC reach $200k by 2027?",
      "Will ETH flip BTC by 2028?",
    ]

    return demoQuestions.map((question, i) => ({
      id: generatePredictionId("sxbet", `demo_${i}`),
      source: "sxbet",
      topic: extractTopic(question),
      question,
      probability: normalizeProbability(0.3 + Math.random() * 0.5),
      volume: Math.floor(Math.random() * 100000),
      confidence: 0.6,
      url: "https://sx.bet",
      timestamp: Date.now(),
    }))
  }
}

export const sxbet = new SxBetSource()
