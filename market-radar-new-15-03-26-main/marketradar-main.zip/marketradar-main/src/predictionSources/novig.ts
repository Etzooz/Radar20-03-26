// Novig Prediction Source
import type { PredictionSource, PredictionMarket } from "./types"
import { withRetry, logLatency, predictionCache, extractTopic, generatePredictionId, normalizeProbability } from "./utils"

const NOVIG_API = "https://api.novig.com"
const CACHE_KEY = "novig_predictions"

interface NovigMarket {
  id: string
  question: string
  description: string
  category: string
  subcategory: string
  status: "open" | "closed" | "resolved"
  expiresAt: string
  volume: number
  outcomes: Array<{
    id: string
    name: string
    price: number
    volume: number
  }>
}

export class NovigSource implements PredictionSource {
  name = "Novig"

  async fetchPredictions(): Promise<PredictionMarket[]> {
    const cached = predictionCache.get(CACHE_KEY)
    if (cached) return cached

    const startTime = Date.now()

    try {
      const response = await withRetry(async () => {
        const res = await fetch(`${NOVIG_API}/markets?status=open&limit=50`)
        if (!res.ok) throw new Error(`Novig API error: ${res.status}`)
        return res.json() as Promise<NovigMarket[]>
      })

      const predictions: PredictionMarket[] = []

      for (const market of response || []) {
        const yesOutcome = market.outcomes.find(
          (o) => o.name.toLowerCase().includes("yes") || o.name === "Yes"
        )

        predictions.push({
          id: generatePredictionId("novig", market.id),
          source: "novig",
          topic: extractTopic(market.question),
          question: market.question,
          probability: normalizeProbability(yesOutcome?.price || 0.5),
          volume: market.volume,
          confidence: market.volume > 50000 ? 0.9 : market.volume > 10000 ? 0.7 : 0.5,
          url: `https://novig.com/markets/${market.id}`,
          timestamp: Date.now(),
          rawData: market,
          outcome: "Yes",
        })
      }

      predictionCache.set(CACHE_KEY, predictions)
      logLatency(this.name, startTime)
      return predictions
    } catch (error) {
      console.error("Novig fetch error:", error)
      return this.getDemoData()
    }
  }

  private getDemoData(): PredictionMarket[] {
    const demoQuestions = [
      "Will the S&P 500 double by 2030?",
      "Will gold hit $5000/oz?",
    ]

    return demoQuestions.map((question, i) => ({
      id: generatePredictionId("novig", `demo_${i}`),
      source: "novig",
      topic: extractTopic(question),
      question,
      probability: normalizeProbability(0.3 + Math.random() * 0.5),
      volume: Math.floor(Math.random() * 50000),
      confidence: 0.6,
      url: "https://novig.com",
      timestamp: Date.now(),
    }))
  }
}

export const novig = new NovigSource()
