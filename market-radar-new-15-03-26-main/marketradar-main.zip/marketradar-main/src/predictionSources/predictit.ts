// PredictIt Prediction Source
import type { PredictionSource, PredictionMarket } from "./types"
import { withRetry, logLatency, predictionCache, extractTopic, generatePredictionId, normalizeProbability } from "./utils"

const PREDICTIT_API = "https://www.predictit.org/api/marketdata"
const CACHE_KEY = "predictit_predictions"

interface PredictItContract {
  id: number
  name: string
  shortName: string
  color: string
  dateEnd: string
  price: number
  buyNo: number
  buyYes: number
  sellNo: number
  sellYes: number
  lastTradePrice: number
  lastClosePrice: number
  lastUpdated: string
}

interface PredictItMarket {
  id: number
  name: string
  shortName: string
  url: string
  image: string
  ticker: string
  status: string
  marketType: string
  dateEnd: string
  contracts: PredictItContract[]
}

interface PredictItResponse {
  markets: PredictItMarket[]
}

export class PredictItSource implements PredictionSource {
  name = "PredictIt"

  async fetchPredictions(): Promise<PredictionMarket[]> {
    const cached = predictionCache.get(CACHE_KEY)
    if (cached) return cached

    const startTime = Date.now()

    try {
      const response = await withRetry(async () => {
        const res = await fetch(`${PREDICTIT_API}/all/`)
        if (!res.ok) throw new Error(`PredictIt API error: ${res.status}`)
        return res.json() as Promise<PredictItResponse>
      })

      const predictions: PredictionMarket[] = []

      for (const market of response.markets || []) {
        for (const contract of market.contracts || []) {
          predictions.push({
            id: generatePredictionId("predictit", contract.id.toString()),
            source: "predictit",
            topic: extractTopic(market.name),
            question: `${market.name}: ${contract.name}`,
            probability: normalizeProbability(contract.price || contract.lastTradePrice || 0.5),
            confidence: 0.7,
            url: `${market.url}`,
            timestamp: Date.now(),
            rawData: { market, contract },
            outcome: contract.name.toLowerCase().includes("yes") ? "Yes" : "No",
          })
        }
      }

      predictionCache.set(CACHE_KEY, predictions)
      logLatency(this.name, startTime)
      return predictions
    } catch (error) {
      console.error("PredictIt fetch error:", error)
      return this.getDemoData()
    }
  }

  private getDemoData(): PredictionMarket[] {
    const demoQuestions = [
      "Who will win 2024 Republican primary?",
      "Will Democrats gain Senate seats in 2024?",
      "Who will be next Fed Chair?",
    ]

    return demoQuestions.map((question, i) => ({
      id: generatePredictionId("predictit", `demo_${i}`),
      source: "predictit",
      topic: extractTopic(question),
      question,
      probability: normalizeProbability(0.3 + Math.random() * 0.5),
      confidence: 0.6,
      url: "https://www.predictit.org",
      timestamp: Date.now(),
    }))
  }
}

export const predictit = new PredictItSource()
