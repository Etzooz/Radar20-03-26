// PredictionBook Prediction Source
import type { PredictionSource, PredictionMarket } from "./types"
import { withRetry, logLatency, predictionCache, extractTopic, generatePredictionId, normalizeProbability } from "./utils"

const PREDICTIONBOOK_API = "https://predictionbook.com/api"
const CACHE_KEY = "predictionbook_predictions"

interface PredictionBookPrediction {
  id: number
  description: string
  outcomes: Array<{
    id: number
    name: string
    probability: number
    votes: number
  }>
  created_at: string
  known_outcome?: {
    name: string
    correct: boolean
  }
}

export class PredictionBookSource implements PredictionSource {
  name = "PredictionBook"

  async fetchPredictions(): Promise<PredictionMarket[]> {
    const cached = predictionCache.get(CACHE_KEY)
    if (cached) return cached

    const startTime = Date.now()

    try {
      const response = await withRetry(async () => {
        const res = await fetch(`${PREDICTIONBOOK_API}/predictions`)
        if (!res.ok) throw new Error(`PredictionBook API error: ${res.status}`)
        return res.json() as Promise<PredictionBookPrediction[]>
      })

      const predictions: PredictionMarket[] = []

      for (const pred of response || []) {
        if (pred.known_outcome) continue // Skip resolved predictions

        // Get the "Yes" or first outcome probability
        const yesOutcome = pred.outcomes.find(o => o.name.toLowerCase().includes("yes")) || pred.outcomes[0]

        predictions.push({
          id: generatePredictionId("predictionbook", pred.id.toString()),
          source: "predictionbook",
          topic: extractTopic(pred.description),
          question: pred.description,
          probability: normalizeProbability((yesOutcome?.probability || 50) / 100),
          volume: yesOutcome?.votes || 0,
          confidence: 0.5,
          url: `https://predictionbook.com/predictions/${pred.id}`,
          timestamp: Date.now(),
          rawData: pred,
          outcome: yesOutcome?.name,
        })
      }

      predictionCache.set(CACHE_KEY, predictions)
      logLatency(this.name, startTime)
      return predictions
    } catch (error) {
      console.error("PredictionBook fetch error:", error)
      return this.getDemoData()
    }
  }

  private getDemoData(): PredictionMarket[] {
    const demoQuestions = [
      "Will it rain tomorrow?",
      "Will the team win the championship?",
      "Will the project be completed on time?",
    ]

    return demoQuestions.map((question, i) => ({
      id: generatePredictionId("predictionbook", `demo_${i}`),
      source: "predictionbook",
      topic: extractTopic(question),
      question,
      probability: normalizeProbability(0.3 + Math.random() * 0.5),
      volume: Math.floor(Math.random() * 100),
      confidence: 0.4,
      url: "https://predictionbook.com",
      timestamp: Date.now(),
    }))
  }
}

export const predictionbook = new PredictionBookSource()
