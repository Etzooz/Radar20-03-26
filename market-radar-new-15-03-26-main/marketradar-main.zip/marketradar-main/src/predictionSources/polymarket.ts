// Polymarket Prediction Source
import type { PredictionSource, PredictionMarket } from './types'
import { withRetry, logLatency, predictionCache, extractTopic, generatePredictionId, normalizeProbability } from './utils'

const POLYMARKET_API = 'https://gamma-api.polymarket.com'
const CACHE_KEY = 'polymarket_predictions'

interface PolymarketEvent {
  id: string
  title: string
  description: string
  startDate: string
  endDate: string
  volumes: Record<string, number>
  clobTokenIds: string[]
}

interface PolymarketMarket {
  conditionId: string
  question: string
  description: string
  volume: number
  liquidity: number
  clobTokenId: string
  groupItemTitle: string
}

export class PolymarketSource implements PredictionSource {
  name = 'Polymarket'

  async fetchPredictions(): Promise<PredictionMarket[]> {
    const cached = predictionCache.get(CACHE_KEY)
    if (cached) return cached

    const startTime = Date.now()

    try {
      // Fetch events (top level markets)
      const events = await withRetry(async () => {
        const response = await fetch(`${POLYMARKET_API}/events?limit=100&closed=false`)
        if (!response.ok) throw new Error(`Polymarket API error: ${response.status}`)
        return response.json() as Promise<PolymarketEvent[]>
      })

      const predictions: PredictionMarket[] = []

      // Fetch markets for each event
      for (const event of events.slice(0, 20)) { // Limit to 20 events
        try {
          const markets = await withRetry(async () => {
            const response = await fetch(
              `${POLYMARKET_API}/markets?conditionId=${event.id}&limit=10`
            )
            if (!response.ok) throw new Error(`Polymarket markets error: ${response.status}`)
            return response.json() as Promise<PolymarketMarket[]>
          })

          for (const market of markets) {
            // Get the Yes price (typically first outcome)
            const yesPrice = market.volume > 0 ? 0.5 : undefined // Default, need to fetch order book for real price
            const probability = yesPrice || Math.random() * 0.4 + 0.3 // Fallback for demo

            predictions.push({
              id: generatePredictionId('polymarket', market.conditionId || market.clobTokenId),
              source: 'polymarket',
              topic: extractTopic(market.question),
              question: market.question,
              probability: normalizeProbability(probability),
              volume: market.volume,
              liquidity: market.liquidity,
              confidence: market.liquidity > 10000 ? 0.9 : market.liquidity > 1000 ? 0.7 : 0.5,
              url: `https://polymarket.com/market/${market.conditionId}`,
              timestamp: Date.now(),
              rawData: market,
              outcome: 'Yes',
            })
          }
        } catch (err) {
          console.warn(`Failed to fetch markets for event ${event.id}:`, err)
        }
      }

      predictionCache.set(CACHE_KEY, predictions)
      logLatency(this.name, startTime)
      return predictions
    } catch (error) {
      console.error('Polymarket fetch error:', error)
      // Return demo data on error
      return this.getDemoData()
    }
  }

  private getDemoData(): PredictionMarket[] {
    const demoQuestions = [
      'Will Bitcoin exceed $100,000 by end of 2026?',
      'Will ETH flip BTC market cap by 2027?',
      'Will there be a recession in US in 2026?',
      'Will AI pass Turing test by 2027?',
      'Will Russia-Ukraine war end in 2026?',
      'Will Fed cut rates to 0% in 2026?',
      'Will Bitcoin be legal tender in more countries?',
      'Will SpaceX go public by 2026?',
    ]

    return demoQuestions.map((question, i) => ({
      id: generatePredictionId('polymarket', `demo_${i}`),
      source: 'polymarket',
      topic: extractTopic(question),
      question,
      probability: normalizeProbability(0.3 + Math.random() * 0.5),
      volume: Math.floor(Math.random() * 1000000),
      liquidity: Math.floor(Math.random() * 500000),
      confidence: 0.7,
      url: `https://polymarket.com/market/demo_${i}`,
      timestamp: Date.now(),
    }))
  }
}

export const polymarket = new PolymarketSource()
