 Main API Exports for Prediction Market Intelligence Engine
// This is the main entry point for using the prediction system

// Types
export * from "./types"

// Utilities
export * from "./utils"

// Normalizer
export * from "./normalizer"

// Topic Clustering
export * from "./topicClustering"

// Aggregator
export * from "./aggregator"

// Arbitrage Detector
export * from "./arbitrage"

// Timeframe Analytics
export * from "./timeframeAnalytics"

// Prediction Sources
export { polymarket, PolymarketSource } from "./polymarket"
export { kalshi, KalshiSource } from "./kalshi"
export { manifold, ManifoldSource } from "./manifold"
export { metaculus, MetaculusSource } from "./metaculus"
export { predictit, PredictItSource } from "./predictit"
export { predictionbook, PredictionBookSource } from "./predictionbook"
export { augur, AugurSource } from "./augur"
export { sxbet, SxBetSource } from "./sxbet"
export { novig, NovigSource } from "./novig"
export { betfair, BetfairSource, convertOdds } from "./betfair"
export { gdelt, googleTrends, fearGreed, GdeltSource, GoogleTrendsSource, FearGreedSource } from "./gdeltdoc"

// Main API Functions

import type { PredictionMarket, AggregatedPrediction, ArbitrageOpportunity, TimeframeAnalytics, HeatmapData } from "./types"
import { polymarket } from "./polymarket"
import { kalshi } from "./kalshi"
import { manifold } from "./manifold"
import { metaculus } from "./metaculus"
import { predictit } from "./predictit"
import { predictionbook } from "./predictionbook"
import { augur } from "./augur"
import { sxbet } from "./sxbet"
import { novig } from "./novig"
import { betfair } from "./betfair"
import { gdelt, googleTrends, fearGreed } from "./gdeltdoc"

import { normalizePredictions, deduplicatePredictions, filterPredictions, sortPredictions } from "./normalizer"
import { clusterByTopic, getTopicDistribution, mapToPredefinedTopic, TOPIC_TEMPLATES } from "./topicClustering"
import { aggregateAllPredictions, getAggregatedProbabilityForTopic, getTopPredictions, getSourcesSummary } from "./aggregator"
import { detectAllArbitrage, getHighSeverityArbitrage, getMostDisagreedTopics } from "./arbitrage"
import { getAllTimeframeAnalytics, getTrendingTopics, formatChange, getMomentumLabel } from "./timeframeAnalytics"
import { calculateDisagreementScore } from "./arbitrage"

// All available prediction sources
const ALL_SOURCES = [
  polymarket,
  kalshi,
  manifold,
  metaculus,
  predictit,
  predictionbook,
  augur,
  sxbet,
  novig,
  betfair,
  gdelt,
  googleTrends,
  fearGreed,
]

// Fetch predictions from all sources
export async function fetchAllPredictionSources(): Promise<PredictionMarket[]> {
  const results = await Promise.allSettled(
    ALL_SOURCES.map(async (source) => {
      try {
        return await source.fetchPredictions()
      } catch (error) {
        console.warn(`Failed to fetch from ${source.name}:`, error)
        return []
      }
    })
  )

  // Flatten and normalize
  const allPredictions: PredictionMarket[] = []

  for (const result of results) {
    if (result.status === "fulfilled") {
      allPredictions.push(...result.value)
    }
  }

  // Normalize and deduplicate
  return deduplicatePredictions(normalizePredictions(allPredictions))
}

// Get aggregated predictions
export function getAggregatedPredictions(predictions: PredictionMarket[]): AggregatedPrediction[] {
  return aggregateAllPredictions(predictions)
}

// Get prediction arbitrage opportunities
export function getPredictionArbitrage(predictions: PredictionMarket[]): ArbitrageOpportunity[] {
  return detectAllArbitrage(predictions)
}

// Get high severity arbitrage only
export function getHighSeverityArbitrageOpportunities(predictions: PredictionMarket[]): ArbitrageOpportunity[] {
  return getHighSeverityArbitrage(predictions)
}

// Get prediction momentum
export function getPredictionMomentum(predictions: PredictionMarket[]): TimeframeAnalytics[] {
  return getAllTimeframeAnalytics(predictions)
}

// Get trending topics
export function getTrending(predictions: PredictionMarket[], limit: number = 10): TimeframeAnalytics[] {
  return getTrendingTopics(predictions, limit)
}

// Get heatmap-ready data
export function getHeatmapData(predictions: PredictionMarket[]): HeatmapData[] {
  const aggregated = aggregateAllPredictions(predictions)
  const analytics = getAllTimeframeAnalytics(predictions)
  const arbitrage = detectAllArbitrage(predictions)

  // Create a map of topic -> arbitrage for quick lookup
  const arbitrageMap = new Map<string, number>()
  for (const a of arbitrage) {
    const current = arbitrageMap.get(a.topic) || 0
    arbitrageMap.set(a.topic, Math.max(current, a.max_difference))
  }

  return aggregated.map((agg) => {
    const topicAnalytics = analytics.find((a) => a.topic === agg.topic)
    const disagreement = arbitrageMap.get(agg.topic) || 0

    return {
      topic: agg.topic,
      probability: agg.aggregated_probability,
      change_24h: topicAnalytics?.change_24h || 0,
      change_7d: topicAnalytics?.change_7d || 0,
      source_count: agg.source_count,
      disagreement_score: disagreement,
      confidence: agg.confidence,
    }
  })
}

// Get predictions by source
export function getPredictionsBySource(predictions: PredictionMarket[], source: string): PredictionMarket[] {
  return filterPredictions(predictions, { sources: [source] })
}

// Get filtered predictions
export function getFilteredPredictions(
  predictions: PredictionMarket[],
  options: {
    sources?: string[]
    topics?: string[]
    minConfidence?: number
    minVolume?: number
  }
): PredictionMarket[] {
  return filterPredictions(predictions, options)
}

// Get sorted predictions
export function getSortedPredictions(
  predictions: PredictionMarket[],
  sortBy: "probability" | "volume" | "confidence" = "confidence",
  order: "asc" | "desc" = "desc"
): PredictionMarket[] {
  return sortPredictions(predictions, sortBy, order)
}

// Get topic clusters
export function getTopicClusters(predictions: PredictionMarket[]) {
  return clusterByTopic(predictions)
}

// Get topic distribution
export function getDistribution(predictions: PredictionMarket[]) {
  return getTopicDistribution(predictions)
}

// Get sources summary
export function getSources(predictions: PredictionMarket[]) {
  return getSourcesSummary(predictions)
}

// Get most disagreed topics
export function getDisagreements(predictions: PredictionMarket[], limit: number = 10) {
  return getMostDisagreedTopics(predictions, limit)
}

// Utility to format probability as percentage
export function formatProbability(prob: number): string {
  return `${(prob * 100).toFixed(1)}%`
}

// Available topic templates
export { TOPIC_TEMPLATES }

// Re-export for convenience
export { mapToPredefinedTopic as getTopic }

// Default export with all functionality
export default {
  fetchAllPredictionSources,
  getAggregatedPredictions,
  getPredictionArbitrage,
  getHighSeverityArbitrageOpportunities,
  getPredictionMomentum,
  getTrending,
  getHeatmapData,
  getPredictionsBySource,
  getFilteredPredictions,
  getSortedPredictions,
  getTopicClusters,
  getDistribution,
  getSources,
  getDisagreements,
  formatProbability,
  // Source exports
  sources: ALL_SOURCES,
}
