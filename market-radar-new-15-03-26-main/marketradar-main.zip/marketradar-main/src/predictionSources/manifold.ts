// Manifold Markets Prediction Source
import type { PredictionSource, PredictionMarket } from "./types"
import { withRetry, logLatency, predictionCache, extractTopic, generatePredictionId, normalizeProbability } from "./utils"

const MANIFOLD_API = "https://api.manifold.markets/v0"
const CACHE_KEY = "manifold_predictions"

interface ManifoldMarket {
  id: string
  slug: string
  question: string
  description: string
  url: string
  mechanism: string
  contractType: string
  createdTime: number
  closeTime: number
  resolvedTime?: number
  volume: number
  volume24hr: number
  liquidity: number
  outcomeType: string
  probability?: number
  resolutions?: Record<string, number>
}

export class ManifoldSource implements PredictionSource {
  name = "Manifold"

  async fetchPredictions(): Promise<PredictionMarket[]> {
    const cached = predictionCache.get(CACHE_KEY)
    if (cached) return cached

    const startTime = Date.now()

    try {
      const response = await withRetry(async () => {
        const res = await fetch(`${MANIFOLD_API}/markets?limit=100&sort=volume`)
        if (!res.ok) throw new Error(`Manifold API error: ${res.status}`)
        return res.json() as Promise<ManifoldMarket[]>
      })

      const predictions: PredictionMarket[] = []

      for (const market of response || []) {
        if (market.closeTime && market.closeTime < Date.now()) continue // Skip closed markets

        predictions.push({
          id: generatePredictionId("manifold", market.id),
          source: "manifold",
          topic: extractTopic(market.question),
          question: market.question,
          probability: normalizeProbability(market.probability || 0.5),
          volume: market.volume,
          liquidity: market.liquidity,
          confidence: market.liquidity > 50000 ? 0.9 : market.liquidity > 10000 ? 0.7 : 0.5,
          url: market.url,
          timestamp: Date.now(),
          rawData: market,
          outcome: "Yes",
        })
      }

      predictionCache.set(CACHE_KEY, predictions)
      logLatency(this.name, startTime)
      return predictions
    } catch (error) {
      console.error("Manifold fetch error:", error)
      return this.getDemoData()
    }
  }

  private getDemoData(): PredictionMarket[] {
    const demoQuestions = [
      "Will Trump win 2024 election?",
      "Will SpaceX land on Mars by 2030?",
      "Will AI pass Bar exam by 2025?",
      "Will Bitcoin reach $1M by 2030?",
      "Will we discover alien life by 2040?",
    ]

    return demoQuestions.map((question, i) => ({
      id: generatePredictionId("manifold", `demo_${i}`),
      source: "manifold",
      topic: extractTopic(question),
      question,
      probability: normalizeProbability(0.3 + Math.random() * 0.5),
      volume: Math.floor(Math.random() * 100000),
      liquidity: Math.floor(Math.random() * 50000),
      confidence: 0.7,
      url: `https://manifold.markets/demo_${i}`,
      timestamp: Date.now(),
    }))
  }
}

export const manifold = new ManifoldSource()
