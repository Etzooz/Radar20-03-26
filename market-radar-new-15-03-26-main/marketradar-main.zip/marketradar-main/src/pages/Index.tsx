import { useState, useCallback, useMemo, useRef, useEffect } from "react";
import { ForecastCard } from "@/components/ForecastCard";
import { PredictionMarketCards } from "@/components/PredictionMarketCards";
import { usePredictionMarkets } from "@/hooks/usePredictionMarkets";
import { useRefreshCountdown } from "@/hooks/useRefreshCountdown";
import { format, formatDistanceToNowStrict } from "date-fns";
import { Loader2, RefreshCw, ChevronDown, ChevronUp, Activity, ExternalLink, Info, AlertTriangle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useQueryClient } from "@tanstack/react-query";
import { DashboardSkeleton, ForecastCardSkeleton } from "@/components/LoadingSkeleton";

const REFRESH_INTERVAL = 1 * 60 * 1000;

function getScoreLabel(score: number) {
  if (score >= 70) return { label: "STRONG BULLISH", color: "text-bullish" };
  if (score >= 55) return { label: "BULLISH", color: "text-bullish" };
  if (score >= 45) return { label: "NEUTRAL", color: "text-neutral" };
  if (score >= 30) return { label: "WEAK", color: "text-bearish" };
  return { label: "BEARISH", color: "text-bearish" };
}

function getMomentumLabel(score: number) {
  if (score >= 60) return { label: "Strong", color: "text-bullish" };
  if (score >= 45) return { label: "Neutral", color: "text-neutral" };
  return { label: "Weak", color: "text-bearish" };
}

function getPositioningLabel(whaleScore: number, stablecoinScore: number) {
  const avg = (whaleScore + stablecoinScore) / 2;
  if (avg >= 60) return { label: "Bullish", color: "text-bullish" };
  if (avg >= 45) return { label: "Neutral", color: "text-neutral" };
  return { label: "Bearish", color: "text-bearish" };
}

function getSentimentLabel(consensus: number) {
  if (consensus >= 0.3) return { label: "Bullish", color: "text-bullish" };
  if (consensus >= -0.3) return { label: "Neutral", color: "text-neutral" };
  return { label: "Bearish", color: "text-bearish" };
}

function DriverRow({ driver: d }: { driver: any }) {
  const [open, setOpen] = useState(false);
  const isPositive = d.impact > 0;
  const isNegative = d.impact < 0;
  const deltaUp = d.delta > 0;

  return (
    <div className="border-t border-border/40">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2.5 py-2 w-full text-left hover:bg-secondary/30 transition-colors rounded-sm px-1.5 -mx-1.5"
      >
        <div className="flex items-center gap-1.5 shrink-0 w-16 justify-end">
          <div className={`w-0 h-0 ${
            isPositive
              ? "border-l-[5px] border-r-[5px] border-b-[8px] border-l-transparent border-r-transparent border-b-bullish"
              : isNegative
              ? "border-l-[5px] border-r-[5px] border-t-[8px] border-l-transparent border-r-transparent border-t-bearish"
              : "w-2 h-2 rounded-full bg-muted-foreground"
          }`} />
          <span className={`text-sm font-black font-mono tabular-nums ${
            isPositive ? "text-bullish" : isNegative ? "text-bearish" : "text-muted-foreground"
          }`}>
            {isPositive ? "+" : ""}{d.impact}
          </span>
        </div>
        {d.delta !== 0 && (
          <span className={`text-[9px] font-bold font-mono tabular-nums px-1.5 py-0.5 rounded-md shrink-0 ${
            deltaUp ? "text-bullish bg-bullish/10" : "text-bearish bg-bearish/10"
          }`}>
            {deltaUp ? "▲" : "▼"}{Math.abs(d.delta)}
          </span>
        )}
        <span className="text-[11px] text-foreground font-semibold flex-1">{d.label}</span>
        {d.source && (
          <span className="text-[8px] text-muted-foreground font-mono shrink-0">· {d.source}</span>
        )}
        <ChevronDown className={`w-3 h-3 text-muted-foreground/50 shrink-0 transition-transform duration-200 ${open ? "rotate-180" : ""}`} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="overflow-hidden">
            <div className="ml-[4.5rem] pr-2 pb-3 space-y-1">
              {d.description && <p className="text-[10px] text-muted-foreground leading-relaxed"><span className="font-semibold text-foreground/70">What:</span> {d.description}</p>}
              {d.whyItMatters && <p className="text-[10px] text-muted-foreground leading-relaxed"><span className="font-semibold text-foreground/70">Why:</span> {d.whyItMatters}</p>}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

const Index = () => {
  const today = format(new Date(), "EEEE, MMM d, yyyy");
  const queryClient = useQueryClient();
  const { data, isLoading, isError, dataUpdatedAt } = usePredictionMarkets();
  const handleExpire = useCallback(() => {
    queryClient.invalidateQueries({ queryKey: ["prediction-markets"] });
  }, [queryClient]);
  const { display: countdown } = useRefreshCountdown(REFRESH_INTERVAL, dataUpdatedAt, handleExpire);
  const [analyticsOpen, setAnalyticsOpen] = useState(false);

  const prevScoreRef = useRef<number | null>(null);
  const [scoreDelta, setScoreDelta] = useState<number | null>(null);

  const prediction: any = data?.prediction ?? {
    confidence: 0, btcConfidence: 0, sp500Confidence: 0, goldConfidence: 0, oilConfidence: 0, signalsUsed: 0,
  };

  const prices: any = {
    btc: data?.prices?.btc ?? { current: 0, predicted: 0, move: 0 },
    sp500: data?.prices?.sp500 ?? { current: 0, predicted: 0, move: 0 },
    gold: data?.prices?.gold ?? { current: 0, predicted: 0, move: 0 },
    oil: (data?.prices as any)?.oil ?? { current: 0, predicted: 0, move: 0 },
  };

  const pulse = data?.globalMarketPulse ?? { score: 50, environment: "Neutral", drivers: [], regime: "RANGE" };

  useEffect(() => {
    if (pulse.score !== undefined && prevScoreRef.current !== null) {
      const delta = pulse.score - prevScoreRef.current;
      if (delta !== 0) setScoreDelta(delta);
    }
    prevScoreRef.current = pulse.score;
  }, [pulse.score]);

  const totalSignals = (data?.sources?.polymarket ?? 0) + (data?.sources?.kalshi ?? 0) + (data?.sources?.manifold ?? 0) + (data?.sources?.metaculus ?? 0);
  const liveSources = [data?.sources?.polymarket, data?.sources?.kalshi, data?.sources?.manifold, data?.sources?.metaculus].filter(s => (s ?? 0) > 0).length;

  const scoreInfo = getScoreLabel(pulse.score);
  const confidenceValue = prediction.confidence || 50;

  const drivers = useMemo(() => {
    if (data?.topDrivers && data.topDrivers.length > 0) return data.topDrivers;
    if (!data?.predictionInputs) return [];
    const inputs = data.predictionInputs;
    const items = [
      { label: "Stablecoin Liquidity", impact: Math.round(inputs.stablecoin.score - 50), delta: 0 },
      { label: "Volume Strength", impact: Math.round(inputs.volume.score - 50), delta: 0 },
      { label: "Whale Activity", impact: Math.round(inputs.whale.score - 50), delta: 0 },
      { label: "Momentum", impact: Math.round(inputs.momentum.score - 50), delta: 0 },
      { label: "Market Consensus", impact: Math.round(inputs.predictionMarkets.score - 50), delta: 0 },
      { label: "News Sentiment", impact: Math.round(inputs.news.score - 50), delta: 0 },
    ];
    return items.sort((a, b) => Math.abs(b.impact) - Math.abs(a.impact));
  }, [data?.topDrivers, data?.predictionInputs]);

  const timeline = useMemo(() => {
    const events: { time: string; text: string; key: string; source?: string }[] = [];
    if (data?.liquidityShocks) {
      data.liquidityShocks.forEach((s: any) => {
        const t = format(new Date(s.timestamp), "HH:mm");
        events.push({ time: t, text: s.description, key: `${t}-${s.description}`, source: s.source });
      });
    }
    if (data?.predictionDrivers) {
      const now = new Date();
      [...(data.predictionDrivers.btc ?? []), ...(data.predictionDrivers.sp500 ?? []), ...(data.predictionDrivers.gold ?? [])].slice(0, 4).forEach((d: any, i: number) => {
        const text = typeof d === "string" ? d : d.text;
        const source = typeof d === "string" ? undefined : d.source;
        const t = format(new Date(now.getTime() - (i + 1) * 2 * 60 * 1000), "HH:mm");
        events.push({ time: t, text, key: `${t}-${text}`, source });
      });
    }
    return events.slice(0, 6);
  }, [data?.liquidityShocks, data?.predictionDrivers]);

  const sentimentInfo = getSentimentLabel(data?.predictionConsensus?.consensus ?? 0);
  const momentumInfo = getMomentumLabel(data?.predictionInputs?.momentum?.score ?? 50);
  const positioningInfo = getPositioningLabel(
    data?.predictionInputs?.whale?.score ?? 50,
    data?.predictionInputs?.stablecoin?.score ?? 50
  );

  const sentimentClusters = data?.socialSentiment ? Object.values(data.socialSentiment).filter((s: any) => s.signalStrength === "strong").length : 0;
  const anomalyAlerts = (data as any)?.anomalies?.length ?? data?.liquidityShocks?.length ?? 0;
  const dataStreams = 18;

  const clusterScores = data?.clusterScores;
  const scenarioProbabilities = data?.scenarioProbabilities;
  const timeframeScores = data?.timeframeScores;
  const anomalies = data?.anomalies ?? [];
  const liquidityIndex = data?.liquidityIndex;
  const expectedMoves = data?.expectedMoves;

  const handleRefresh = () => queryClient.invalidateQueries({ queryKey: ["prediction-markets"] });

  const [globalEvents, setGlobalEvents] = useState<any | null>(null);
  const [globalRunning, setGlobalRunning] = useState(false);

  async function runGlobalEvents() {
    try {
      setGlobalRunning(true);
      const topics = ['oil','inflation','geopolitics'];
      const mod = await import('@/global_event_engine');
      const tasks = topics.map(t => mod.runAllAndCompute(t).catch(() => null));
      const results = await Promise.all(tasks);
      // merge results by averaging probabilities per event
      const eventKeys = ['oilSupplyShock','inflationSpike','policyTightening','recessionRisk','geopoliticalConflict'];
      const merged: any = { timestamp: new Date().toISOString(), eventProbabilities: {}, eventReliability: {}, overallReliability: 0, topEventDrivers: [] };
      for (const k of eventKeys) {
        const vals: number[] = [];
        const rels: number[] = [];
        for (const r of results) {
          if (!r) continue;
          const p = r.eventProbabilities?.[k];
          const rel = r.eventReliability?.[k];
          if (p != null) vals.push(p);
          if (rel != null) rels.push(rel);
        }
        merged.eventProbabilities[k] = vals.length ? (vals.reduce((a,b) => a + b, 0) / vals.length) : null;
        merged.eventReliability[k] = rels.length ? (rels.reduce((a,b) => a + b, 0) / rels.length) : 0;
      }
      // overall reliability as mean
      merged.overallReliability = Object.values(merged.eventReliability).reduce((a:any,b:any)=>a+(b||0),0) / eventKeys.length;
      // combine drivers
      merged.topEventDrivers = [];
      for (const r of results) if (r && r.topEventDrivers) merged.topEventDrivers.push(...r.topEventDrivers);
      // sort and keep top 6
      merged.topEventDrivers = (merged.topEventDrivers || []).sort((a:any,b:any) => Math.abs(b.p - 0.5) - Math.abs(a.p - 0.5)).slice(0,6);
      setGlobalEvents(merged);
    } catch (e) {
      console.error(e);
    } finally {
      setGlobalRunning(false);
    }
  }

  // run on mount
  useEffect(() => {
    runGlobalEvents();
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border px-4 md:px-8 py-3">
        <div className="max-w-5xl mx-auto flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-info" />
                <span className="text-foreground font-black text-sm tracking-tight">MARKET ORACLE</span>
              </div>
              <span className="text-muted-foreground text-[9px] font-medium tracking-wide uppercase">Global Market Intelligence</span>
            </div>
            <div className="flex items-center gap-3">
              {data && (
                <span className="text-muted-foreground text-[9px] font-mono bg-secondary px-1.5 py-0.5 rounded">Refresh in {countdown}</span>
              )}
              <span className="flex items-center gap-1.5 text-[10px]">
                <span className={`w-1.5 h-1.5 rounded-full ${data ? "bg-bullish animate-pulse-glow" : "bg-destructive"}`} />
                <span className={data ? "text-bullish font-semibold" : "text-destructive font-semibold"}>
                  {isLoading ? "Connecting…" : data ? "Live" : "Offline"}
                </span>
              </span>
              <button onClick={handleRefresh} className="text-muted-foreground hover:text-foreground p-1 rounded hover:bg-secondary transition-colors">
                <RefreshCw className={`w-3 h-3 ${isLoading ? "animate-spin" : ""}`} />
              </button>
            </div>
          </div>
          {data?.sources && (
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] text-muted-foreground font-medium">
                {liveSources} source{liveSources !== 1 ? "s" : ""}:
              </span>
              {Object.entries(data.sources).map(([name, count]: [string, any]) =>
                (count as number) > 0 && (
                  <span key={name} className="bg-secondary/80 rounded-md px-2 py-0.5 flex items-center gap-1.5 text-[9px] border border-border">
                    <span className={`w-1 h-1 rounded-full ${(count as number) > 0 ? "bg-bullish" : "bg-muted-foreground"}`} />
                    <span className="text-foreground font-medium capitalize">{name}</span>
                    <span className="text-muted-foreground font-mono">{(count as number)}</span>
                  </span>
                )
              )}
            </div>
          )}
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 md:px-8 py-6 space-y-4">
        {isLoading && !data && (
          <DashboardSkeleton />
        )}

        {isError && !data && (
          <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-4 text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <AlertTriangle className="w-5 h-5 text-destructive" />
              <span className="text-destructive font-semibold">Connection Error</span>
            </div>
            <p className="text-destructive text-sm">Failed to load market data. Please check your connection and try again.</p>
            <button
              onClick={handleRefresh}
              className="mt-3 px-4 py-2 bg-destructive/20 text-destructive rounded-lg hover:bg-destructive/30 transition-colors"
            >
              Retry Connection
            </button>
          </div>
        )}

        {/* ═══ ASSET FORECASTS — TOP ROW (Left to Right) ═══ */}
        {(data || !isLoading) && (
          <section>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <ForecastCard label="BTC/USD" variant="btc" currentPrice={prices.btc.current} predictedPrice={prices.btc.predicted}
                expectedMove={prices.btc.move} confidence={prediction.btcConfidence ?? prediction.confidence}
                liveSources={liveSources} sources={data?.sources} signalsProcessed={data?.signalsProcessedCount} reliability={data?.reliability?.btc} globalEvent={globalEvents} />
              <ForecastCard label="S&P 500" variant="sp500" currentPrice={prices.sp500.current} predictedPrice={prices.sp500.predicted}
                expectedMove={prices.sp500.move} confidence={prediction.sp500Confidence ?? prediction.confidence}
                liveSources={liveSources} sources={data?.sources} signalsProcessed={data?.signalsProcessedCount} reliability={data?.reliability?.sp500} globalEvent={globalEvents} />
              <ForecastCard label="XAU/USD" variant="gold" currentPrice={prices.gold.current} predictedPrice={prices.gold.predicted}
                expectedMove={prices.gold.move} confidence={prediction.goldConfidence ?? prediction.confidence}
                liveSources={liveSources} sources={data?.sources} signalsProcessed={data?.signalsProcessedCount} reliability={data?.reliability?.gold} globalEvent={globalEvents} />
              <ForecastCard label="WTI Oil" variant="oil" currentPrice={prices.oil.current} predictedPrice={prices.oil.predicted}
                expectedMove={prices.oil.move} confidence={prediction.oilConfidence ?? prediction.confidence}
                liveSources={liveSources} sources={data?.sources} signalsProcessed={data?.signalsProcessedCount} reliability={data?.reliability?.gold ?? "medium"} globalEvent={globalEvents} />
            </div>
          </section>
        )}

      </main>
    </div>
  );
};

export default Index;
