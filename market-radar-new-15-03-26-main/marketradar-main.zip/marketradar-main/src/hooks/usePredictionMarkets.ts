import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface MarketSignal {
  title: string;
  probability: number;
  volume: string;
  source: string;
  sentiment: number;
}

export interface AccuracyHistoryItem {
  date: string;
  btcAccuracy: number | null;
  sp500Accuracy: number | null;
  goldAccuracy: number | null;
  btcPredicted: number;
  btcActual: number | null;
  sp500Predicted: number;
  sp500Actual: number | null;
  goldPredicted: number;
  goldActual: number | null;
  btcDirCorrect: boolean | null;
  sp500DirCorrect: boolean | null;
  goldDirCorrect: boolean | null;
  btcError: number | null;
  sp500Error: number | null;
  goldError: number | null;
  btcMAPE: number | null;
  sp500MAPE: number | null;
  goldMAPE: number | null;
}

export interface SocialPlatform {
  mentions: number;
  changePercent: number;
}

export interface SocialAssetData {
  sentimentScore: number;
  newsFrequency: number;
  topicTrends: string[];
  reddit: SocialPlatform;
  twitter: SocialPlatform;
  youtube: SocialPlatform;
  hackerNews: SocialPlatform;
  stocktwits: SocialPlatform;
  googleTrends: SocialPlatform;
  totalSourcesAnalyzed: number;
  sentimentTrend6h: "improving" | "declining" | "stable";
  sourceBreakdown: { news: number; social: number; searchTrends: number; devActivity: number };
  weightedComponents: { news: number; social: number; searchTrends: number; devActivity: number };
  credibilityScore: number;
  signalStrength: "strong" | "moderate" | "weak";
}

export interface RealtimeAccuracy {
  oneHour: { btc: number | null; sp500: number | null; gold: number | null };
  twelveHour: { btc: number | null; sp500: number | null; gold: number | null };
}

export interface WhaleTransaction {
  id: string;
  asset: "BTC" | "ETH" | "SOL";
  type: "accumulation" | "selling" | "exchange_inflow" | "exchange_outflow";
  amountUsd: number;
  exchange: string;
  timestamp: string;
}

export interface WhaleData {
  transactions: WhaleTransaction[];
  scores: { btc: number; eth: number; sol: number };
  heatmap: { hour: string; btc: number; eth: number; sol: number }[];
  summary: {
    totalVolume24h: number;
    netFlow: number;
    dominantActivity: string;
  };
}

export interface GlobalMarketPulse {
  score: number;
  environment: string;
  drivers: string[];
  regime: string;
}

export interface MarketCorrelation {
  strength: string;
  direction: string;
}

export interface PlatformConsensus {
  platform: string;
  weight: number;
  avgProbability: number;
  signalCount: number;
  sentiment: number;
}

export interface PredictionConsensusData {
  score: number;
  consensus: number;
  platforms: PlatformConsensus[];
  divergence: number;
  totalContracts: number;
}

export interface LiquidityShock {
  type: "stablecoin_spike" | "whale_cluster" | "exchange_flow";
  direction: "bullish" | "bearish";
  severity: "high" | "medium";
  description: string;
  timestamp: string;
  source: string;
}

export interface VolatilityContext {
  btc: { hourly: number; daily: number };
  sp500: { hourly: number; daily: number };
  gold: { hourly: number; daily: number };
}

export interface PredictionResponse {
  signals: any[];
  prediction: {
    sp500: { value: number; label: string; direction: string };
    btc: { value: number; label: string; direction: string };
    gold: { value: number; label: string; direction: string };
    confidence: number;
    btcConfidence: number;
    sp500Confidence: number;
    goldConfidence: number;
    signalsUsed: number;
  };
  sources: {
    polymarket: number;
    kalshi: number;
    manifold: number;
    metaculus: number;
  };
  signalsProcessedCount: number;
  prices: {
    btc: { current: number; predicted: number; move: number };
    sp500: { current: number; predicted: number; move: number };
    gold: { current: number; predicted: number; move: number };
  };
  momentumScore: number;
  volumeTrend: number;
  volatility: number;
  marketScore: { btc: number; sp500: number; gold: number };
  signalDrivers: {
    btc: { sentimentRaw: number; sentimentLabel: string; momentum: number; volatility: number; liquidity: number; signalCount: number };
    sp500: { sentimentRaw: number; sentimentLabel: string; momentum: number; volatility: number; liquidity: number; signalCount: number };
    gold: { sentimentRaw: number; sentimentLabel: string; momentum: number; volatility: number; liquidity: number; signalCount: number };
  };
  accuracyHistory: AccuracyHistoryItem[];
  realtimeAccuracy: RealtimeAccuracy;
  optionsMetrics: {
    btc: { impliedVolatility: number; putCallRatio: number; skew: number; openInterest: number };
    sp500: { impliedVolatility: number; putCallRatio: number; skew: number; openInterest: number };
    gold: { impliedVolatility: number; putCallRatio: number; skew: number; openInterest: number };
  };
  socialSentiment: {
    btc: SocialAssetData;
    sp500: SocialAssetData;
    gold: SocialAssetData;
  };
  whaleActivity: WhaleData;
  stablecoinLiquidity: {
    events: any[];
    flowBars: { label: string; value: number; type: "inflow" | "outflow" }[];
    timeline: { time: string; usdt_inflow: number; usdt_outflow: number; usdc_inflow: number; usdc_outflow: number }[];
    liquidityScore: number;
    liquidityTrend: "Bullish" | "Neutral" | "Bearish";
    usdtMinted24h: number;
    usdtNetFlow: number;
    usdcNetFlow: number;
  };
  predictionInputs: {
    predictionMarkets: { weight: number; score: number; contracts: number };
    momentum: { weight: number; score: number };
    volume: { weight: number; score: number };
    stablecoin: { weight: number; score: number; trend: string };
    whale: { weight: number; score: number; activity: string };
    news: { weight: number; score: number; frequency: number };
  };
  globalMarketPulse: GlobalMarketPulse;
  predictionDrivers: {
    btc: { text: string; source: string }[];
    sp500: { text: string; source: string }[];
    gold: { text: string; source: string }[];
  };
  correlations: {
    btcSp500: MarketCorrelation;
    goldSp500: MarketCorrelation;
    btcGold: MarketCorrelation;
  };
  marketRegimes: { btc: string; sp500: string; gold: string };
  predictionConsensus: PredictionConsensusData;
  volatilityContext: VolatilityContext;
  liquidityShocks: LiquidityShock[];
  narrative: string;
  reliability: { btc: "high" | "medium" | "low"; sp500: "high" | "medium" | "low"; gold: "high" | "medium" | "low" };
  clusterScores: { liquidity: number; marketStructure: number; sentiment: number; derivativesRisk: number; macroConditions: number };
  scenarioProbabilities: { bullish: number; neutral: number; bearish: number };
  timeframeScores: {
    btc: { "1h": number; "4h": number; "24h": number; "7d": number };
    sp500: { "1h": number; "4h": number; "24h": number; "7d": number };
    gold: { "1h": number; "4h": number; "24h": number; "7d": number };
  };
  anomalies: { type: string; severity: string; description: string; timestamp: string }[];
  dataFreshness: number;
  regimeWeights: { momentum: number; liquidity: number; whale: number; predictionMarkets: number; volume: number; sentiment: number };
  liquidityIndex: number;
  topDrivers: { label: string; impact: number; delta: number }[];
  expectedMoves: {
    btc: { "1h": number; "4h": number; "24h": number };
    sp500: { "1h": number; "4h": number; "24h": number };
    gold: { "1h": number; "4h": number; "24h": number };
  };
  fetchedAt: string;
  predictionMarketsByGroup?: Record<string, any[]>;
  predictionMarketCounts?: Record<string, number>;
}

async function fetchPredictionMarkets(): Promise<PredictionResponse> {
  const { data, error } = await supabase.functions.invoke("prediction-markets");
  if (error) throw new Error(error.message);
  return data as PredictionResponse;
}

export function usePredictionMarkets() {
  return useQuery({
    queryKey: ["prediction-markets"],
    queryFn: fetchPredictionMarkets,
    refetchInterval: 1 * 60 * 1000,
    staleTime: 1 * 60 * 1000,
    retry: 2,
  });
}
