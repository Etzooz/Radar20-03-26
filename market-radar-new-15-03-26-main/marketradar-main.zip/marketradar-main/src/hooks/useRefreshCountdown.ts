import { useState, useEffect, useRef } from "react";

export function useRefreshCountdown(intervalMs: number, dataUpdatedAt: number, onExpire?: () => void) {
  const [secondsLeft, setSecondsLeft] = useState(0);
  const firedRef = useRef(false);

  useEffect(() => {
    firedRef.current = false;
  }, [dataUpdatedAt]);

  useEffect(() => {
    if (dataUpdatedAt === 0) return;

    const tick = () => {
      const elapsed = Date.now() - dataUpdatedAt;
      const remaining = Math.max(0, Math.ceil((intervalMs - elapsed) / 1000));
      setSecondsLeft(remaining);
      if (remaining === 0 && !firedRef.current) {
        firedRef.current = true;
        onExpire?.();
      }
    };

    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [dataUpdatedAt, intervalMs, onExpire]);

  const minutes = Math.floor(secondsLeft / 60);
  const seconds = secondsLeft % 60;
  const display = `${minutes}:${seconds.toString().padStart(2, "0")}`;

  return { secondsLeft, display };
}
